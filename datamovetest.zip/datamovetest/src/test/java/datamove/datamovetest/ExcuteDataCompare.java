package datamove.datamovetest;

import com.modules.barrieroptbkinfo.BarrieroptbkinfoCompare;
import com.modules.bkunderlyinginfo.BkunderlyinginfoCompare;
import com.modules.bondbkinfo.BondbkinfoCompare;
import com.modules.bookingbasicinfo.BookingbasicinfoCompare;
import com.modules.calendar.CalendarCompare;
import com.modules.cashflow.CashflowCompare;
import com.modules.client.ClientCompare;
import com.modules.clientpricing.ClientpricingCompare;
import com.modules.codecatalog.CodecatalogCompare;
import com.modules.codelibrary.CodelibraryCompare;
import com.modules.corpaction.CorpactionCompare;
import com.modules.correlation.CorrelationCompare;
import com.modules.dividend.DividendCompare;
import com.modules.eqswpbkinfo.EqswpbkinfoModelWithBLOBsCompare;
import com.modules.hisprice.HispriceCompare;
import com.modules.interestrate.InterestrateCompare;
import com.modules.liveprice.LivepriceCompare;
import com.modules.margin.MarginCompare;
import com.modules.marktomkt.MarktomktCompare;
import com.modules.nonlinearswapinfo.NonlinearswapinfoCompare;
import com.modules.optionportfolio.OptionportfolioCompare;
import com.modules.parameter.ParameterCompare;
import com.modules.repo.RepoCompare;
import com.modules.tradecheckrecords.TradecheckrecordsCompare;
import com.modules.tradingflowinfo.TradingflowinfoCompare;
import com.modules.underlying.UnderlyingCompare;
import com.modules.volatility.VolatilityCompare;

public class ExcuteDataCompare {
	
	
	public static void main(String[] args) {
		new BarrieroptbkinfoCompare().compare();
		new BkunderlyinginfoCompare().compare();
		new BondbkinfoCompare().compare();
		new BookingbasicinfoCompare().compare();
		new CalendarCompare().compare();
		new CashflowCompare().compare();
		new ClientCompare().compare();
		new ClientpricingCompare().compare();
		new CodecatalogCompare().compare();
		new CodelibraryCompare().compare();
		new CorpactionCompare().compare();
		new CorrelationCompare().compare();
		new DividendCompare().compare();
		new EqswpbkinfoModelWithBLOBsCompare().compare();
		new HispriceCompare().compare();
		new InterestrateCompare().compare();
		new LivepriceCompare().compare();
		new MarginCompare().compare();
		new MarktomktCompare().compare();
		new NonlinearswapinfoCompare().compare();
		new OptionportfolioCompare().compare();
		new ParameterCompare().compare();
		new RepoCompare().compare();
		new TradecheckrecordsCompare().compare();
		new TradingflowinfoCompare().compare();
		new UnderlyingCompare().compare();
		new VolatilityCompare().compare();
		
	}
	

}
