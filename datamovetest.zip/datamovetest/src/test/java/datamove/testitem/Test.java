package datamove.testitem;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		SimpleDateFormat sd = new SimpleDateFormat("yyyyMMdd/hhmmss");
		Date date = new Date(1510997902000l);
		String dd = sd.format(date);
		System.out.println(dd);
		
		
		String s = new String("删除报错".getBytes(),"UTF-8");
		System.out.println(s);
		System.out.println("删除报错");
		
	}

}
