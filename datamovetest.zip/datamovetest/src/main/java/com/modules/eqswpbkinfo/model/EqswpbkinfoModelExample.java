package com.modules.eqswpbkinfo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EqswpbkinfoModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public EqswpbkinfoModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andLeverageIsNull() {
            addCriterion("Leverage is null");
            return (Criteria) this;
        }

        public Criteria andLeverageIsNotNull() {
            addCriterion("Leverage is not null");
            return (Criteria) this;
        }

        public Criteria andLeverageEqualTo(BigDecimal value) {
            addCriterion("Leverage =", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageNotEqualTo(BigDecimal value) {
            addCriterion("Leverage <>", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageGreaterThan(BigDecimal value) {
            addCriterion("Leverage >", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Leverage >=", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageLessThan(BigDecimal value) {
            addCriterion("Leverage <", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Leverage <=", value, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageIn(List<BigDecimal> values) {
            addCriterion("Leverage in", values, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageNotIn(List<BigDecimal> values) {
            addCriterion("Leverage not in", values, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Leverage between", value1, value2, "leverage");
            return (Criteria) this;
        }

        public Criteria andLeverageNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Leverage not between", value1, value2, "leverage");
            return (Criteria) this;
        }

        public Criteria andFundingrateIsNull() {
            addCriterion("FundingRate is null");
            return (Criteria) this;
        }

        public Criteria andFundingrateIsNotNull() {
            addCriterion("FundingRate is not null");
            return (Criteria) this;
        }

        public Criteria andFundingrateEqualTo(BigDecimal value) {
            addCriterion("FundingRate =", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateNotEqualTo(BigDecimal value) {
            addCriterion("FundingRate <>", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateGreaterThan(BigDecimal value) {
            addCriterion("FundingRate >", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FundingRate >=", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateLessThan(BigDecimal value) {
            addCriterion("FundingRate <", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FundingRate <=", value, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateIn(List<BigDecimal> values) {
            addCriterion("FundingRate in", values, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateNotIn(List<BigDecimal> values) {
            addCriterion("FundingRate not in", values, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FundingRate between", value1, value2, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingrateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FundingRate not between", value1, value2, "fundingrate");
            return (Criteria) this;
        }

        public Criteria andFundingccyIsNull() {
            addCriterion("FundingCcy is null");
            return (Criteria) this;
        }

        public Criteria andFundingccyIsNotNull() {
            addCriterion("FundingCcy is not null");
            return (Criteria) this;
        }

        public Criteria andFundingccyEqualTo(String value) {
            addCriterion("FundingCcy =", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyNotEqualTo(String value) {
            addCriterion("FundingCcy <>", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyGreaterThan(String value) {
            addCriterion("FundingCcy >", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyGreaterThanOrEqualTo(String value) {
            addCriterion("FundingCcy >=", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyLessThan(String value) {
            addCriterion("FundingCcy <", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyLessThanOrEqualTo(String value) {
            addCriterion("FundingCcy <=", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyLike(String value) {
            addCriterion("FundingCcy like", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyNotLike(String value) {
            addCriterion("FundingCcy not like", value, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyIn(List<String> values) {
            addCriterion("FundingCcy in", values, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyNotIn(List<String> values) {
            addCriterion("FundingCcy not in", values, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyBetween(String value1, String value2) {
            addCriterion("FundingCcy between", value1, value2, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundingccyNotBetween(String value1, String value2) {
            addCriterion("FundingCcy not between", value1, value2, "fundingccy");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqIsNull() {
            addCriterion("FundResetFreq is null");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqIsNotNull() {
            addCriterion("FundResetFreq is not null");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqEqualTo(Integer value) {
            addCriterion("FundResetFreq =", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqNotEqualTo(Integer value) {
            addCriterion("FundResetFreq <>", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqGreaterThan(Integer value) {
            addCriterion("FundResetFreq >", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqGreaterThanOrEqualTo(Integer value) {
            addCriterion("FundResetFreq >=", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqLessThan(Integer value) {
            addCriterion("FundResetFreq <", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqLessThanOrEqualTo(Integer value) {
            addCriterion("FundResetFreq <=", value, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqIn(List<Integer> values) {
            addCriterion("FundResetFreq in", values, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqNotIn(List<Integer> values) {
            addCriterion("FundResetFreq not in", values, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqBetween(Integer value1, Integer value2) {
            addCriterion("FundResetFreq between", value1, value2, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundresetfreqNotBetween(Integer value1, Integer value2) {
            addCriterion("FundResetFreq not between", value1, value2, "fundresetfreq");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayIsNull() {
            addCriterion("FundSettleDelay is null");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayIsNotNull() {
            addCriterion("FundSettleDelay is not null");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayEqualTo(Integer value) {
            addCriterion("FundSettleDelay =", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayNotEqualTo(Integer value) {
            addCriterion("FundSettleDelay <>", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayGreaterThan(Integer value) {
            addCriterion("FundSettleDelay >", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayGreaterThanOrEqualTo(Integer value) {
            addCriterion("FundSettleDelay >=", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayLessThan(Integer value) {
            addCriterion("FundSettleDelay <", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayLessThanOrEqualTo(Integer value) {
            addCriterion("FundSettleDelay <=", value, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayIn(List<Integer> values) {
            addCriterion("FundSettleDelay in", values, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayNotIn(List<Integer> values) {
            addCriterion("FundSettleDelay not in", values, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayBetween(Integer value1, Integer value2) {
            addCriterion("FundSettleDelay between", value1, value2, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andFundsettledelayNotBetween(Integer value1, Integer value2) {
            addCriterion("FundSettleDelay not between", value1, value2, "fundsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqIsNull() {
            addCriterion("DivResetFreq is null");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqIsNotNull() {
            addCriterion("DivResetFreq is not null");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqEqualTo(Integer value) {
            addCriterion("DivResetFreq =", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqNotEqualTo(Integer value) {
            addCriterion("DivResetFreq <>", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqGreaterThan(Integer value) {
            addCriterion("DivResetFreq >", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqGreaterThanOrEqualTo(Integer value) {
            addCriterion("DivResetFreq >=", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqLessThan(Integer value) {
            addCriterion("DivResetFreq <", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqLessThanOrEqualTo(Integer value) {
            addCriterion("DivResetFreq <=", value, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqIn(List<Integer> values) {
            addCriterion("DivResetFreq in", values, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqNotIn(List<Integer> values) {
            addCriterion("DivResetFreq not in", values, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqBetween(Integer value1, Integer value2) {
            addCriterion("DivResetFreq between", value1, value2, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivresetfreqNotBetween(Integer value1, Integer value2) {
            addCriterion("DivResetFreq not between", value1, value2, "divresetfreq");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayIsNull() {
            addCriterion("DivSettleDelay is null");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayIsNotNull() {
            addCriterion("DivSettleDelay is not null");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayEqualTo(Integer value) {
            addCriterion("DivSettleDelay =", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayNotEqualTo(Integer value) {
            addCriterion("DivSettleDelay <>", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayGreaterThan(Integer value) {
            addCriterion("DivSettleDelay >", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayGreaterThanOrEqualTo(Integer value) {
            addCriterion("DivSettleDelay >=", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayLessThan(Integer value) {
            addCriterion("DivSettleDelay <", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayLessThanOrEqualTo(Integer value) {
            addCriterion("DivSettleDelay <=", value, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayIn(List<Integer> values) {
            addCriterion("DivSettleDelay in", values, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayNotIn(List<Integer> values) {
            addCriterion("DivSettleDelay not in", values, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayBetween(Integer value1, Integer value2) {
            addCriterion("DivSettleDelay between", value1, value2, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andDivsettledelayNotBetween(Integer value1, Integer value2) {
            addCriterion("DivSettleDelay not between", value1, value2, "divsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqIsNull() {
            addCriterion("EqResetFreq is null");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqIsNotNull() {
            addCriterion("EqResetFreq is not null");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqEqualTo(Integer value) {
            addCriterion("EqResetFreq =", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqNotEqualTo(Integer value) {
            addCriterion("EqResetFreq <>", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqGreaterThan(Integer value) {
            addCriterion("EqResetFreq >", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqGreaterThanOrEqualTo(Integer value) {
            addCriterion("EqResetFreq >=", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqLessThan(Integer value) {
            addCriterion("EqResetFreq <", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqLessThanOrEqualTo(Integer value) {
            addCriterion("EqResetFreq <=", value, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqIn(List<Integer> values) {
            addCriterion("EqResetFreq in", values, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqNotIn(List<Integer> values) {
            addCriterion("EqResetFreq not in", values, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqBetween(Integer value1, Integer value2) {
            addCriterion("EqResetFreq between", value1, value2, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqresetfreqNotBetween(Integer value1, Integer value2) {
            addCriterion("EqResetFreq not between", value1, value2, "eqresetfreq");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayIsNull() {
            addCriterion("EqSettleDelay is null");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayIsNotNull() {
            addCriterion("EqSettleDelay is not null");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayEqualTo(Integer value) {
            addCriterion("EqSettleDelay =", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayNotEqualTo(Integer value) {
            addCriterion("EqSettleDelay <>", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayGreaterThan(Integer value) {
            addCriterion("EqSettleDelay >", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayGreaterThanOrEqualTo(Integer value) {
            addCriterion("EqSettleDelay >=", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayLessThan(Integer value) {
            addCriterion("EqSettleDelay <", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayLessThanOrEqualTo(Integer value) {
            addCriterion("EqSettleDelay <=", value, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayIn(List<Integer> values) {
            addCriterion("EqSettleDelay in", values, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayNotIn(List<Integer> values) {
            addCriterion("EqSettleDelay not in", values, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayBetween(Integer value1, Integer value2) {
            addCriterion("EqSettleDelay between", value1, value2, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andEqsettledelayNotBetween(Integer value1, Integer value2) {
            addCriterion("EqSettleDelay not between", value1, value2, "eqsettledelay");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNull() {
            addCriterion("LastUpdateUser is null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNotNull() {
            addCriterion("LastUpdateUser is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserEqualTo(String value) {
            addCriterion("LastUpdateUser =", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotEqualTo(String value) {
            addCriterion("LastUpdateUser <>", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThan(String value) {
            addCriterion("LastUpdateUser >", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser >=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThan(String value) {
            addCriterion("LastUpdateUser <", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser <=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLike(String value) {
            addCriterion("LastUpdateUser like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotLike(String value) {
            addCriterion("LastUpdateUser not like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIn(List<String> values) {
            addCriterion("LastUpdateUser in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotIn(List<String> values) {
            addCriterion("LastUpdateUser not in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserBetween(String value1, String value2) {
            addCriterion("LastUpdateUser between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotBetween(String value1, String value2) {
            addCriterion("LastUpdateUser not between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("LastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("LastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("LastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("LastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("LastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("LastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("LastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("LastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}