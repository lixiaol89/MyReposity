package com.modules.eqswpbkinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.eqswpbkinfo.dao.EqswpbkinfoModelMapper;
import com.modules.eqswpbkinfo.model.EqswpbkinfoModelWithBLOBs;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class EqswpbkinfoModelWithBLOBsCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		EqswpbkinfoModelMapper sourcemapper = GetDataSource.getMapper(EqswpbkinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		EqswpbkinfoModelMapper targetmapper = GetDataSource.getMapper(EqswpbkinfoModelMapper.class, sessionqa);
		
		
		List<EqswpbkinfoModelWithBLOBs> source = sourcemapper.selectByExampleWithBLOBs(null);
		List<EqswpbkinfoModelWithBLOBs> target = targetmapper.selectByExampleWithBLOBs(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<EqswpbkinfoModelWithBLOBs> same = new ArrayList<EqswpbkinfoModelWithBLOBs>();
		for(EqswpbkinfoModelWithBLOBs targetmodel : target){
			for(EqswpbkinfoModelWithBLOBs sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(EqswpbkinfoModelWithBLOBs smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(EqswpbkinfoModelWithBLOBs samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new EqswpbkinfoModelWithBLOBsCompare().compare();
	}


}
