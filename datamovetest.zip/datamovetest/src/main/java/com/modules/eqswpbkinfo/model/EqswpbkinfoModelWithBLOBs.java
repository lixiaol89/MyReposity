package com.modules.eqswpbkinfo.model;

public class EqswpbkinfoModelWithBLOBs extends EqswpbkinfoModel {
    private String fundresetdates;

    private String divresetdates;

    private String eqresetdatesspots;

    public String getFundresetdates() {
        return fundresetdates;
    }

    public void setFundresetdates(String fundresetdates) {
        this.fundresetdates = fundresetdates == null ? null : fundresetdates.trim();
    }

    public String getDivresetdates() {
        return divresetdates;
    }

    public void setDivresetdates(String divresetdates) {
        this.divresetdates = divresetdates == null ? null : divresetdates.trim();
    }

    public String getEqresetdatesspots() {
        return eqresetdatesspots;
    }

    public void setEqresetdatesspots(String eqresetdatesspots) {
        this.eqresetdatesspots = eqresetdatesspots == null ? null : eqresetdatesspots.trim();
    }
}