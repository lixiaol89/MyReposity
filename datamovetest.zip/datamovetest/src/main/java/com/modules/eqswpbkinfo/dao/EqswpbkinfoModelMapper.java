package com.modules.eqswpbkinfo.dao;

import com.modules.eqswpbkinfo.model.EqswpbkinfoModel;
import com.modules.eqswpbkinfo.model.EqswpbkinfoModelExample;
import com.modules.eqswpbkinfo.model.EqswpbkinfoModelWithBLOBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EqswpbkinfoModelMapper {
    int countByExample(EqswpbkinfoModelExample example);

    int deleteByExample(EqswpbkinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EqswpbkinfoModelWithBLOBs record);

    int insertSelective(EqswpbkinfoModelWithBLOBs record);

    List<EqswpbkinfoModelWithBLOBs> selectByExampleWithBLOBs(EqswpbkinfoModelExample example);

    List<EqswpbkinfoModel> selectByExample(EqswpbkinfoModelExample example);

    EqswpbkinfoModelWithBLOBs selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") EqswpbkinfoModelWithBLOBs record, @Param("example") EqswpbkinfoModelExample example);

    int updateByExampleWithBLOBs(@Param("record") EqswpbkinfoModelWithBLOBs record, @Param("example") EqswpbkinfoModelExample example);

    int updateByExample(@Param("record") EqswpbkinfoModel record, @Param("example") EqswpbkinfoModelExample example);

    int updateByPrimaryKeySelective(EqswpbkinfoModelWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(EqswpbkinfoModelWithBLOBs record);

    int updateByPrimaryKey(EqswpbkinfoModel record);
}