package com.modules.eqswpbkinfo.model;

import java.math.BigDecimal;
import java.util.Date;

public class EqswpbkinfoModel {
    private Integer id;

    private String tradeid;

    private BigDecimal leverage;

    private BigDecimal fundingrate;

    private String fundingccy;

    private Integer fundresetfreq;

    private Integer fundsettledelay;

    private Integer divresetfreq;

    private Integer divsettledelay;

    private Integer eqresetfreq;

    private Integer eqsettledelay;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public BigDecimal getLeverage() {
        return leverage;
    }

    public void setLeverage(BigDecimal leverage) {
        this.leverage = leverage;
    }

    public BigDecimal getFundingrate() {
        return fundingrate;
    }

    public void setFundingrate(BigDecimal fundingrate) {
        this.fundingrate = fundingrate;
    }

    public String getFundingccy() {
        return fundingccy;
    }

    public void setFundingccy(String fundingccy) {
        this.fundingccy = fundingccy == null ? null : fundingccy.trim();
    }

    public Integer getFundresetfreq() {
        return fundresetfreq;
    }

    public void setFundresetfreq(Integer fundresetfreq) {
        this.fundresetfreq = fundresetfreq;
    }

    public Integer getFundsettledelay() {
        return fundsettledelay;
    }

    public void setFundsettledelay(Integer fundsettledelay) {
        this.fundsettledelay = fundsettledelay;
    }

    public Integer getDivresetfreq() {
        return divresetfreq;
    }

    public void setDivresetfreq(Integer divresetfreq) {
        this.divresetfreq = divresetfreq;
    }

    public Integer getDivsettledelay() {
        return divsettledelay;
    }

    public void setDivsettledelay(Integer divsettledelay) {
        this.divsettledelay = divsettledelay;
    }

    public Integer getEqresetfreq() {
        return eqresetfreq;
    }

    public void setEqresetfreq(Integer eqresetfreq) {
        this.eqresetfreq = eqresetfreq;
    }

    public Integer getEqsettledelay() {
        return eqsettledelay;
    }

    public void setEqsettledelay(Integer eqsettledelay) {
        this.eqsettledelay = eqsettledelay;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}