package com.modules.client;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.client.dao.ClientModelMapper;
import com.modules.client.model.ClientModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class ClientCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		ClientModelMapper sourcemapper = GetDataSource.getMapper(ClientModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		ClientModelMapper targetmapper = GetDataSource.getMapper(ClientModelMapper.class, sessionqa);
		
		
		List<ClientModel> source = sourcemapper.selectByExample(null);
		List<ClientModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<ClientModel> same = new ArrayList<ClientModel>();
		for(ClientModel targetmodel : target){
			for(ClientModel sourcemodel : source){
				if(targetmodel.getClientid().equals(sourcemodel.getClientid())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(ClientModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(ClientModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new ClientCompare().compare();
	}


}
