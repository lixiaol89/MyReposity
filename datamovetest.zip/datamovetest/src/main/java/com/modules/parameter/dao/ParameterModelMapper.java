package com.modules.parameter.dao;

import com.modules.parameter.model.ParameterModel;
import com.modules.parameter.model.ParameterModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ParameterModelMapper {
    int countByExample(ParameterModelExample example);

    int deleteByExample(ParameterModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ParameterModel record);

    int insertSelective(ParameterModel record);

    List<ParameterModel> selectByExample(ParameterModelExample example);

    ParameterModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ParameterModel record, @Param("example") ParameterModelExample example);

    int updateByExample(@Param("record") ParameterModel record, @Param("example") ParameterModelExample example);

    int updateByPrimaryKeySelective(ParameterModel record);

    int updateByPrimaryKey(ParameterModel record);
}