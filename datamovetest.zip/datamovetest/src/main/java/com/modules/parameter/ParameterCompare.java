package com.modules.parameter;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.parameter.dao.ParameterModelMapper;
import com.modules.parameter.model.ParameterModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class ParameterCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		ParameterModelMapper sourcemapper = GetDataSource.getMapper(ParameterModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		ParameterModelMapper targetmapper = GetDataSource.getMapper(ParameterModelMapper.class, sessionqa);
		
		
		List<ParameterModel> source = sourcemapper.selectByExample(null);
		List<ParameterModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<ParameterModel> same = new ArrayList<ParameterModel>();
		for(ParameterModel targetmodel : target){
			for(ParameterModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getParameter()==sourcemodel.getParameter()&&
						targetmodel.getFamily()==sourcemodel.getFamily()&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(ParameterModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(ParameterModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new ParameterCompare().compare();
	}


}
