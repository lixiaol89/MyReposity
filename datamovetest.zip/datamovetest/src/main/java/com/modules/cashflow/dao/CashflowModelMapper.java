package com.modules.cashflow.dao;

import com.modules.cashflow.model.CashflowModel;
import com.modules.cashflow.model.CashflowModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CashflowModelMapper {
    int countByExample(CashflowModelExample example);

    int deleteByExample(CashflowModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CashflowModel record);

    int insertSelective(CashflowModel record);

    List<CashflowModel> selectByExample(CashflowModelExample example);

    CashflowModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CashflowModel record, @Param("example") CashflowModelExample example);

    int updateByExample(@Param("record") CashflowModel record, @Param("example") CashflowModelExample example);

    int updateByPrimaryKeySelective(CashflowModel record);

    int updateByPrimaryKey(CashflowModel record);
}