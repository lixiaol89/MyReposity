package com.modules.cashflow;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.cashflow.dao.CashflowModelMapper;
import com.modules.cashflow.model.CashflowModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CashflowCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CashflowModelMapper sourcemapper = GetDataSource.getMapper(CashflowModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CashflowModelMapper targetmapper = GetDataSource.getMapper(CashflowModelMapper.class, sessionqa);
		
		
		List<CashflowModel> source = sourcemapper.selectByExample(null);
		List<CashflowModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CashflowModel> same = new ArrayList<CashflowModel>();
		for(CashflowModel targetmodel : target){
			for(CashflowModel sourcemodel : source){
				if(targetmodel.getSerialno().equals(sourcemodel.getSerialno())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(CashflowModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CashflowModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CashflowCompare().compare();
	}


}
