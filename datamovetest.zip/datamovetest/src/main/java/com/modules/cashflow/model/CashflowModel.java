package com.modules.cashflow.model;

import java.math.BigDecimal;
import java.util.Date;

public class CashflowModel {
    private Integer id;

    private String serialno;

    private String tradeid;

    private String clientid;

    private Date date;

    private Date settlementdate;

    private String currency;

    private Integer businclass;

    private BigDecimal amount;

    private Boolean ismargin;

    private Boolean issettled;

    private Integer status;

    private String errormessage;

    private String comment;

    private String checkoperator;

    private Date checktime;

    private String settleoperator;

    private Date settletime;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerialno() {
        return serialno;
    }

    public void setSerialno(String serialno) {
        this.serialno = serialno == null ? null : serialno.trim();
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public String getClientid() {
        return clientid;
    }

    public void setClientid(String clientid) {
        this.clientid = clientid == null ? null : clientid.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getSettlementdate() {
        return settlementdate;
    }

    public void setSettlementdate(Date settlementdate) {
        this.settlementdate = settlementdate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Integer getBusinclass() {
        return businclass;
    }

    public void setBusinclass(Integer businclass) {
        this.businclass = businclass;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Boolean getIsmargin() {
        return ismargin;
    }

    public void setIsmargin(Boolean ismargin) {
        this.ismargin = ismargin;
    }

    public Boolean getIssettled() {
        return issettled;
    }

    public void setIssettled(Boolean issettled) {
        this.issettled = issettled;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getErrormessage() {
        return errormessage;
    }

    public void setErrormessage(String errormessage) {
        this.errormessage = errormessage == null ? null : errormessage.trim();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment == null ? null : comment.trim();
    }

    public String getCheckoperator() {
        return checkoperator;
    }

    public void setCheckoperator(String checkoperator) {
        this.checkoperator = checkoperator == null ? null : checkoperator.trim();
    }

    public Date getChecktime() {
        return checktime;
    }

    public void setChecktime(Date checktime) {
        this.checktime = checktime;
    }

    public String getSettleoperator() {
        return settleoperator;
    }

    public void setSettleoperator(String settleoperator) {
        this.settleoperator = settleoperator == null ? null : settleoperator.trim();
    }

    public Date getSettletime() {
        return settletime;
    }

    public void setSettletime(Date settletime) {
        this.settletime = settletime;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}