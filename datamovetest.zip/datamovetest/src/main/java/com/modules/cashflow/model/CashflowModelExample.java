package com.modules.cashflow.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CashflowModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CashflowModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSerialnoIsNull() {
            addCriterion("SerialNo is null");
            return (Criteria) this;
        }

        public Criteria andSerialnoIsNotNull() {
            addCriterion("SerialNo is not null");
            return (Criteria) this;
        }

        public Criteria andSerialnoEqualTo(String value) {
            addCriterion("SerialNo =", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoNotEqualTo(String value) {
            addCriterion("SerialNo <>", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoGreaterThan(String value) {
            addCriterion("SerialNo >", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoGreaterThanOrEqualTo(String value) {
            addCriterion("SerialNo >=", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoLessThan(String value) {
            addCriterion("SerialNo <", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoLessThanOrEqualTo(String value) {
            addCriterion("SerialNo <=", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoLike(String value) {
            addCriterion("SerialNo like", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoNotLike(String value) {
            addCriterion("SerialNo not like", value, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoIn(List<String> values) {
            addCriterion("SerialNo in", values, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoNotIn(List<String> values) {
            addCriterion("SerialNo not in", values, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoBetween(String value1, String value2) {
            addCriterion("SerialNo between", value1, value2, "serialno");
            return (Criteria) this;
        }

        public Criteria andSerialnoNotBetween(String value1, String value2) {
            addCriterion("SerialNo not between", value1, value2, "serialno");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andClientidIsNull() {
            addCriterion("ClientID is null");
            return (Criteria) this;
        }

        public Criteria andClientidIsNotNull() {
            addCriterion("ClientID is not null");
            return (Criteria) this;
        }

        public Criteria andClientidEqualTo(String value) {
            addCriterion("ClientID =", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotEqualTo(String value) {
            addCriterion("ClientID <>", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidGreaterThan(String value) {
            addCriterion("ClientID >", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidGreaterThanOrEqualTo(String value) {
            addCriterion("ClientID >=", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLessThan(String value) {
            addCriterion("ClientID <", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLessThanOrEqualTo(String value) {
            addCriterion("ClientID <=", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLike(String value) {
            addCriterion("ClientID like", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotLike(String value) {
            addCriterion("ClientID not like", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidIn(List<String> values) {
            addCriterion("ClientID in", values, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotIn(List<String> values) {
            addCriterion("ClientID not in", values, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidBetween(String value1, String value2) {
            addCriterion("ClientID between", value1, value2, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotBetween(String value1, String value2) {
            addCriterion("ClientID not between", value1, value2, "clientid");
            return (Criteria) this;
        }

        public Criteria andDateIsNull() {
            addCriterion("Date is null");
            return (Criteria) this;
        }

        public Criteria andDateIsNotNull() {
            addCriterion("Date is not null");
            return (Criteria) this;
        }

        public Criteria andDateEqualTo(Date value) {
            addCriterionForJDBCDate("Date =", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("Date <>", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateGreaterThan(Date value) {
            addCriterionForJDBCDate("Date >", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("Date >=", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateLessThan(Date value) {
            addCriterionForJDBCDate("Date <", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("Date <=", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateIn(List<Date> values) {
            addCriterionForJDBCDate("Date in", values, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("Date not in", values, "date");
            return (Criteria) this;
        }

        public Criteria andDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("Date between", value1, value2, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("Date not between", value1, value2, "date");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIsNull() {
            addCriterion("SettlementDate is null");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIsNotNull() {
            addCriterion("SettlementDate is not null");
            return (Criteria) this;
        }

        public Criteria andSettlementdateEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate =", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate <>", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateGreaterThan(Date value) {
            addCriterionForJDBCDate("SettlementDate >", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate >=", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateLessThan(Date value) {
            addCriterionForJDBCDate("SettlementDate <", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate <=", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIn(List<Date> values) {
            addCriterionForJDBCDate("SettlementDate in", values, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("SettlementDate not in", values, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("SettlementDate between", value1, value2, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("SettlementDate not between", value1, value2, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andCurrencyIsNull() {
            addCriterion("Currency is null");
            return (Criteria) this;
        }

        public Criteria andCurrencyIsNotNull() {
            addCriterion("Currency is not null");
            return (Criteria) this;
        }

        public Criteria andCurrencyEqualTo(String value) {
            addCriterion("Currency =", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotEqualTo(String value) {
            addCriterion("Currency <>", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyGreaterThan(String value) {
            addCriterion("Currency >", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyGreaterThanOrEqualTo(String value) {
            addCriterion("Currency >=", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLessThan(String value) {
            addCriterion("Currency <", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLessThanOrEqualTo(String value) {
            addCriterion("Currency <=", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLike(String value) {
            addCriterion("Currency like", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotLike(String value) {
            addCriterion("Currency not like", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyIn(List<String> values) {
            addCriterion("Currency in", values, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotIn(List<String> values) {
            addCriterion("Currency not in", values, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyBetween(String value1, String value2) {
            addCriterion("Currency between", value1, value2, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotBetween(String value1, String value2) {
            addCriterion("Currency not between", value1, value2, "currency");
            return (Criteria) this;
        }

        public Criteria andBusinclassIsNull() {
            addCriterion("BusinClass is null");
            return (Criteria) this;
        }

        public Criteria andBusinclassIsNotNull() {
            addCriterion("BusinClass is not null");
            return (Criteria) this;
        }

        public Criteria andBusinclassEqualTo(Integer value) {
            addCriterion("BusinClass =", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassNotEqualTo(Integer value) {
            addCriterion("BusinClass <>", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassGreaterThan(Integer value) {
            addCriterion("BusinClass >", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassGreaterThanOrEqualTo(Integer value) {
            addCriterion("BusinClass >=", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassLessThan(Integer value) {
            addCriterion("BusinClass <", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassLessThanOrEqualTo(Integer value) {
            addCriterion("BusinClass <=", value, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassIn(List<Integer> values) {
            addCriterion("BusinClass in", values, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassNotIn(List<Integer> values) {
            addCriterion("BusinClass not in", values, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassBetween(Integer value1, Integer value2) {
            addCriterion("BusinClass between", value1, value2, "businclass");
            return (Criteria) this;
        }

        public Criteria andBusinclassNotBetween(Integer value1, Integer value2) {
            addCriterion("BusinClass not between", value1, value2, "businclass");
            return (Criteria) this;
        }

        public Criteria andAmountIsNull() {
            addCriterion("Amount is null");
            return (Criteria) this;
        }

        public Criteria andAmountIsNotNull() {
            addCriterion("Amount is not null");
            return (Criteria) this;
        }

        public Criteria andAmountEqualTo(BigDecimal value) {
            addCriterion("Amount =", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotEqualTo(BigDecimal value) {
            addCriterion("Amount <>", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThan(BigDecimal value) {
            addCriterion("Amount >", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Amount >=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThan(BigDecimal value) {
            addCriterion("Amount <", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Amount <=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountIn(List<BigDecimal> values) {
            addCriterion("Amount in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotIn(List<BigDecimal> values) {
            addCriterion("Amount not in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Amount between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Amount not between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andIsmarginIsNull() {
            addCriterion("IsMargin is null");
            return (Criteria) this;
        }

        public Criteria andIsmarginIsNotNull() {
            addCriterion("IsMargin is not null");
            return (Criteria) this;
        }

        public Criteria andIsmarginEqualTo(Boolean value) {
            addCriterion("IsMargin =", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginNotEqualTo(Boolean value) {
            addCriterion("IsMargin <>", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginGreaterThan(Boolean value) {
            addCriterion("IsMargin >", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsMargin >=", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginLessThan(Boolean value) {
            addCriterion("IsMargin <", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginLessThanOrEqualTo(Boolean value) {
            addCriterion("IsMargin <=", value, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginIn(List<Boolean> values) {
            addCriterion("IsMargin in", values, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginNotIn(List<Boolean> values) {
            addCriterion("IsMargin not in", values, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginBetween(Boolean value1, Boolean value2) {
            addCriterion("IsMargin between", value1, value2, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIsmarginNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsMargin not between", value1, value2, "ismargin");
            return (Criteria) this;
        }

        public Criteria andIssettledIsNull() {
            addCriterion("IsSettled is null");
            return (Criteria) this;
        }

        public Criteria andIssettledIsNotNull() {
            addCriterion("IsSettled is not null");
            return (Criteria) this;
        }

        public Criteria andIssettledEqualTo(Boolean value) {
            addCriterion("IsSettled =", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledNotEqualTo(Boolean value) {
            addCriterion("IsSettled <>", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledGreaterThan(Boolean value) {
            addCriterion("IsSettled >", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsSettled >=", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledLessThan(Boolean value) {
            addCriterion("IsSettled <", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledLessThanOrEqualTo(Boolean value) {
            addCriterion("IsSettled <=", value, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledIn(List<Boolean> values) {
            addCriterion("IsSettled in", values, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledNotIn(List<Boolean> values) {
            addCriterion("IsSettled not in", values, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledBetween(Boolean value1, Boolean value2) {
            addCriterion("IsSettled between", value1, value2, "issettled");
            return (Criteria) this;
        }

        public Criteria andIssettledNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsSettled not between", value1, value2, "issettled");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("Status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("Status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("Status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("Status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("Status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("Status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("Status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("Status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("Status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("Status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("Status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("Status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andErrormessageIsNull() {
            addCriterion("ErrorMessage is null");
            return (Criteria) this;
        }

        public Criteria andErrormessageIsNotNull() {
            addCriterion("ErrorMessage is not null");
            return (Criteria) this;
        }

        public Criteria andErrormessageEqualTo(String value) {
            addCriterion("ErrorMessage =", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageNotEqualTo(String value) {
            addCriterion("ErrorMessage <>", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageGreaterThan(String value) {
            addCriterion("ErrorMessage >", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageGreaterThanOrEqualTo(String value) {
            addCriterion("ErrorMessage >=", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageLessThan(String value) {
            addCriterion("ErrorMessage <", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageLessThanOrEqualTo(String value) {
            addCriterion("ErrorMessage <=", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageLike(String value) {
            addCriterion("ErrorMessage like", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageNotLike(String value) {
            addCriterion("ErrorMessage not like", value, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageIn(List<String> values) {
            addCriterion("ErrorMessage in", values, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageNotIn(List<String> values) {
            addCriterion("ErrorMessage not in", values, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageBetween(String value1, String value2) {
            addCriterion("ErrorMessage between", value1, value2, "errormessage");
            return (Criteria) this;
        }

        public Criteria andErrormessageNotBetween(String value1, String value2) {
            addCriterion("ErrorMessage not between", value1, value2, "errormessage");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("Comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("Comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(String value) {
            addCriterion("Comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(String value) {
            addCriterion("Comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(String value) {
            addCriterion("Comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(String value) {
            addCriterion("Comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(String value) {
            addCriterion("Comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(String value) {
            addCriterion("Comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLike(String value) {
            addCriterion("Comment like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotLike(String value) {
            addCriterion("Comment not like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<String> values) {
            addCriterion("Comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<String> values) {
            addCriterion("Comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(String value1, String value2) {
            addCriterion("Comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(String value1, String value2) {
            addCriterion("Comment not between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorIsNull() {
            addCriterion("CheckOperator is null");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorIsNotNull() {
            addCriterion("CheckOperator is not null");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorEqualTo(String value) {
            addCriterion("CheckOperator =", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorNotEqualTo(String value) {
            addCriterion("CheckOperator <>", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorGreaterThan(String value) {
            addCriterion("CheckOperator >", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorGreaterThanOrEqualTo(String value) {
            addCriterion("CheckOperator >=", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorLessThan(String value) {
            addCriterion("CheckOperator <", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorLessThanOrEqualTo(String value) {
            addCriterion("CheckOperator <=", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorLike(String value) {
            addCriterion("CheckOperator like", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorNotLike(String value) {
            addCriterion("CheckOperator not like", value, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorIn(List<String> values) {
            addCriterion("CheckOperator in", values, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorNotIn(List<String> values) {
            addCriterion("CheckOperator not in", values, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorBetween(String value1, String value2) {
            addCriterion("CheckOperator between", value1, value2, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andCheckoperatorNotBetween(String value1, String value2) {
            addCriterion("CheckOperator not between", value1, value2, "checkoperator");
            return (Criteria) this;
        }

        public Criteria andChecktimeIsNull() {
            addCriterion("CheckTime is null");
            return (Criteria) this;
        }

        public Criteria andChecktimeIsNotNull() {
            addCriterion("CheckTime is not null");
            return (Criteria) this;
        }

        public Criteria andChecktimeEqualTo(Date value) {
            addCriterion("CheckTime =", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotEqualTo(Date value) {
            addCriterion("CheckTime <>", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeGreaterThan(Date value) {
            addCriterion("CheckTime >", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CheckTime >=", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeLessThan(Date value) {
            addCriterion("CheckTime <", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeLessThanOrEqualTo(Date value) {
            addCriterion("CheckTime <=", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeIn(List<Date> values) {
            addCriterion("CheckTime in", values, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotIn(List<Date> values) {
            addCriterion("CheckTime not in", values, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeBetween(Date value1, Date value2) {
            addCriterion("CheckTime between", value1, value2, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotBetween(Date value1, Date value2) {
            addCriterion("CheckTime not between", value1, value2, "checktime");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorIsNull() {
            addCriterion("SettleOperator is null");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorIsNotNull() {
            addCriterion("SettleOperator is not null");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorEqualTo(String value) {
            addCriterion("SettleOperator =", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorNotEqualTo(String value) {
            addCriterion("SettleOperator <>", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorGreaterThan(String value) {
            addCriterion("SettleOperator >", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorGreaterThanOrEqualTo(String value) {
            addCriterion("SettleOperator >=", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorLessThan(String value) {
            addCriterion("SettleOperator <", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorLessThanOrEqualTo(String value) {
            addCriterion("SettleOperator <=", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorLike(String value) {
            addCriterion("SettleOperator like", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorNotLike(String value) {
            addCriterion("SettleOperator not like", value, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorIn(List<String> values) {
            addCriterion("SettleOperator in", values, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorNotIn(List<String> values) {
            addCriterion("SettleOperator not in", values, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorBetween(String value1, String value2) {
            addCriterion("SettleOperator between", value1, value2, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettleoperatorNotBetween(String value1, String value2) {
            addCriterion("SettleOperator not between", value1, value2, "settleoperator");
            return (Criteria) this;
        }

        public Criteria andSettletimeIsNull() {
            addCriterion("SettleTime is null");
            return (Criteria) this;
        }

        public Criteria andSettletimeIsNotNull() {
            addCriterion("SettleTime is not null");
            return (Criteria) this;
        }

        public Criteria andSettletimeEqualTo(Date value) {
            addCriterion("SettleTime =", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeNotEqualTo(Date value) {
            addCriterion("SettleTime <>", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeGreaterThan(Date value) {
            addCriterion("SettleTime >", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeGreaterThanOrEqualTo(Date value) {
            addCriterion("SettleTime >=", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeLessThan(Date value) {
            addCriterion("SettleTime <", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeLessThanOrEqualTo(Date value) {
            addCriterion("SettleTime <=", value, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeIn(List<Date> values) {
            addCriterion("SettleTime in", values, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeNotIn(List<Date> values) {
            addCriterion("SettleTime not in", values, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeBetween(Date value1, Date value2) {
            addCriterion("SettleTime between", value1, value2, "settletime");
            return (Criteria) this;
        }

        public Criteria andSettletimeNotBetween(Date value1, Date value2) {
            addCriterion("SettleTime not between", value1, value2, "settletime");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNull() {
            addCriterion("LastUpdateUser is null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNotNull() {
            addCriterion("LastUpdateUser is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserEqualTo(String value) {
            addCriterion("LastUpdateUser =", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotEqualTo(String value) {
            addCriterion("LastUpdateUser <>", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThan(String value) {
            addCriterion("LastUpdateUser >", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser >=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThan(String value) {
            addCriterion("LastUpdateUser <", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser <=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLike(String value) {
            addCriterion("LastUpdateUser like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotLike(String value) {
            addCriterion("LastUpdateUser not like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIn(List<String> values) {
            addCriterion("LastUpdateUser in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotIn(List<String> values) {
            addCriterion("LastUpdateUser not in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserBetween(String value1, String value2) {
            addCriterion("LastUpdateUser between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotBetween(String value1, String value2) {
            addCriterion("LastUpdateUser not between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("LastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("LastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("LastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("LastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("LastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("LastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("LastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("LastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}