package com.modules.calendar;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.calendar.dao.CalendarModelMapper;
import com.modules.calendar.model.CalendarModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CalendarCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CalendarModelMapper sourcemapper = GetDataSource.getMapper(CalendarModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CalendarModelMapper targetmapper = GetDataSource.getMapper(CalendarModelMapper.class, sessionqa);
		
		
		List<CalendarModel> source = sourcemapper.selectByExample(null);
		List<CalendarModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CalendarModel> same = new ArrayList<CalendarModel>();
		for(CalendarModel targetmodel : target){
			for(CalendarModel sourcemodel : source){
				if(targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())&&targetmodel.getDay().equals(sourcemodel.getDay())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		target.removeAll(same);
		System.out.println("targetdifferent=========================" + target.size());
		
		try {
			targetmapper.deleteByExample(null);
			
			
			for(CalendarModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CalendarModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CalendarCompare().compare();
	}


}
