package com.modules.calendar.dao;

import com.modules.calendar.model.CalendarModel;
import com.modules.calendar.model.CalendarModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CalendarModelMapper {
    int countByExample(CalendarModelExample example);

    int deleteByExample(CalendarModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CalendarModel record);

    int insertSelective(CalendarModel record);

    List<CalendarModel> selectByExample(CalendarModelExample example);

    CalendarModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CalendarModel record, @Param("example") CalendarModelExample example);

    int updateByExample(@Param("record") CalendarModel record, @Param("example") CalendarModelExample example);

    int updateByPrimaryKeySelective(CalendarModel record);

    int updateByPrimaryKey(CalendarModel record);
}