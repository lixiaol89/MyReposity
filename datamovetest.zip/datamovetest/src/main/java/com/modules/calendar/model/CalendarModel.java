package com.modules.calendar.model;

import java.util.Date;

public class CalendarModel {
    private Integer id;

    private String exchangecode;

    private Date day;

    private Boolean trading;

    private Boolean settling;

    private Boolean holiday;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExchangecode() {
        return exchangecode;
    }

    public void setExchangecode(String exchangecode) {
        this.exchangecode = exchangecode == null ? null : exchangecode.trim();
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    public Boolean getTrading() {
        return trading;
    }

    public void setTrading(Boolean trading) {
        this.trading = trading;
    }

    public Boolean getSettling() {
        return settling;
    }

    public void setSettling(Boolean settling) {
        this.settling = settling;
    }

    public Boolean getHoliday() {
        return holiday;
    }

    public void setHoliday(Boolean holiday) {
        this.holiday = holiday;
    }
}