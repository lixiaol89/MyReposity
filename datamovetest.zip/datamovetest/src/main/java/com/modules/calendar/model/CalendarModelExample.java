package com.modules.calendar.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CalendarModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CalendarModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIsNull() {
            addCriterion("ExchangeCode is null");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIsNotNull() {
            addCriterion("ExchangeCode is not null");
            return (Criteria) this;
        }

        public Criteria andExchangecodeEqualTo(String value) {
            addCriterion("ExchangeCode =", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotEqualTo(String value) {
            addCriterion("ExchangeCode <>", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeGreaterThan(String value) {
            addCriterion("ExchangeCode >", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeGreaterThanOrEqualTo(String value) {
            addCriterion("ExchangeCode >=", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLessThan(String value) {
            addCriterion("ExchangeCode <", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLessThanOrEqualTo(String value) {
            addCriterion("ExchangeCode <=", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLike(String value) {
            addCriterion("ExchangeCode like", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotLike(String value) {
            addCriterion("ExchangeCode not like", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIn(List<String> values) {
            addCriterion("ExchangeCode in", values, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotIn(List<String> values) {
            addCriterion("ExchangeCode not in", values, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeBetween(String value1, String value2) {
            addCriterion("ExchangeCode between", value1, value2, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotBetween(String value1, String value2) {
            addCriterion("ExchangeCode not between", value1, value2, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andDayIsNull() {
            addCriterion("Day is null");
            return (Criteria) this;
        }

        public Criteria andDayIsNotNull() {
            addCriterion("Day is not null");
            return (Criteria) this;
        }

        public Criteria andDayEqualTo(Date value) {
            addCriterionForJDBCDate("Day =", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotEqualTo(Date value) {
            addCriterionForJDBCDate("Day <>", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThan(Date value) {
            addCriterionForJDBCDate("Day >", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("Day >=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThan(Date value) {
            addCriterionForJDBCDate("Day <", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("Day <=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayIn(List<Date> values) {
            addCriterionForJDBCDate("Day in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotIn(List<Date> values) {
            addCriterionForJDBCDate("Day not in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("Day between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("Day not between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andTradingIsNull() {
            addCriterion("Trading is null");
            return (Criteria) this;
        }

        public Criteria andTradingIsNotNull() {
            addCriterion("Trading is not null");
            return (Criteria) this;
        }

        public Criteria andTradingEqualTo(Boolean value) {
            addCriterion("Trading =", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingNotEqualTo(Boolean value) {
            addCriterion("Trading <>", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingGreaterThan(Boolean value) {
            addCriterion("Trading >", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingGreaterThanOrEqualTo(Boolean value) {
            addCriterion("Trading >=", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingLessThan(Boolean value) {
            addCriterion("Trading <", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingLessThanOrEqualTo(Boolean value) {
            addCriterion("Trading <=", value, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingIn(List<Boolean> values) {
            addCriterion("Trading in", values, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingNotIn(List<Boolean> values) {
            addCriterion("Trading not in", values, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingBetween(Boolean value1, Boolean value2) {
            addCriterion("Trading between", value1, value2, "trading");
            return (Criteria) this;
        }

        public Criteria andTradingNotBetween(Boolean value1, Boolean value2) {
            addCriterion("Trading not between", value1, value2, "trading");
            return (Criteria) this;
        }

        public Criteria andSettlingIsNull() {
            addCriterion("Settling is null");
            return (Criteria) this;
        }

        public Criteria andSettlingIsNotNull() {
            addCriterion("Settling is not null");
            return (Criteria) this;
        }

        public Criteria andSettlingEqualTo(Boolean value) {
            addCriterion("Settling =", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingNotEqualTo(Boolean value) {
            addCriterion("Settling <>", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingGreaterThan(Boolean value) {
            addCriterion("Settling >", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingGreaterThanOrEqualTo(Boolean value) {
            addCriterion("Settling >=", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingLessThan(Boolean value) {
            addCriterion("Settling <", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingLessThanOrEqualTo(Boolean value) {
            addCriterion("Settling <=", value, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingIn(List<Boolean> values) {
            addCriterion("Settling in", values, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingNotIn(List<Boolean> values) {
            addCriterion("Settling not in", values, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingBetween(Boolean value1, Boolean value2) {
            addCriterion("Settling between", value1, value2, "settling");
            return (Criteria) this;
        }

        public Criteria andSettlingNotBetween(Boolean value1, Boolean value2) {
            addCriterion("Settling not between", value1, value2, "settling");
            return (Criteria) this;
        }

        public Criteria andHolidayIsNull() {
            addCriterion("Holiday is null");
            return (Criteria) this;
        }

        public Criteria andHolidayIsNotNull() {
            addCriterion("Holiday is not null");
            return (Criteria) this;
        }

        public Criteria andHolidayEqualTo(Boolean value) {
            addCriterion("Holiday =", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotEqualTo(Boolean value) {
            addCriterion("Holiday <>", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayGreaterThan(Boolean value) {
            addCriterion("Holiday >", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayGreaterThanOrEqualTo(Boolean value) {
            addCriterion("Holiday >=", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayLessThan(Boolean value) {
            addCriterion("Holiday <", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayLessThanOrEqualTo(Boolean value) {
            addCriterion("Holiday <=", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayIn(List<Boolean> values) {
            addCriterion("Holiday in", values, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotIn(List<Boolean> values) {
            addCriterion("Holiday not in", values, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayBetween(Boolean value1, Boolean value2) {
            addCriterion("Holiday between", value1, value2, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotBetween(Boolean value1, Boolean value2) {
            addCriterion("Holiday not between", value1, value2, "holiday");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}