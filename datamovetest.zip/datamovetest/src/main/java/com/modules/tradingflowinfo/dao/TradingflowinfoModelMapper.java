package com.modules.tradingflowinfo.dao;

import com.modules.tradingflowinfo.model.TradingflowinfoModel;
import com.modules.tradingflowinfo.model.TradingflowinfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TradingflowinfoModelMapper {
    int countByExample(TradingflowinfoModelExample example);

    int deleteByExample(TradingflowinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TradingflowinfoModel record);

    int insertSelective(TradingflowinfoModel record);

    List<TradingflowinfoModel> selectByExample(TradingflowinfoModelExample example);

    TradingflowinfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TradingflowinfoModel record, @Param("example") TradingflowinfoModelExample example);

    int updateByExample(@Param("record") TradingflowinfoModel record, @Param("example") TradingflowinfoModelExample example);

    int updateByPrimaryKeySelective(TradingflowinfoModel record);

    int updateByPrimaryKey(TradingflowinfoModel record);
}