package com.modules.tradingflowinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.tradingflowinfo.dao.TradingflowinfoModelMapper;
import com.modules.tradingflowinfo.model.TradingflowinfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class TradingflowinfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		TradingflowinfoModelMapper sourcemapper = GetDataSource.getMapper(TradingflowinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		TradingflowinfoModelMapper targetmapper = GetDataSource.getMapper(TradingflowinfoModelMapper.class, sessionqa);
		
		
		List<TradingflowinfoModel> source = sourcemapper.selectByExample(null);
		List<TradingflowinfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<TradingflowinfoModel> same = new ArrayList<TradingflowinfoModel>();
		for(TradingflowinfoModel targetmodel : target){
			for(TradingflowinfoModel sourcemodel : source){
				if(targetmodel.getTradedate().equals(sourcemodel.getTradedate())&&
						targetmodel.getTradeid().equals(sourcemodel.getTradeid())&&
						targetmodel.getTradingflowno().equals(sourcemodel.getTradingflowno())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(TradingflowinfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(TradingflowinfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new TradingflowinfoCompare().compare();
	}


}
