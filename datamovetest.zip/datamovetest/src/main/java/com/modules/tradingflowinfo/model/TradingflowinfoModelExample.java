package com.modules.tradingflowinfo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class TradingflowinfoModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TradingflowinfoModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTradedateIsNull() {
            addCriterion("TradeDate is null");
            return (Criteria) this;
        }

        public Criteria andTradedateIsNotNull() {
            addCriterion("TradeDate is not null");
            return (Criteria) this;
        }

        public Criteria andTradedateEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate =", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate <>", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateGreaterThan(Date value) {
            addCriterionForJDBCDate("TradeDate >", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate >=", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateLessThan(Date value) {
            addCriterionForJDBCDate("TradeDate <", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate <=", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateIn(List<Date> values) {
            addCriterionForJDBCDate("TradeDate in", values, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("TradeDate not in", values, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("TradeDate between", value1, value2, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("TradeDate not between", value1, value2, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradingflownoIsNull() {
            addCriterion("TradingFlowNo is null");
            return (Criteria) this;
        }

        public Criteria andTradingflownoIsNotNull() {
            addCriterion("TradingFlowNo is not null");
            return (Criteria) this;
        }

        public Criteria andTradingflownoEqualTo(String value) {
            addCriterion("TradingFlowNo =", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoNotEqualTo(String value) {
            addCriterion("TradingFlowNo <>", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoGreaterThan(String value) {
            addCriterion("TradingFlowNo >", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoGreaterThanOrEqualTo(String value) {
            addCriterion("TradingFlowNo >=", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoLessThan(String value) {
            addCriterion("TradingFlowNo <", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoLessThanOrEqualTo(String value) {
            addCriterion("TradingFlowNo <=", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoLike(String value) {
            addCriterion("TradingFlowNo like", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoNotLike(String value) {
            addCriterion("TradingFlowNo not like", value, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoIn(List<String> values) {
            addCriterion("TradingFlowNo in", values, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoNotIn(List<String> values) {
            addCriterion("TradingFlowNo not in", values, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoBetween(String value1, String value2) {
            addCriterion("TradingFlowNo between", value1, value2, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andTradingflownoNotBetween(String value1, String value2) {
            addCriterion("TradingFlowNo not between", value1, value2, "tradingflowno");
            return (Criteria) this;
        }

        public Criteria andPositionIsNull() {
            addCriterion("Position is null");
            return (Criteria) this;
        }

        public Criteria andPositionIsNotNull() {
            addCriterion("Position is not null");
            return (Criteria) this;
        }

        public Criteria andPositionEqualTo(BigDecimal value) {
            addCriterion("Position =", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotEqualTo(BigDecimal value) {
            addCriterion("Position <>", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionGreaterThan(BigDecimal value) {
            addCriterion("Position >", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Position >=", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionLessThan(BigDecimal value) {
            addCriterion("Position <", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Position <=", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionIn(List<BigDecimal> values) {
            addCriterion("Position in", values, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotIn(List<BigDecimal> values) {
            addCriterion("Position not in", values, "position");
            return (Criteria) this;
        }

        public Criteria andPositionBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Position between", value1, value2, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Position not between", value1, value2, "position");
            return (Criteria) this;
        }

        public Criteria andTradepriceIsNull() {
            addCriterion("TradePrice is null");
            return (Criteria) this;
        }

        public Criteria andTradepriceIsNotNull() {
            addCriterion("TradePrice is not null");
            return (Criteria) this;
        }

        public Criteria andTradepriceEqualTo(BigDecimal value) {
            addCriterion("TradePrice =", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotEqualTo(BigDecimal value) {
            addCriterion("TradePrice <>", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceGreaterThan(BigDecimal value) {
            addCriterion("TradePrice >", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TradePrice >=", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceLessThan(BigDecimal value) {
            addCriterion("TradePrice <", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TradePrice <=", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceIn(List<BigDecimal> values) {
            addCriterion("TradePrice in", values, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotIn(List<BigDecimal> values) {
            addCriterion("TradePrice not in", values, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TradePrice between", value1, value2, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TradePrice not between", value1, value2, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNull() {
            addCriterion("LastUpdateUser is null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNotNull() {
            addCriterion("LastUpdateUser is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserEqualTo(String value) {
            addCriterion("LastUpdateUser =", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotEqualTo(String value) {
            addCriterion("LastUpdateUser <>", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThan(String value) {
            addCriterion("LastUpdateUser >", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser >=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThan(String value) {
            addCriterion("LastUpdateUser <", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser <=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLike(String value) {
            addCriterion("LastUpdateUser like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotLike(String value) {
            addCriterion("LastUpdateUser not like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIn(List<String> values) {
            addCriterion("LastUpdateUser in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotIn(List<String> values) {
            addCriterion("LastUpdateUser not in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserBetween(String value1, String value2) {
            addCriterion("LastUpdateUser between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotBetween(String value1, String value2) {
            addCriterion("LastUpdateUser not between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("LastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("LastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("LastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("LastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("LastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("LastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("LastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("LastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}