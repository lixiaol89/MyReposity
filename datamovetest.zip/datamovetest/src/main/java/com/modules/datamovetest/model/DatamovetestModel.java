package com.modules.datamovetest.model;

import java.math.BigDecimal;
import java.util.Date;

public class DatamovetestModel {
    private Integer id;

    private String name;

    private BigDecimal money;

    private Byte op;

    private Integer nu;

    private Date dtime;

    private Date ddate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Byte getOp() {
        return op;
    }

    public void setOp(Byte op) {
        this.op = op;
    }

    public Integer getNu() {
        return nu;
    }

    public void setNu(Integer nu) {
        this.nu = nu;
    }

    public Date getDtime() {
        return dtime;
    }

    public void setDtime(Date dtime) {
        this.dtime = dtime;
    }

    public Date getDdate() {
        return ddate;
    }

    public void setDdate(Date ddate) {
        this.ddate = ddate;
    }
}