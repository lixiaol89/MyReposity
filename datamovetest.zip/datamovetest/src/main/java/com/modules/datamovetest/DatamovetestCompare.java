package com.modules.datamovetest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.datamovetest.dao.DatamovetestModelMapper;
import com.modules.datamovetest.model.DatamovetestModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class DatamovetestCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		DatamovetestModelMapper sourcemapper = GetDataSource.getMapper(DatamovetestModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		DatamovetestModelMapper targetmapper = GetDataSource.getMapper(DatamovetestModelMapper.class, sessionqa);
		
		
		List<DatamovetestModel> source = sourcemapper.selectByExample(null);
		List<DatamovetestModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<DatamovetestModel> same = new ArrayList<DatamovetestModel>();
		for(DatamovetestModel targetmodel : target){
			for(DatamovetestModel sourcemodel : source){
				if(targetmodel.getMoney().equals(sourcemodel.getMoney()) && targetmodel.getName().equals(sourcemodel.getName())&&targetmodel.getOp()==sourcemodel.getOp()){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(DatamovetestModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(DatamovetestModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new DatamovetestCompare().compare();
	}


}
