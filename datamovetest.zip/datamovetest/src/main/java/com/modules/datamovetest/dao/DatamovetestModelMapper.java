package com.modules.datamovetest.dao;

import com.modules.datamovetest.model.DatamovetestModel;
import com.modules.datamovetest.model.DatamovetestModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DatamovetestModelMapper {
    int countByExample(DatamovetestModelExample example);

    int deleteByExample(DatamovetestModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DatamovetestModel record);

    int insertSelective(DatamovetestModel record);

    List<DatamovetestModel> selectByExample(DatamovetestModelExample example);

    DatamovetestModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DatamovetestModel record, @Param("example") DatamovetestModelExample example);

    int updateByExample(@Param("record") DatamovetestModel record, @Param("example") DatamovetestModelExample example);

    int updateByPrimaryKeySelective(DatamovetestModel record);

    int updateByPrimaryKey(DatamovetestModel record);
}