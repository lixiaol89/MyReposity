package com.modules.optionportfolio.dao;

import com.modules.optionportfolio.model.OptionportfolioModel;
import com.modules.optionportfolio.model.OptionportfolioModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OptionportfolioModelMapper {
    int countByExample(OptionportfolioModelExample example);

    int deleteByExample(OptionportfolioModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(OptionportfolioModel record);

    int insertSelective(OptionportfolioModel record);

    List<OptionportfolioModel> selectByExampleWithBLOBs(OptionportfolioModelExample example);

    List<OptionportfolioModel> selectByExample(OptionportfolioModelExample example);

    OptionportfolioModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") OptionportfolioModel record, @Param("example") OptionportfolioModelExample example);

    int updateByExampleWithBLOBs(@Param("record") OptionportfolioModel record, @Param("example") OptionportfolioModelExample example);

    int updateByExample(@Param("record") OptionportfolioModel record, @Param("example") OptionportfolioModelExample example);

    int updateByPrimaryKeySelective(OptionportfolioModel record);

    int updateByPrimaryKeyWithBLOBs(OptionportfolioModel record);

    int updateByPrimaryKey(OptionportfolioModel record);
}