package com.modules.optionportfolio.model;

import java.math.BigDecimal;
import java.util.Date;

public class OptionportfolioModel {
    private Integer id;

    private String tradeid;

    private String lastupdateuser;

    private Date lastupdatetime;

    private BigDecimal maturityprincipal;

    private String optportfolio;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }

    public BigDecimal getMaturityprincipal() {
        return maturityprincipal;
    }

    public void setMaturityprincipal(BigDecimal maturityprincipal) {
        this.maturityprincipal = maturityprincipal;
    }

    public String getOptportfolio() {
        return optportfolio;
    }

    public void setOptportfolio(String optportfolio) {
        this.optportfolio = optportfolio == null ? null : optportfolio.trim();
    }
}