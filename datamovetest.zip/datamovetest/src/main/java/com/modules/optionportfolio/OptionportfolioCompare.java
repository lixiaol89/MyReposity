package com.modules.optionportfolio;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.optionportfolio.dao.OptionportfolioModelMapper;
import com.modules.optionportfolio.model.OptionportfolioModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class OptionportfolioCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		OptionportfolioModelMapper sourcemapper = GetDataSource.getMapper(OptionportfolioModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		OptionportfolioModelMapper targetmapper = GetDataSource.getMapper(OptionportfolioModelMapper.class, sessionqa);
		
		
		List<OptionportfolioModel> source = sourcemapper.selectByExample(null);
		List<OptionportfolioModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<OptionportfolioModel> same = new ArrayList<OptionportfolioModel>();
		for(OptionportfolioModel targetmodel : target){
			for(OptionportfolioModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(OptionportfolioModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(OptionportfolioModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new OptionportfolioCompare().compare();
	}


}
