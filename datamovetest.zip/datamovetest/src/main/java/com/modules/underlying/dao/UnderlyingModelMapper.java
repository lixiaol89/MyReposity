package com.modules.underlying.dao;

import com.modules.underlying.model.UnderlyingModel;
import com.modules.underlying.model.UnderlyingModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UnderlyingModelMapper {
    int countByExample(UnderlyingModelExample example);

    int deleteByExample(UnderlyingModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(UnderlyingModel record);

    int insertSelective(UnderlyingModel record);

    List<UnderlyingModel> selectByExample(UnderlyingModelExample example);

    UnderlyingModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") UnderlyingModel record, @Param("example") UnderlyingModelExample example);

    int updateByExample(@Param("record") UnderlyingModel record, @Param("example") UnderlyingModelExample example);

    int updateByPrimaryKeySelective(UnderlyingModel record);

    int updateByPrimaryKey(UnderlyingModel record);
}