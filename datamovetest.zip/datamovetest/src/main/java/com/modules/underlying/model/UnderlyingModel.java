package com.modules.underlying.model;

import java.math.BigDecimal;
import java.util.Date;

public class UnderlyingModel {
    private Integer id;

    private String underlying;

    private String currency;

    private String exchangecode;

    private BigDecimal vardown;

    private BigDecimal varup;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public String getExchangecode() {
        return exchangecode;
    }

    public void setExchangecode(String exchangecode) {
        this.exchangecode = exchangecode == null ? null : exchangecode.trim();
    }

    public BigDecimal getVardown() {
        return vardown;
    }

    public void setVardown(BigDecimal vardown) {
        this.vardown = vardown;
    }

    public BigDecimal getVarup() {
        return varup;
    }

    public void setVarup(BigDecimal varup) {
        this.varup = varup;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}