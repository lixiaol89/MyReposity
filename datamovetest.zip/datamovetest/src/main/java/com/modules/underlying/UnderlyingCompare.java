package com.modules.underlying;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.underlying.dao.UnderlyingModelMapper;
import com.modules.underlying.model.UnderlyingModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class UnderlyingCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		UnderlyingModelMapper sourcemapper = GetDataSource.getMapper(UnderlyingModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		UnderlyingModelMapper targetmapper = GetDataSource.getMapper(UnderlyingModelMapper.class, sessionqa);
		
		
		List<UnderlyingModel> source = sourcemapper.selectByExample(null);
		List<UnderlyingModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<UnderlyingModel> same = new ArrayList<UnderlyingModel>();
		for(UnderlyingModel targetmodel : target){
			for(UnderlyingModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())&&
						targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(UnderlyingModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(UnderlyingModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new UnderlyingCompare().compare();
	}


}
