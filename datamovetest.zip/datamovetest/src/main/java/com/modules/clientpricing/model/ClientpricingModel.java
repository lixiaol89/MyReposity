package com.modules.clientpricing.model;

import java.math.BigDecimal;

public class ClientpricingModel {
    private Integer id;

    private String clientid;

    private String templatetype;

    private Integer longshort;

    private BigDecimal quota;

    private String settleccy;

    private String salesid;

    private BigDecimal edge;

    private BigDecimal initalmargin;

    private BigDecimal marginwarninglevel;

    private BigDecimal margincalllevel;

    private BigDecimal liquiditionlevel;

    private Boolean marginnet;

    private BigDecimal leverage;

    private BigDecimal fundingrate;

    private String fundingccy;

    private BigDecimal commission;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClientid() {
        return clientid;
    }

    public void setClientid(String clientid) {
        this.clientid = clientid == null ? null : clientid.trim();
    }

    public String getTemplatetype() {
        return templatetype;
    }

    public void setTemplatetype(String templatetype) {
        this.templatetype = templatetype == null ? null : templatetype.trim();
    }

    public Integer getLongshort() {
        return longshort;
    }

    public void setLongshort(Integer longshort) {
        this.longshort = longshort;
    }

    public BigDecimal getQuota() {
        return quota;
    }

    public void setQuota(BigDecimal quota) {
        this.quota = quota;
    }

    public String getSettleccy() {
        return settleccy;
    }

    public void setSettleccy(String settleccy) {
        this.settleccy = settleccy == null ? null : settleccy.trim();
    }

    public String getSalesid() {
        return salesid;
    }

    public void setSalesid(String salesid) {
        this.salesid = salesid == null ? null : salesid.trim();
    }

    public BigDecimal getEdge() {
        return edge;
    }

    public void setEdge(BigDecimal edge) {
        this.edge = edge;
    }

    public BigDecimal getInitalmargin() {
        return initalmargin;
    }

    public void setInitalmargin(BigDecimal initalmargin) {
        this.initalmargin = initalmargin;
    }

    public BigDecimal getMarginwarninglevel() {
        return marginwarninglevel;
    }

    public void setMarginwarninglevel(BigDecimal marginwarninglevel) {
        this.marginwarninglevel = marginwarninglevel;
    }

    public BigDecimal getMargincalllevel() {
        return margincalllevel;
    }

    public void setMargincalllevel(BigDecimal margincalllevel) {
        this.margincalllevel = margincalllevel;
    }

    public BigDecimal getLiquiditionlevel() {
        return liquiditionlevel;
    }

    public void setLiquiditionlevel(BigDecimal liquiditionlevel) {
        this.liquiditionlevel = liquiditionlevel;
    }

    public Boolean getMarginnet() {
        return marginnet;
    }

    public void setMarginnet(Boolean marginnet) {
        this.marginnet = marginnet;
    }

    public BigDecimal getLeverage() {
        return leverage;
    }

    public void setLeverage(BigDecimal leverage) {
        this.leverage = leverage;
    }

    public BigDecimal getFundingrate() {
        return fundingrate;
    }

    public void setFundingrate(BigDecimal fundingrate) {
        this.fundingrate = fundingrate;
    }

    public String getFundingccy() {
        return fundingccy;
    }

    public void setFundingccy(String fundingccy) {
        this.fundingccy = fundingccy == null ? null : fundingccy.trim();
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }
}