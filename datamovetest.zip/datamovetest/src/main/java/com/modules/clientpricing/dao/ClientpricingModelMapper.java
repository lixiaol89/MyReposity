package com.modules.clientpricing.dao;

import com.modules.clientpricing.model.ClientpricingModel;
import com.modules.clientpricing.model.ClientpricingModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ClientpricingModelMapper {
    int countByExample(ClientpricingModelExample example);

    int deleteByExample(ClientpricingModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ClientpricingModel record);

    int insertSelective(ClientpricingModel record);

    List<ClientpricingModel> selectByExample(ClientpricingModelExample example);

    ClientpricingModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ClientpricingModel record, @Param("example") ClientpricingModelExample example);

    int updateByExample(@Param("record") ClientpricingModel record, @Param("example") ClientpricingModelExample example);

    int updateByPrimaryKeySelective(ClientpricingModel record);

    int updateByPrimaryKey(ClientpricingModel record);
}