package com.modules.clientpricing;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.clientpricing.dao.ClientpricingModelMapper;
import com.modules.clientpricing.model.ClientpricingModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class ClientpricingCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		ClientpricingModelMapper sourcemapper = GetDataSource.getMapper(ClientpricingModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		ClientpricingModelMapper targetmapper = GetDataSource.getMapper(ClientpricingModelMapper.class, sessionqa);
		
		
		List<ClientpricingModel> source = sourcemapper.selectByExample(null);
		List<ClientpricingModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<ClientpricingModel> same = new ArrayList<ClientpricingModel>();
		for(ClientpricingModel targetmodel : target){
			for(ClientpricingModel sourcemodel : source){
				if(targetmodel.getClientid().equals(sourcemodel.getClientid())&&targetmodel.getTemplatetype().equals(sourcemodel.getTemplatetype())&&targetmodel.getLongshort()==sourcemodel.getLongshort()){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(ClientpricingModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(ClientpricingModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new ClientpricingCompare().compare();
	}


}
