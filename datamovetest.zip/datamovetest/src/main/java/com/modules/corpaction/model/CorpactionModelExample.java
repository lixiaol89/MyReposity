package com.modules.corpaction.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CorpactionModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CorpactionModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUnderlyingIsNull() {
            addCriterion("Underlying is null");
            return (Criteria) this;
        }

        public Criteria andUnderlyingIsNotNull() {
            addCriterion("Underlying is not null");
            return (Criteria) this;
        }

        public Criteria andUnderlyingEqualTo(String value) {
            addCriterion("Underlying =", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingNotEqualTo(String value) {
            addCriterion("Underlying <>", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingGreaterThan(String value) {
            addCriterion("Underlying >", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingGreaterThanOrEqualTo(String value) {
            addCriterion("Underlying >=", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingLessThan(String value) {
            addCriterion("Underlying <", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingLessThanOrEqualTo(String value) {
            addCriterion("Underlying <=", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingLike(String value) {
            addCriterion("Underlying like", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingNotLike(String value) {
            addCriterion("Underlying not like", value, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingIn(List<String> values) {
            addCriterion("Underlying in", values, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingNotIn(List<String> values) {
            addCriterion("Underlying not in", values, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingBetween(String value1, String value2) {
            addCriterion("Underlying between", value1, value2, "underlying");
            return (Criteria) this;
        }

        public Criteria andUnderlyingNotBetween(String value1, String value2) {
            addCriterion("Underlying not between", value1, value2, "underlying");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIsNull() {
            addCriterion("ExchangeCode is null");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIsNotNull() {
            addCriterion("ExchangeCode is not null");
            return (Criteria) this;
        }

        public Criteria andExchangecodeEqualTo(String value) {
            addCriterion("ExchangeCode =", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotEqualTo(String value) {
            addCriterion("ExchangeCode <>", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeGreaterThan(String value) {
            addCriterion("ExchangeCode >", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeGreaterThanOrEqualTo(String value) {
            addCriterion("ExchangeCode >=", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLessThan(String value) {
            addCriterion("ExchangeCode <", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLessThanOrEqualTo(String value) {
            addCriterion("ExchangeCode <=", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeLike(String value) {
            addCriterion("ExchangeCode like", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotLike(String value) {
            addCriterion("ExchangeCode not like", value, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeIn(List<String> values) {
            addCriterion("ExchangeCode in", values, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotIn(List<String> values) {
            addCriterion("ExchangeCode not in", values, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeBetween(String value1, String value2) {
            addCriterion("ExchangeCode between", value1, value2, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andExchangecodeNotBetween(String value1, String value2) {
            addCriterion("ExchangeCode not between", value1, value2, "exchangecode");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeIsNull() {
            addCriterion("BusinessType is null");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeIsNotNull() {
            addCriterion("BusinessType is not null");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeEqualTo(String value) {
            addCriterion("BusinessType =", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeNotEqualTo(String value) {
            addCriterion("BusinessType <>", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeGreaterThan(String value) {
            addCriterion("BusinessType >", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeGreaterThanOrEqualTo(String value) {
            addCriterion("BusinessType >=", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeLessThan(String value) {
            addCriterion("BusinessType <", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeLessThanOrEqualTo(String value) {
            addCriterion("BusinessType <=", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeLike(String value) {
            addCriterion("BusinessType like", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeNotLike(String value) {
            addCriterion("BusinessType not like", value, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeIn(List<String> values) {
            addCriterion("BusinessType in", values, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeNotIn(List<String> values) {
            addCriterion("BusinessType not in", values, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeBetween(String value1, String value2) {
            addCriterion("BusinessType between", value1, value2, "businesstype");
            return (Criteria) this;
        }

        public Criteria andBusinesstypeNotBetween(String value1, String value2) {
            addCriterion("BusinessType not between", value1, value2, "businesstype");
            return (Criteria) this;
        }

        public Criteria andExrightdateIsNull() {
            addCriterion("ExRightDate is null");
            return (Criteria) this;
        }

        public Criteria andExrightdateIsNotNull() {
            addCriterion("ExRightDate is not null");
            return (Criteria) this;
        }

        public Criteria andExrightdateEqualTo(Date value) {
            addCriterionForJDBCDate("ExRightDate =", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("ExRightDate <>", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateGreaterThan(Date value) {
            addCriterionForJDBCDate("ExRightDate >", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ExRightDate >=", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateLessThan(Date value) {
            addCriterionForJDBCDate("ExRightDate <", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ExRightDate <=", value, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateIn(List<Date> values) {
            addCriterionForJDBCDate("ExRightDate in", values, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("ExRightDate not in", values, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ExRightDate between", value1, value2, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andExrightdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ExRightDate not between", value1, value2, "exrightdate");
            return (Criteria) this;
        }

        public Criteria andArrivedateIsNull() {
            addCriterion("ArriveDate is null");
            return (Criteria) this;
        }

        public Criteria andArrivedateIsNotNull() {
            addCriterion("ArriveDate is not null");
            return (Criteria) this;
        }

        public Criteria andArrivedateEqualTo(Date value) {
            addCriterionForJDBCDate("ArriveDate =", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("ArriveDate <>", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateGreaterThan(Date value) {
            addCriterionForJDBCDate("ArriveDate >", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ArriveDate >=", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateLessThan(Date value) {
            addCriterionForJDBCDate("ArriveDate <", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ArriveDate <=", value, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateIn(List<Date> values) {
            addCriterionForJDBCDate("ArriveDate in", values, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("ArriveDate not in", values, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ArriveDate between", value1, value2, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andArrivedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ArriveDate not between", value1, value2, "arrivedate");
            return (Criteria) this;
        }

        public Criteria andAmountIsNull() {
            addCriterion("Amount is null");
            return (Criteria) this;
        }

        public Criteria andAmountIsNotNull() {
            addCriterion("Amount is not null");
            return (Criteria) this;
        }

        public Criteria andAmountEqualTo(BigDecimal value) {
            addCriterion("Amount =", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotEqualTo(BigDecimal value) {
            addCriterion("Amount <>", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThan(BigDecimal value) {
            addCriterion("Amount >", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Amount >=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThan(BigDecimal value) {
            addCriterion("Amount <", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Amount <=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountIn(List<BigDecimal> values) {
            addCriterion("Amount in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotIn(List<BigDecimal> values) {
            addCriterion("Amount not in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Amount between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Amount not between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("Price is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("Price is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(BigDecimal value) {
            addCriterion("Price =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(BigDecimal value) {
            addCriterion("Price <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(BigDecimal value) {
            addCriterion("Price >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Price >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(BigDecimal value) {
            addCriterion("Price <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Price <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<BigDecimal> values) {
            addCriterion("Price in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<BigDecimal> values) {
            addCriterion("Price not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Price between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Price not between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andScaleIsNull() {
            addCriterion("Scale is null");
            return (Criteria) this;
        }

        public Criteria andScaleIsNotNull() {
            addCriterion("Scale is not null");
            return (Criteria) this;
        }

        public Criteria andScaleEqualTo(BigDecimal value) {
            addCriterion("Scale =", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleNotEqualTo(BigDecimal value) {
            addCriterion("Scale <>", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleGreaterThan(BigDecimal value) {
            addCriterion("Scale >", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Scale >=", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleLessThan(BigDecimal value) {
            addCriterion("Scale <", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Scale <=", value, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleIn(List<BigDecimal> values) {
            addCriterion("Scale in", values, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleNotIn(List<BigDecimal> values) {
            addCriterion("Scale not in", values, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Scale between", value1, value2, "scale");
            return (Criteria) this;
        }

        public Criteria andScaleNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Scale not between", value1, value2, "scale");
            return (Criteria) this;
        }

        public Criteria andSymbolIsNull() {
            addCriterion("Symbol is null");
            return (Criteria) this;
        }

        public Criteria andSymbolIsNotNull() {
            addCriterion("Symbol is not null");
            return (Criteria) this;
        }

        public Criteria andSymbolEqualTo(String value) {
            addCriterion("Symbol =", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolNotEqualTo(String value) {
            addCriterion("Symbol <>", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolGreaterThan(String value) {
            addCriterion("Symbol >", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolGreaterThanOrEqualTo(String value) {
            addCriterion("Symbol >=", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolLessThan(String value) {
            addCriterion("Symbol <", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolLessThanOrEqualTo(String value) {
            addCriterion("Symbol <=", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolLike(String value) {
            addCriterion("Symbol like", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolNotLike(String value) {
            addCriterion("Symbol not like", value, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolIn(List<String> values) {
            addCriterion("Symbol in", values, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolNotIn(List<String> values) {
            addCriterion("Symbol not in", values, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolBetween(String value1, String value2) {
            addCriterion("Symbol between", value1, value2, "symbol");
            return (Criteria) this;
        }

        public Criteria andSymbolNotBetween(String value1, String value2) {
            addCriterion("Symbol not between", value1, value2, "symbol");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateIsNull() {
            addCriterion("RationalStartDate is null");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateIsNotNull() {
            addCriterion("RationalStartDate is not null");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateEqualTo(Date value) {
            addCriterionForJDBCDate("RationalStartDate =", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("RationalStartDate <>", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateGreaterThan(Date value) {
            addCriterionForJDBCDate("RationalStartDate >", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RationalStartDate >=", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateLessThan(Date value) {
            addCriterionForJDBCDate("RationalStartDate <", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RationalStartDate <=", value, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateIn(List<Date> values) {
            addCriterionForJDBCDate("RationalStartDate in", values, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("RationalStartDate not in", values, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RationalStartDate between", value1, value2, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalstartdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RationalStartDate not between", value1, value2, "rationalstartdate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateIsNull() {
            addCriterion("RationalEndDate is null");
            return (Criteria) this;
        }

        public Criteria andRationalenddateIsNotNull() {
            addCriterion("RationalEndDate is not null");
            return (Criteria) this;
        }

        public Criteria andRationalenddateEqualTo(Date value) {
            addCriterionForJDBCDate("RationalEndDate =", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateNotEqualTo(Date value) {
            addCriterionForJDBCDate("RationalEndDate <>", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateGreaterThan(Date value) {
            addCriterionForJDBCDate("RationalEndDate >", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RationalEndDate >=", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateLessThan(Date value) {
            addCriterionForJDBCDate("RationalEndDate <", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("RationalEndDate <=", value, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateIn(List<Date> values) {
            addCriterionForJDBCDate("RationalEndDate in", values, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateNotIn(List<Date> values) {
            addCriterionForJDBCDate("RationalEndDate not in", values, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RationalEndDate between", value1, value2, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andRationalenddateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("RationalEndDate not between", value1, value2, "rationalenddate");
            return (Criteria) this;
        }

        public Criteria andTaxpriceIsNull() {
            addCriterion("TaxPrice is null");
            return (Criteria) this;
        }

        public Criteria andTaxpriceIsNotNull() {
            addCriterion("TaxPrice is not null");
            return (Criteria) this;
        }

        public Criteria andTaxpriceEqualTo(BigDecimal value) {
            addCriterion("TaxPrice =", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceNotEqualTo(BigDecimal value) {
            addCriterion("TaxPrice <>", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceGreaterThan(BigDecimal value) {
            addCriterion("TaxPrice >", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TaxPrice >=", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceLessThan(BigDecimal value) {
            addCriterion("TaxPrice <", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TaxPrice <=", value, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceIn(List<BigDecimal> values) {
            addCriterion("TaxPrice in", values, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceNotIn(List<BigDecimal> values) {
            addCriterion("TaxPrice not in", values, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TaxPrice between", value1, value2, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxpriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TaxPrice not between", value1, value2, "taxprice");
            return (Criteria) this;
        }

        public Criteria andTaxproportionIsNull() {
            addCriterion("TaxProportion is null");
            return (Criteria) this;
        }

        public Criteria andTaxproportionIsNotNull() {
            addCriterion("TaxProportion is not null");
            return (Criteria) this;
        }

        public Criteria andTaxproportionEqualTo(BigDecimal value) {
            addCriterion("TaxProportion =", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionNotEqualTo(BigDecimal value) {
            addCriterion("TaxProportion <>", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionGreaterThan(BigDecimal value) {
            addCriterion("TaxProportion >", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TaxProportion >=", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionLessThan(BigDecimal value) {
            addCriterion("TaxProportion <", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TaxProportion <=", value, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionIn(List<BigDecimal> values) {
            addCriterion("TaxProportion in", values, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionNotIn(List<BigDecimal> values) {
            addCriterion("TaxProportion not in", values, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TaxProportion between", value1, value2, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andTaxproportionNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TaxProportion not between", value1, value2, "taxproportion");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("Status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("Status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(String value) {
            addCriterion("Status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(String value) {
            addCriterion("Status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(String value) {
            addCriterion("Status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(String value) {
            addCriterion("Status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(String value) {
            addCriterion("Status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(String value) {
            addCriterion("Status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(String value) {
            addCriterion("Status like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(String value) {
            addCriterion("Status not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<String> values) {
            addCriterion("Status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<String> values) {
            addCriterion("Status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(String value1, String value2) {
            addCriterion("Status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(String value1, String value2) {
            addCriterion("Status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andNoticedateIsNull() {
            addCriterion("NoticeDate is null");
            return (Criteria) this;
        }

        public Criteria andNoticedateIsNotNull() {
            addCriterion("NoticeDate is not null");
            return (Criteria) this;
        }

        public Criteria andNoticedateEqualTo(Date value) {
            addCriterionForJDBCDate("NoticeDate =", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("NoticeDate <>", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateGreaterThan(Date value) {
            addCriterionForJDBCDate("NoticeDate >", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("NoticeDate >=", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateLessThan(Date value) {
            addCriterionForJDBCDate("NoticeDate <", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("NoticeDate <=", value, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateIn(List<Date> values) {
            addCriterionForJDBCDate("NoticeDate in", values, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("NoticeDate not in", values, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("NoticeDate between", value1, value2, "noticedate");
            return (Criteria) this;
        }

        public Criteria andNoticedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("NoticeDate not between", value1, value2, "noticedate");
            return (Criteria) this;
        }

        public Criteria andHasadjustedIsNull() {
            addCriterion("HasAdjusted is null");
            return (Criteria) this;
        }

        public Criteria andHasadjustedIsNotNull() {
            addCriterion("HasAdjusted is not null");
            return (Criteria) this;
        }

        public Criteria andHasadjustedEqualTo(Boolean value) {
            addCriterion("HasAdjusted =", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedNotEqualTo(Boolean value) {
            addCriterion("HasAdjusted <>", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedGreaterThan(Boolean value) {
            addCriterion("HasAdjusted >", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("HasAdjusted >=", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedLessThan(Boolean value) {
            addCriterion("HasAdjusted <", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedLessThanOrEqualTo(Boolean value) {
            addCriterion("HasAdjusted <=", value, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedIn(List<Boolean> values) {
            addCriterion("HasAdjusted in", values, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedNotIn(List<Boolean> values) {
            addCriterion("HasAdjusted not in", values, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedBetween(Boolean value1, Boolean value2) {
            addCriterion("HasAdjusted between", value1, value2, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andHasadjustedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("HasAdjusted not between", value1, value2, "hasadjusted");
            return (Criteria) this;
        }

        public Criteria andFactorIsNull() {
            addCriterion("Factor is null");
            return (Criteria) this;
        }

        public Criteria andFactorIsNotNull() {
            addCriterion("Factor is not null");
            return (Criteria) this;
        }

        public Criteria andFactorEqualTo(BigDecimal value) {
            addCriterion("Factor =", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorNotEqualTo(BigDecimal value) {
            addCriterion("Factor <>", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorGreaterThan(BigDecimal value) {
            addCriterion("Factor >", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Factor >=", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorLessThan(BigDecimal value) {
            addCriterion("Factor <", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Factor <=", value, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorIn(List<BigDecimal> values) {
            addCriterion("Factor in", values, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorNotIn(List<BigDecimal> values) {
            addCriterion("Factor not in", values, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Factor between", value1, value2, "factor");
            return (Criteria) this;
        }

        public Criteria andFactorNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Factor not between", value1, value2, "factor");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}