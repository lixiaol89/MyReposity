package com.modules.corpaction.dao;

import com.modules.corpaction.model.CorpactionModel;
import com.modules.corpaction.model.CorpactionModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CorpactionModelMapper {
    int countByExample(CorpactionModelExample example);

    int deleteByExample(CorpactionModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CorpactionModel record);

    int insertSelective(CorpactionModel record);

    List<CorpactionModel> selectByExample(CorpactionModelExample example);

    CorpactionModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CorpactionModel record, @Param("example") CorpactionModelExample example);

    int updateByExample(@Param("record") CorpactionModel record, @Param("example") CorpactionModelExample example);

    int updateByPrimaryKeySelective(CorpactionModel record);

    int updateByPrimaryKey(CorpactionModel record);
}