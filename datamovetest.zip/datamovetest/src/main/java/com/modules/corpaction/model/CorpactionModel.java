package com.modules.corpaction.model;

import java.math.BigDecimal;
import java.util.Date;

public class CorpactionModel {
    private Integer id;

    private String underlying;

    private String exchangecode;

    private String businesstype;

    private Date exrightdate;

    private Date arrivedate;

    private BigDecimal amount;

    private BigDecimal price;

    private BigDecimal scale;

    private String symbol;

    private Date rationalstartdate;

    private Date rationalenddate;

    private BigDecimal taxprice;

    private BigDecimal taxproportion;

    private String status;

    private Date noticedate;

    private Boolean hasadjusted;

    private BigDecimal factor;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public String getExchangecode() {
        return exchangecode;
    }

    public void setExchangecode(String exchangecode) {
        this.exchangecode = exchangecode == null ? null : exchangecode.trim();
    }

    public String getBusinesstype() {
        return businesstype;
    }

    public void setBusinesstype(String businesstype) {
        this.businesstype = businesstype == null ? null : businesstype.trim();
    }

    public Date getExrightdate() {
        return exrightdate;
    }

    public void setExrightdate(Date exrightdate) {
        this.exrightdate = exrightdate;
    }

    public Date getArrivedate() {
        return arrivedate;
    }

    public void setArrivedate(Date arrivedate) {
        this.arrivedate = arrivedate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getScale() {
        return scale;
    }

    public void setScale(BigDecimal scale) {
        this.scale = scale;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol == null ? null : symbol.trim();
    }

    public Date getRationalstartdate() {
        return rationalstartdate;
    }

    public void setRationalstartdate(Date rationalstartdate) {
        this.rationalstartdate = rationalstartdate;
    }

    public Date getRationalenddate() {
        return rationalenddate;
    }

    public void setRationalenddate(Date rationalenddate) {
        this.rationalenddate = rationalenddate;
    }

    public BigDecimal getTaxprice() {
        return taxprice;
    }

    public void setTaxprice(BigDecimal taxprice) {
        this.taxprice = taxprice;
    }

    public BigDecimal getTaxproportion() {
        return taxproportion;
    }

    public void setTaxproportion(BigDecimal taxproportion) {
        this.taxproportion = taxproportion;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getNoticedate() {
        return noticedate;
    }

    public void setNoticedate(Date noticedate) {
        this.noticedate = noticedate;
    }

    public Boolean getHasadjusted() {
        return hasadjusted;
    }

    public void setHasadjusted(Boolean hasadjusted) {
        this.hasadjusted = hasadjusted;
    }

    public BigDecimal getFactor() {
        return factor;
    }

    public void setFactor(BigDecimal factor) {
        this.factor = factor;
    }
}