package com.modules.corpaction;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.corpaction.dao.CorpactionModelMapper;
import com.modules.corpaction.model.CorpactionModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CorpactionCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CorpactionModelMapper sourcemapper = GetDataSource.getMapper(CorpactionModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CorpactionModelMapper targetmapper = GetDataSource.getMapper(CorpactionModelMapper.class, sessionqa);
		
		
		List<CorpactionModel> source = sourcemapper.selectByExample(null);
		List<CorpactionModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CorpactionModel> same = new ArrayList<CorpactionModel>();
		for(CorpactionModel targetmodel : target){
			for(CorpactionModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())&&targetmodel.getBusinesstype().equals(sourcemodel.getBusinesstype())&&targetmodel.getNoticedate().equals(sourcemodel.getNoticedate())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(CorpactionModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CorpactionModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CorpactionCompare().compare();
	}


}
