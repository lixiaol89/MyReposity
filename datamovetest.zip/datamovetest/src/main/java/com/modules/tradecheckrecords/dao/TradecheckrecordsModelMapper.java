package com.modules.tradecheckrecords.dao;

import com.modules.tradecheckrecords.model.TradecheckrecordsModel;
import com.modules.tradecheckrecords.model.TradecheckrecordsModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TradecheckrecordsModelMapper {
    int countByExample(TradecheckrecordsModelExample example);

    int deleteByExample(TradecheckrecordsModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TradecheckrecordsModel record);

    int insertSelective(TradecheckrecordsModel record);

    List<TradecheckrecordsModel> selectByExample(TradecheckrecordsModelExample example);

    TradecheckrecordsModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TradecheckrecordsModel record, @Param("example") TradecheckrecordsModelExample example);

    int updateByExample(@Param("record") TradecheckrecordsModel record, @Param("example") TradecheckrecordsModelExample example);

    int updateByPrimaryKeySelective(TradecheckrecordsModel record);

    int updateByPrimaryKey(TradecheckrecordsModel record);
}