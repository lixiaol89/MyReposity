package com.modules.tradecheckrecords.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TradecheckrecordsModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TradecheckrecordsModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andEventidIsNull() {
            addCriterion("EventID is null");
            return (Criteria) this;
        }

        public Criteria andEventidIsNotNull() {
            addCriterion("EventID is not null");
            return (Criteria) this;
        }

        public Criteria andEventidEqualTo(String value) {
            addCriterion("EventID =", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidNotEqualTo(String value) {
            addCriterion("EventID <>", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidGreaterThan(String value) {
            addCriterion("EventID >", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidGreaterThanOrEqualTo(String value) {
            addCriterion("EventID >=", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidLessThan(String value) {
            addCriterion("EventID <", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidLessThanOrEqualTo(String value) {
            addCriterion("EventID <=", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidLike(String value) {
            addCriterion("EventID like", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidNotLike(String value) {
            addCriterion("EventID not like", value, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidIn(List<String> values) {
            addCriterion("EventID in", values, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidNotIn(List<String> values) {
            addCriterion("EventID not in", values, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidBetween(String value1, String value2) {
            addCriterion("EventID between", value1, value2, "eventid");
            return (Criteria) this;
        }

        public Criteria andEventidNotBetween(String value1, String value2) {
            addCriterion("EventID not between", value1, value2, "eventid");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andSeqnoIsNull() {
            addCriterion("SeqNo is null");
            return (Criteria) this;
        }

        public Criteria andSeqnoIsNotNull() {
            addCriterion("SeqNo is not null");
            return (Criteria) this;
        }

        public Criteria andSeqnoEqualTo(Long value) {
            addCriterion("SeqNo =", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoNotEqualTo(Long value) {
            addCriterion("SeqNo <>", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoGreaterThan(Long value) {
            addCriterion("SeqNo >", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoGreaterThanOrEqualTo(Long value) {
            addCriterion("SeqNo >=", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoLessThan(Long value) {
            addCriterion("SeqNo <", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoLessThanOrEqualTo(Long value) {
            addCriterion("SeqNo <=", value, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoIn(List<Long> values) {
            addCriterion("SeqNo in", values, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoNotIn(List<Long> values) {
            addCriterion("SeqNo not in", values, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoBetween(Long value1, Long value2) {
            addCriterion("SeqNo between", value1, value2, "seqno");
            return (Criteria) this;
        }

        public Criteria andSeqnoNotBetween(Long value1, Long value2) {
            addCriterion("SeqNo not between", value1, value2, "seqno");
            return (Criteria) this;
        }

        public Criteria andEventtypeIsNull() {
            addCriterion("EventType is null");
            return (Criteria) this;
        }

        public Criteria andEventtypeIsNotNull() {
            addCriterion("EventType is not null");
            return (Criteria) this;
        }

        public Criteria andEventtypeEqualTo(Integer value) {
            addCriterion("EventType =", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeNotEqualTo(Integer value) {
            addCriterion("EventType <>", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeGreaterThan(Integer value) {
            addCriterion("EventType >", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("EventType >=", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeLessThan(Integer value) {
            addCriterion("EventType <", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeLessThanOrEqualTo(Integer value) {
            addCriterion("EventType <=", value, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeIn(List<Integer> values) {
            addCriterion("EventType in", values, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeNotIn(List<Integer> values) {
            addCriterion("EventType not in", values, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeBetween(Integer value1, Integer value2) {
            addCriterion("EventType between", value1, value2, "eventtype");
            return (Criteria) this;
        }

        public Criteria andEventtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("EventType not between", value1, value2, "eventtype");
            return (Criteria) this;
        }

        public Criteria andMakeridIsNull() {
            addCriterion("MakerID is null");
            return (Criteria) this;
        }

        public Criteria andMakeridIsNotNull() {
            addCriterion("MakerID is not null");
            return (Criteria) this;
        }

        public Criteria andMakeridEqualTo(String value) {
            addCriterion("MakerID =", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridNotEqualTo(String value) {
            addCriterion("MakerID <>", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridGreaterThan(String value) {
            addCriterion("MakerID >", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridGreaterThanOrEqualTo(String value) {
            addCriterion("MakerID >=", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridLessThan(String value) {
            addCriterion("MakerID <", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridLessThanOrEqualTo(String value) {
            addCriterion("MakerID <=", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridLike(String value) {
            addCriterion("MakerID like", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridNotLike(String value) {
            addCriterion("MakerID not like", value, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridIn(List<String> values) {
            addCriterion("MakerID in", values, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridNotIn(List<String> values) {
            addCriterion("MakerID not in", values, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridBetween(String value1, String value2) {
            addCriterion("MakerID between", value1, value2, "makerid");
            return (Criteria) this;
        }

        public Criteria andMakeridNotBetween(String value1, String value2) {
            addCriterion("MakerID not between", value1, value2, "makerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridIsNull() {
            addCriterion("CheckerID is null");
            return (Criteria) this;
        }

        public Criteria andCheckeridIsNotNull() {
            addCriterion("CheckerID is not null");
            return (Criteria) this;
        }

        public Criteria andCheckeridEqualTo(String value) {
            addCriterion("CheckerID =", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotEqualTo(String value) {
            addCriterion("CheckerID <>", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridGreaterThan(String value) {
            addCriterion("CheckerID >", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridGreaterThanOrEqualTo(String value) {
            addCriterion("CheckerID >=", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLessThan(String value) {
            addCriterion("CheckerID <", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLessThanOrEqualTo(String value) {
            addCriterion("CheckerID <=", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLike(String value) {
            addCriterion("CheckerID like", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotLike(String value) {
            addCriterion("CheckerID not like", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridIn(List<String> values) {
            addCriterion("CheckerID in", values, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotIn(List<String> values) {
            addCriterion("CheckerID not in", values, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridBetween(String value1, String value2) {
            addCriterion("CheckerID between", value1, value2, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotBetween(String value1, String value2) {
            addCriterion("CheckerID not between", value1, value2, "checkerid");
            return (Criteria) this;
        }

        public Criteria andIsacceptIsNull() {
            addCriterion("IsAccept is null");
            return (Criteria) this;
        }

        public Criteria andIsacceptIsNotNull() {
            addCriterion("IsAccept is not null");
            return (Criteria) this;
        }

        public Criteria andIsacceptEqualTo(Integer value) {
            addCriterion("IsAccept =", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptNotEqualTo(Integer value) {
            addCriterion("IsAccept <>", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptGreaterThan(Integer value) {
            addCriterion("IsAccept >", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptGreaterThanOrEqualTo(Integer value) {
            addCriterion("IsAccept >=", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptLessThan(Integer value) {
            addCriterion("IsAccept <", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptLessThanOrEqualTo(Integer value) {
            addCriterion("IsAccept <=", value, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptIn(List<Integer> values) {
            addCriterion("IsAccept in", values, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptNotIn(List<Integer> values) {
            addCriterion("IsAccept not in", values, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptBetween(Integer value1, Integer value2) {
            addCriterion("IsAccept between", value1, value2, "isaccept");
            return (Criteria) this;
        }

        public Criteria andIsacceptNotBetween(Integer value1, Integer value2) {
            addCriterion("IsAccept not between", value1, value2, "isaccept");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNull() {
            addCriterion("CheckStatus is null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNotNull() {
            addCriterion("CheckStatus is not null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusEqualTo(Integer value) {
            addCriterion("CheckStatus =", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotEqualTo(Integer value) {
            addCriterion("CheckStatus <>", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThan(Integer value) {
            addCriterion("CheckStatus >", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("CheckStatus >=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThan(Integer value) {
            addCriterion("CheckStatus <", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThanOrEqualTo(Integer value) {
            addCriterion("CheckStatus <=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIn(List<Integer> values) {
            addCriterion("CheckStatus in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotIn(List<Integer> values) {
            addCriterion("CheckStatus not in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusBetween(Integer value1, Integer value2) {
            addCriterion("CheckStatus between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("CheckStatus not between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("Comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("Comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(String value) {
            addCriterion("Comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(String value) {
            addCriterion("Comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(String value) {
            addCriterion("Comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(String value) {
            addCriterion("Comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(String value) {
            addCriterion("Comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(String value) {
            addCriterion("Comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLike(String value) {
            addCriterion("Comment like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotLike(String value) {
            addCriterion("Comment not like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<String> values) {
            addCriterion("Comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<String> values) {
            addCriterion("Comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(String value1, String value2) {
            addCriterion("Comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(String value1, String value2) {
            addCriterion("Comment not between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("lastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("lastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("lastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("lastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("lastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("lastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("lastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("lastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("lastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("lastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("lastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("lastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}