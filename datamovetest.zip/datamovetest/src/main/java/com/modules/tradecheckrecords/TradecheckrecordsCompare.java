package com.modules.tradecheckrecords;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.tradecheckrecords.dao.TradecheckrecordsModelMapper;
import com.modules.tradecheckrecords.model.TradecheckrecordsModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class TradecheckrecordsCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		TradecheckrecordsModelMapper sourcemapper = GetDataSource.getMapper(TradecheckrecordsModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		TradecheckrecordsModelMapper targetmapper = GetDataSource.getMapper(TradecheckrecordsModelMapper.class, sessionqa);
		
		
		List<TradecheckrecordsModel> source = sourcemapper.selectByExample(null);
		List<TradecheckrecordsModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<TradecheckrecordsModel> same = new ArrayList<TradecheckrecordsModel>();
		for(TradecheckrecordsModel targetmodel : target){
			for(TradecheckrecordsModel sourcemodel : source){
				if(targetmodel.getEventid().equals(sourcemodel.getEventid())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(TradecheckrecordsModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(TradecheckrecordsModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new TradecheckrecordsCompare().compare();
	}


}
