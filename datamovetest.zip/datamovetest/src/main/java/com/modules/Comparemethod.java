package com.modules;

public interface Comparemethod {

}
