package com.modules.barrieroptbkinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.barrieroptbkinfo.dao.BarrieroptbkinfoModelMapper;
import com.modules.barrieroptbkinfo.model.BarrieroptbkinfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class BarrieroptbkinfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		BarrieroptbkinfoModelMapper sourcemapper = GetDataSource.getMapper(BarrieroptbkinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		BarrieroptbkinfoModelMapper targetmapper = GetDataSource.getMapper(BarrieroptbkinfoModelMapper.class, sessionqa);
		
		
		List<BarrieroptbkinfoModel> source = sourcemapper.selectByExample(null);
		List<BarrieroptbkinfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<BarrieroptbkinfoModel> same = new ArrayList<BarrieroptbkinfoModel>();
		for(BarrieroptbkinfoModel targetmodel : target){
			for(BarrieroptbkinfoModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(BarrieroptbkinfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(BarrieroptbkinfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new BarrieroptbkinfoCompare().compare();
	}


}
