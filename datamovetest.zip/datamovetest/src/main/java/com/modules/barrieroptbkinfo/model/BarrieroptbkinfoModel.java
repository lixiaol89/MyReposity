package com.modules.barrieroptbkinfo.model;

import java.math.BigDecimal;
import java.util.Date;

public class BarrieroptbkinfoModel  implements Comparable<BarrieroptbkinfoModel>{
    private Integer id;

    private String tradeid;

    private Integer obsfreq;

    private BigDecimal upbarrier;

    private BigDecimal downbarrier;

    private BigDecimal riskupbarrier;

    private BigDecimal riskdownbarrier;

    private BigDecimal upsmoothwidth;

    private BigDecimal downsmoothwidth;

    private Integer upinorout;

    private Integer downinorout;

    private BigDecimal uprebate;

    private BigDecimal downrebate;

    private Integer rebatepaytime;

    private Integer rebatepaydelay;

    private String lastupdateuser;

    private Date lastupdatetime;

    private BigDecimal maturityprincipal;

    private String optportfolio;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public Integer getObsfreq() {
        return obsfreq;
    }

    public void setObsfreq(Integer obsfreq) {
        this.obsfreq = obsfreq;
    }

    public BigDecimal getUpbarrier() {
        return upbarrier;
    }

    public void setUpbarrier(BigDecimal upbarrier) {
        this.upbarrier = upbarrier;
    }

    public BigDecimal getDownbarrier() {
        return downbarrier;
    }

    public void setDownbarrier(BigDecimal downbarrier) {
        this.downbarrier = downbarrier;
    }

    public BigDecimal getRiskupbarrier() {
        return riskupbarrier;
    }

    public void setRiskupbarrier(BigDecimal riskupbarrier) {
        this.riskupbarrier = riskupbarrier;
    }

    public BigDecimal getRiskdownbarrier() {
        return riskdownbarrier;
    }

    public void setRiskdownbarrier(BigDecimal riskdownbarrier) {
        this.riskdownbarrier = riskdownbarrier;
    }

    public BigDecimal getUpsmoothwidth() {
        return upsmoothwidth;
    }

    public void setUpsmoothwidth(BigDecimal upsmoothwidth) {
        this.upsmoothwidth = upsmoothwidth;
    }

    public BigDecimal getDownsmoothwidth() {
        return downsmoothwidth;
    }

    public void setDownsmoothwidth(BigDecimal downsmoothwidth) {
        this.downsmoothwidth = downsmoothwidth;
    }

    public Integer getUpinorout() {
        return upinorout;
    }

    public void setUpinorout(Integer upinorout) {
        this.upinorout = upinorout;
    }

    public Integer getDowninorout() {
        return downinorout;
    }

    public void setDowninorout(Integer downinorout) {
        this.downinorout = downinorout;
    }

    public BigDecimal getUprebate() {
        return uprebate;
    }

    public void setUprebate(BigDecimal uprebate) {
        this.uprebate = uprebate;
    }

    public BigDecimal getDownrebate() {
        return downrebate;
    }

    public void setDownrebate(BigDecimal downrebate) {
        this.downrebate = downrebate;
    }

    public Integer getRebatepaytime() {
        return rebatepaytime;
    }

    public void setRebatepaytime(Integer rebatepaytime) {
        this.rebatepaytime = rebatepaytime;
    }

    public Integer getRebatepaydelay() {
        return rebatepaydelay;
    }

    public void setRebatepaydelay(Integer rebatepaydelay) {
        this.rebatepaydelay = rebatepaydelay;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }

    public BigDecimal getMaturityprincipal() {
        return maturityprincipal;
    }

    public void setMaturityprincipal(BigDecimal maturityprincipal) {
        this.maturityprincipal = maturityprincipal;
    }

    public String getOptportfolio() {
        return optportfolio;
    }

    public void setOptportfolio(String optportfolio) {
        this.optportfolio = optportfolio == null ? null : optportfolio.trim();
    }

	public int compareTo(BarrieroptbkinfoModel o) {
		if(this.tradeid.equals(o.tradeid)){
			return 0;
		}else{
			return 1;
		}
		
	}
}