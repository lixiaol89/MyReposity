package com.modules.barrieroptbkinfo.dao;

import com.modules.barrieroptbkinfo.model.BarrieroptbkinfoModel;
import com.modules.barrieroptbkinfo.model.BarrieroptbkinfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BarrieroptbkinfoModelMapper {
    int countByExample(BarrieroptbkinfoModelExample example);

    int deleteByExample(BarrieroptbkinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BarrieroptbkinfoModel record);

    int insertSelective(BarrieroptbkinfoModel record);

    List<BarrieroptbkinfoModel> selectByExampleWithBLOBs(BarrieroptbkinfoModelExample example);

    List<BarrieroptbkinfoModel> selectByExample(BarrieroptbkinfoModelExample example);

    BarrieroptbkinfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BarrieroptbkinfoModel record, @Param("example") BarrieroptbkinfoModelExample example);

    int updateByExampleWithBLOBs(@Param("record") BarrieroptbkinfoModel record, @Param("example") BarrieroptbkinfoModelExample example);

    int updateByExample(@Param("record") BarrieroptbkinfoModel record, @Param("example") BarrieroptbkinfoModelExample example);

    int updateByPrimaryKeySelective(BarrieroptbkinfoModel record);

    int updateByPrimaryKeyWithBLOBs(BarrieroptbkinfoModel record);

    int updateByPrimaryKey(BarrieroptbkinfoModel record);
}