package com.modules.barrieroptbkinfo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BarrieroptbkinfoModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BarrieroptbkinfoModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andObsfreqIsNull() {
            addCriterion("ObsFreq is null");
            return (Criteria) this;
        }

        public Criteria andObsfreqIsNotNull() {
            addCriterion("ObsFreq is not null");
            return (Criteria) this;
        }

        public Criteria andObsfreqEqualTo(Integer value) {
            addCriterion("ObsFreq =", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqNotEqualTo(Integer value) {
            addCriterion("ObsFreq <>", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqGreaterThan(Integer value) {
            addCriterion("ObsFreq >", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqGreaterThanOrEqualTo(Integer value) {
            addCriterion("ObsFreq >=", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqLessThan(Integer value) {
            addCriterion("ObsFreq <", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqLessThanOrEqualTo(Integer value) {
            addCriterion("ObsFreq <=", value, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqIn(List<Integer> values) {
            addCriterion("ObsFreq in", values, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqNotIn(List<Integer> values) {
            addCriterion("ObsFreq not in", values, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqBetween(Integer value1, Integer value2) {
            addCriterion("ObsFreq between", value1, value2, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andObsfreqNotBetween(Integer value1, Integer value2) {
            addCriterion("ObsFreq not between", value1, value2, "obsfreq");
            return (Criteria) this;
        }

        public Criteria andUpbarrierIsNull() {
            addCriterion("UpBarrier is null");
            return (Criteria) this;
        }

        public Criteria andUpbarrierIsNotNull() {
            addCriterion("UpBarrier is not null");
            return (Criteria) this;
        }

        public Criteria andUpbarrierEqualTo(BigDecimal value) {
            addCriterion("UpBarrier =", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierNotEqualTo(BigDecimal value) {
            addCriterion("UpBarrier <>", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierGreaterThan(BigDecimal value) {
            addCriterion("UpBarrier >", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("UpBarrier >=", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierLessThan(BigDecimal value) {
            addCriterion("UpBarrier <", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierLessThanOrEqualTo(BigDecimal value) {
            addCriterion("UpBarrier <=", value, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierIn(List<BigDecimal> values) {
            addCriterion("UpBarrier in", values, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierNotIn(List<BigDecimal> values) {
            addCriterion("UpBarrier not in", values, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpBarrier between", value1, value2, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andUpbarrierNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpBarrier not between", value1, value2, "upbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierIsNull() {
            addCriterion("DownBarrier is null");
            return (Criteria) this;
        }

        public Criteria andDownbarrierIsNotNull() {
            addCriterion("DownBarrier is not null");
            return (Criteria) this;
        }

        public Criteria andDownbarrierEqualTo(BigDecimal value) {
            addCriterion("DownBarrier =", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierNotEqualTo(BigDecimal value) {
            addCriterion("DownBarrier <>", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierGreaterThan(BigDecimal value) {
            addCriterion("DownBarrier >", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DownBarrier >=", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierLessThan(BigDecimal value) {
            addCriterion("DownBarrier <", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DownBarrier <=", value, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierIn(List<BigDecimal> values) {
            addCriterion("DownBarrier in", values, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierNotIn(List<BigDecimal> values) {
            addCriterion("DownBarrier not in", values, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownBarrier between", value1, value2, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andDownbarrierNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownBarrier not between", value1, value2, "downbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierIsNull() {
            addCriterion("RiskUpBarrier is null");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierIsNotNull() {
            addCriterion("RiskUpBarrier is not null");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierEqualTo(BigDecimal value) {
            addCriterion("RiskUpBarrier =", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierNotEqualTo(BigDecimal value) {
            addCriterion("RiskUpBarrier <>", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierGreaterThan(BigDecimal value) {
            addCriterion("RiskUpBarrier >", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("RiskUpBarrier >=", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierLessThan(BigDecimal value) {
            addCriterion("RiskUpBarrier <", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierLessThanOrEqualTo(BigDecimal value) {
            addCriterion("RiskUpBarrier <=", value, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierIn(List<BigDecimal> values) {
            addCriterion("RiskUpBarrier in", values, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierNotIn(List<BigDecimal> values) {
            addCriterion("RiskUpBarrier not in", values, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RiskUpBarrier between", value1, value2, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskupbarrierNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RiskUpBarrier not between", value1, value2, "riskupbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierIsNull() {
            addCriterion("RiskDownBarrier is null");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierIsNotNull() {
            addCriterion("RiskDownBarrier is not null");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierEqualTo(BigDecimal value) {
            addCriterion("RiskDownBarrier =", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierNotEqualTo(BigDecimal value) {
            addCriterion("RiskDownBarrier <>", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierGreaterThan(BigDecimal value) {
            addCriterion("RiskDownBarrier >", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("RiskDownBarrier >=", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierLessThan(BigDecimal value) {
            addCriterion("RiskDownBarrier <", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierLessThanOrEqualTo(BigDecimal value) {
            addCriterion("RiskDownBarrier <=", value, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierIn(List<BigDecimal> values) {
            addCriterion("RiskDownBarrier in", values, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierNotIn(List<BigDecimal> values) {
            addCriterion("RiskDownBarrier not in", values, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RiskDownBarrier between", value1, value2, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andRiskdownbarrierNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RiskDownBarrier not between", value1, value2, "riskdownbarrier");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthIsNull() {
            addCriterion("UpSmoothWidth is null");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthIsNotNull() {
            addCriterion("UpSmoothWidth is not null");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthEqualTo(BigDecimal value) {
            addCriterion("UpSmoothWidth =", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthNotEqualTo(BigDecimal value) {
            addCriterion("UpSmoothWidth <>", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthGreaterThan(BigDecimal value) {
            addCriterion("UpSmoothWidth >", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("UpSmoothWidth >=", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthLessThan(BigDecimal value) {
            addCriterion("UpSmoothWidth <", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthLessThanOrEqualTo(BigDecimal value) {
            addCriterion("UpSmoothWidth <=", value, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthIn(List<BigDecimal> values) {
            addCriterion("UpSmoothWidth in", values, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthNotIn(List<BigDecimal> values) {
            addCriterion("UpSmoothWidth not in", values, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpSmoothWidth between", value1, value2, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpsmoothwidthNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpSmoothWidth not between", value1, value2, "upsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthIsNull() {
            addCriterion("DownSmoothWidth is null");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthIsNotNull() {
            addCriterion("DownSmoothWidth is not null");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthEqualTo(BigDecimal value) {
            addCriterion("DownSmoothWidth =", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthNotEqualTo(BigDecimal value) {
            addCriterion("DownSmoothWidth <>", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthGreaterThan(BigDecimal value) {
            addCriterion("DownSmoothWidth >", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DownSmoothWidth >=", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthLessThan(BigDecimal value) {
            addCriterion("DownSmoothWidth <", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DownSmoothWidth <=", value, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthIn(List<BigDecimal> values) {
            addCriterion("DownSmoothWidth in", values, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthNotIn(List<BigDecimal> values) {
            addCriterion("DownSmoothWidth not in", values, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownSmoothWidth between", value1, value2, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andDownsmoothwidthNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownSmoothWidth not between", value1, value2, "downsmoothwidth");
            return (Criteria) this;
        }

        public Criteria andUpinoroutIsNull() {
            addCriterion("UpInOrOut is null");
            return (Criteria) this;
        }

        public Criteria andUpinoroutIsNotNull() {
            addCriterion("UpInOrOut is not null");
            return (Criteria) this;
        }

        public Criteria andUpinoroutEqualTo(Integer value) {
            addCriterion("UpInOrOut =", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutNotEqualTo(Integer value) {
            addCriterion("UpInOrOut <>", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutGreaterThan(Integer value) {
            addCriterion("UpInOrOut >", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutGreaterThanOrEqualTo(Integer value) {
            addCriterion("UpInOrOut >=", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutLessThan(Integer value) {
            addCriterion("UpInOrOut <", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutLessThanOrEqualTo(Integer value) {
            addCriterion("UpInOrOut <=", value, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutIn(List<Integer> values) {
            addCriterion("UpInOrOut in", values, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutNotIn(List<Integer> values) {
            addCriterion("UpInOrOut not in", values, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutBetween(Integer value1, Integer value2) {
            addCriterion("UpInOrOut between", value1, value2, "upinorout");
            return (Criteria) this;
        }

        public Criteria andUpinoroutNotBetween(Integer value1, Integer value2) {
            addCriterion("UpInOrOut not between", value1, value2, "upinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutIsNull() {
            addCriterion("DownInOrOut is null");
            return (Criteria) this;
        }

        public Criteria andDowninoroutIsNotNull() {
            addCriterion("DownInOrOut is not null");
            return (Criteria) this;
        }

        public Criteria andDowninoroutEqualTo(Integer value) {
            addCriterion("DownInOrOut =", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutNotEqualTo(Integer value) {
            addCriterion("DownInOrOut <>", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutGreaterThan(Integer value) {
            addCriterion("DownInOrOut >", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutGreaterThanOrEqualTo(Integer value) {
            addCriterion("DownInOrOut >=", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutLessThan(Integer value) {
            addCriterion("DownInOrOut <", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutLessThanOrEqualTo(Integer value) {
            addCriterion("DownInOrOut <=", value, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutIn(List<Integer> values) {
            addCriterion("DownInOrOut in", values, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutNotIn(List<Integer> values) {
            addCriterion("DownInOrOut not in", values, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutBetween(Integer value1, Integer value2) {
            addCriterion("DownInOrOut between", value1, value2, "downinorout");
            return (Criteria) this;
        }

        public Criteria andDowninoroutNotBetween(Integer value1, Integer value2) {
            addCriterion("DownInOrOut not between", value1, value2, "downinorout");
            return (Criteria) this;
        }

        public Criteria andUprebateIsNull() {
            addCriterion("UpRebate is null");
            return (Criteria) this;
        }

        public Criteria andUprebateIsNotNull() {
            addCriterion("UpRebate is not null");
            return (Criteria) this;
        }

        public Criteria andUprebateEqualTo(BigDecimal value) {
            addCriterion("UpRebate =", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateNotEqualTo(BigDecimal value) {
            addCriterion("UpRebate <>", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateGreaterThan(BigDecimal value) {
            addCriterion("UpRebate >", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("UpRebate >=", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateLessThan(BigDecimal value) {
            addCriterion("UpRebate <", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("UpRebate <=", value, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateIn(List<BigDecimal> values) {
            addCriterion("UpRebate in", values, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateNotIn(List<BigDecimal> values) {
            addCriterion("UpRebate not in", values, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpRebate between", value1, value2, "uprebate");
            return (Criteria) this;
        }

        public Criteria andUprebateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpRebate not between", value1, value2, "uprebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateIsNull() {
            addCriterion("DownRebate is null");
            return (Criteria) this;
        }

        public Criteria andDownrebateIsNotNull() {
            addCriterion("DownRebate is not null");
            return (Criteria) this;
        }

        public Criteria andDownrebateEqualTo(BigDecimal value) {
            addCriterion("DownRebate =", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateNotEqualTo(BigDecimal value) {
            addCriterion("DownRebate <>", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateGreaterThan(BigDecimal value) {
            addCriterion("DownRebate >", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DownRebate >=", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateLessThan(BigDecimal value) {
            addCriterion("DownRebate <", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DownRebate <=", value, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateIn(List<BigDecimal> values) {
            addCriterion("DownRebate in", values, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateNotIn(List<BigDecimal> values) {
            addCriterion("DownRebate not in", values, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownRebate between", value1, value2, "downrebate");
            return (Criteria) this;
        }

        public Criteria andDownrebateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DownRebate not between", value1, value2, "downrebate");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeIsNull() {
            addCriterion("RebatePaytime is null");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeIsNotNull() {
            addCriterion("RebatePaytime is not null");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeEqualTo(Integer value) {
            addCriterion("RebatePaytime =", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeNotEqualTo(Integer value) {
            addCriterion("RebatePaytime <>", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeGreaterThan(Integer value) {
            addCriterion("RebatePaytime >", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("RebatePaytime >=", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeLessThan(Integer value) {
            addCriterion("RebatePaytime <", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeLessThanOrEqualTo(Integer value) {
            addCriterion("RebatePaytime <=", value, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeIn(List<Integer> values) {
            addCriterion("RebatePaytime in", values, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeNotIn(List<Integer> values) {
            addCriterion("RebatePaytime not in", values, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeBetween(Integer value1, Integer value2) {
            addCriterion("RebatePaytime between", value1, value2, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaytimeNotBetween(Integer value1, Integer value2) {
            addCriterion("RebatePaytime not between", value1, value2, "rebatepaytime");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayIsNull() {
            addCriterion("RebatePayDelay is null");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayIsNotNull() {
            addCriterion("RebatePayDelay is not null");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayEqualTo(Integer value) {
            addCriterion("RebatePayDelay =", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayNotEqualTo(Integer value) {
            addCriterion("RebatePayDelay <>", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayGreaterThan(Integer value) {
            addCriterion("RebatePayDelay >", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayGreaterThanOrEqualTo(Integer value) {
            addCriterion("RebatePayDelay >=", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayLessThan(Integer value) {
            addCriterion("RebatePayDelay <", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayLessThanOrEqualTo(Integer value) {
            addCriterion("RebatePayDelay <=", value, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayIn(List<Integer> values) {
            addCriterion("RebatePayDelay in", values, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayNotIn(List<Integer> values) {
            addCriterion("RebatePayDelay not in", values, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayBetween(Integer value1, Integer value2) {
            addCriterion("RebatePayDelay between", value1, value2, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andRebatepaydelayNotBetween(Integer value1, Integer value2) {
            addCriterion("RebatePayDelay not between", value1, value2, "rebatepaydelay");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNull() {
            addCriterion("LastUpdateUser is null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNotNull() {
            addCriterion("LastUpdateUser is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserEqualTo(String value) {
            addCriterion("LastUpdateUser =", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotEqualTo(String value) {
            addCriterion("LastUpdateUser <>", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThan(String value) {
            addCriterion("LastUpdateUser >", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser >=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThan(String value) {
            addCriterion("LastUpdateUser <", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser <=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLike(String value) {
            addCriterion("LastUpdateUser like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotLike(String value) {
            addCriterion("LastUpdateUser not like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIn(List<String> values) {
            addCriterion("LastUpdateUser in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotIn(List<String> values) {
            addCriterion("LastUpdateUser not in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserBetween(String value1, String value2) {
            addCriterion("LastUpdateUser between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotBetween(String value1, String value2) {
            addCriterion("LastUpdateUser not between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("LastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("LastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("LastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("LastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("LastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("LastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("LastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("LastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalIsNull() {
            addCriterion("MaturityPrincipal is null");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalIsNotNull() {
            addCriterion("MaturityPrincipal is not null");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalEqualTo(BigDecimal value) {
            addCriterion("MaturityPrincipal =", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalNotEqualTo(BigDecimal value) {
            addCriterion("MaturityPrincipal <>", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalGreaterThan(BigDecimal value) {
            addCriterion("MaturityPrincipal >", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MaturityPrincipal >=", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalLessThan(BigDecimal value) {
            addCriterion("MaturityPrincipal <", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MaturityPrincipal <=", value, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalIn(List<BigDecimal> values) {
            addCriterion("MaturityPrincipal in", values, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalNotIn(List<BigDecimal> values) {
            addCriterion("MaturityPrincipal not in", values, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MaturityPrincipal between", value1, value2, "maturityprincipal");
            return (Criteria) this;
        }

        public Criteria andMaturityprincipalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MaturityPrincipal not between", value1, value2, "maturityprincipal");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}