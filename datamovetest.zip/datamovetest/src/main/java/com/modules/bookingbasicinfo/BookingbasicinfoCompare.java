package com.modules.bookingbasicinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.bookingbasicinfo.dao.BookingbasicinfoModelMapper;
import com.modules.bookingbasicinfo.model.BookingbasicinfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class BookingbasicinfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		BookingbasicinfoModelMapper sourcemapper = GetDataSource.getMapper(BookingbasicinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		BookingbasicinfoModelMapper targetmapper = GetDataSource.getMapper(BookingbasicinfoModelMapper.class, sessionqa);
		
		
		List<BookingbasicinfoModel> source = sourcemapper.selectByExample(null);
		List<BookingbasicinfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<BookingbasicinfoModel> same = new ArrayList<BookingbasicinfoModel>();
		for(BookingbasicinfoModel targetmodel : target){
			for(BookingbasicinfoModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(BookingbasicinfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(BookingbasicinfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new BookingbasicinfoCompare().compare();
	}


}
