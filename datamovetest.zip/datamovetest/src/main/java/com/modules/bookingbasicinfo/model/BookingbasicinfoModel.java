package com.modules.bookingbasicinfo.model;

import java.math.BigDecimal;
import java.util.Date;

public class BookingbasicinfoModel {
    private Integer id;

    private String tradeid;

    private String subbook;

    private String strategy;

    private String templatetype;

    private Integer performancetype;

    private BigDecimal position;

    private BigDecimal tradeprice;

    private String tradeccy;

    private String settleccy;

    private Date tradedate;

    private Date strikedate;

    private Date settlementdate;

    private Date expirydate;

    private String settlementtype;

    private Integer bizconv;

    private String daycountconv;

    private String counterpartyid;

    private String salesid;

    private BigDecimal edge;

    private Boolean fixingrecord;

    private Integer quantoflag;

    private BigDecimal initialmargin;

    private BigDecimal marginwarninglevel;

    private BigDecimal margincalllevel;

    private Boolean divadjust;

    private BigDecimal liquidationlevel;

    private Boolean marginnet;

    private String jsonfilepath;

    private String fxfixing;

    private String lastupdateuser;

    private Date lastupdatetime;

    private Integer undlrounding;

    private Integer payoffrounding;

    private BigDecimal reportingnotional;

    private Integer checkstatus;

    private String comment;

    private String checkerid;

    private Date checktime;

    private String overrideobsdate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public String getSubbook() {
        return subbook;
    }

    public void setSubbook(String subbook) {
        this.subbook = subbook == null ? null : subbook.trim();
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy == null ? null : strategy.trim();
    }

    public String getTemplatetype() {
        return templatetype;
    }

    public void setTemplatetype(String templatetype) {
        this.templatetype = templatetype == null ? null : templatetype.trim();
    }

    public Integer getPerformancetype() {
        return performancetype;
    }

    public void setPerformancetype(Integer performancetype) {
        this.performancetype = performancetype;
    }

    public BigDecimal getPosition() {
        return position;
    }

    public void setPosition(BigDecimal position) {
        this.position = position;
    }

    public BigDecimal getTradeprice() {
        return tradeprice;
    }

    public void setTradeprice(BigDecimal tradeprice) {
        this.tradeprice = tradeprice;
    }

    public String getTradeccy() {
        return tradeccy;
    }

    public void setTradeccy(String tradeccy) {
        this.tradeccy = tradeccy == null ? null : tradeccy.trim();
    }

    public String getSettleccy() {
        return settleccy;
    }

    public void setSettleccy(String settleccy) {
        this.settleccy = settleccy == null ? null : settleccy.trim();
    }

    public Date getTradedate() {
        return tradedate;
    }

    public void setTradedate(Date tradedate) {
        this.tradedate = tradedate;
    }

    public Date getStrikedate() {
        return strikedate;
    }

    public void setStrikedate(Date strikedate) {
        this.strikedate = strikedate;
    }

    public Date getSettlementdate() {
        return settlementdate;
    }

    public void setSettlementdate(Date settlementdate) {
        this.settlementdate = settlementdate;
    }

    public Date getExpirydate() {
        return expirydate;
    }

    public void setExpirydate(Date expirydate) {
        this.expirydate = expirydate;
    }

    public String getSettlementtype() {
        return settlementtype;
    }

    public void setSettlementtype(String settlementtype) {
        this.settlementtype = settlementtype == null ? null : settlementtype.trim();
    }

    public Integer getBizconv() {
        return bizconv;
    }

    public void setBizconv(Integer bizconv) {
        this.bizconv = bizconv;
    }

    public String getDaycountconv() {
        return daycountconv;
    }

    public void setDaycountconv(String daycountconv) {
        this.daycountconv = daycountconv == null ? null : daycountconv.trim();
    }

    public String getCounterpartyid() {
        return counterpartyid;
    }

    public void setCounterpartyid(String counterpartyid) {
        this.counterpartyid = counterpartyid == null ? null : counterpartyid.trim();
    }

    public String getSalesid() {
        return salesid;
    }

    public void setSalesid(String salesid) {
        this.salesid = salesid == null ? null : salesid.trim();
    }

    public BigDecimal getEdge() {
        return edge;
    }

    public void setEdge(BigDecimal edge) {
        this.edge = edge;
    }

    public Boolean getFixingrecord() {
        return fixingrecord;
    }

    public void setFixingrecord(Boolean fixingrecord) {
        this.fixingrecord = fixingrecord;
    }

    public Integer getQuantoflag() {
        return quantoflag;
    }

    public void setQuantoflag(Integer quantoflag) {
        this.quantoflag = quantoflag;
    }

    public BigDecimal getInitialmargin() {
        return initialmargin;
    }

    public void setInitialmargin(BigDecimal initialmargin) {
        this.initialmargin = initialmargin;
    }

    public BigDecimal getMarginwarninglevel() {
        return marginwarninglevel;
    }

    public void setMarginwarninglevel(BigDecimal marginwarninglevel) {
        this.marginwarninglevel = marginwarninglevel;
    }

    public BigDecimal getMargincalllevel() {
        return margincalllevel;
    }

    public void setMargincalllevel(BigDecimal margincalllevel) {
        this.margincalllevel = margincalllevel;
    }

    public Boolean getDivadjust() {
        return divadjust;
    }

    public void setDivadjust(Boolean divadjust) {
        this.divadjust = divadjust;
    }

    public BigDecimal getLiquidationlevel() {
        return liquidationlevel;
    }

    public void setLiquidationlevel(BigDecimal liquidationlevel) {
        this.liquidationlevel = liquidationlevel;
    }

    public Boolean getMarginnet() {
        return marginnet;
    }

    public void setMarginnet(Boolean marginnet) {
        this.marginnet = marginnet;
    }

    public String getJsonfilepath() {
        return jsonfilepath;
    }

    public void setJsonfilepath(String jsonfilepath) {
        this.jsonfilepath = jsonfilepath == null ? null : jsonfilepath.trim();
    }

    public String getFxfixing() {
        return fxfixing;
    }

    public void setFxfixing(String fxfixing) {
        this.fxfixing = fxfixing == null ? null : fxfixing.trim();
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }

    public Integer getUndlrounding() {
        return undlrounding;
    }

    public void setUndlrounding(Integer undlrounding) {
        this.undlrounding = undlrounding;
    }

    public Integer getPayoffrounding() {
        return payoffrounding;
    }

    public void setPayoffrounding(Integer payoffrounding) {
        this.payoffrounding = payoffrounding;
    }

    public BigDecimal getReportingnotional() {
        return reportingnotional;
    }

    public void setReportingnotional(BigDecimal reportingnotional) {
        this.reportingnotional = reportingnotional;
    }

    public Integer getCheckstatus() {
        return checkstatus;
    }

    public void setCheckstatus(Integer checkstatus) {
        this.checkstatus = checkstatus;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment == null ? null : comment.trim();
    }

    public String getCheckerid() {
        return checkerid;
    }

    public void setCheckerid(String checkerid) {
        this.checkerid = checkerid == null ? null : checkerid.trim();
    }

    public Date getChecktime() {
        return checktime;
    }

    public void setChecktime(Date checktime) {
        this.checktime = checktime;
    }

    public String getOverrideobsdate() {
        return overrideobsdate;
    }

    public void setOverrideobsdate(String overrideobsdate) {
        this.overrideobsdate = overrideobsdate == null ? null : overrideobsdate.trim();
    }
}