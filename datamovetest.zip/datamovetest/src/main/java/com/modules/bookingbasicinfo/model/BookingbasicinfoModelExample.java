package com.modules.bookingbasicinfo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class BookingbasicinfoModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BookingbasicinfoModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNull() {
            addCriterion("TradeID is null");
            return (Criteria) this;
        }

        public Criteria andTradeidIsNotNull() {
            addCriterion("TradeID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeidEqualTo(String value) {
            addCriterion("TradeID =", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotEqualTo(String value) {
            addCriterion("TradeID <>", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThan(String value) {
            addCriterion("TradeID >", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidGreaterThanOrEqualTo(String value) {
            addCriterion("TradeID >=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThan(String value) {
            addCriterion("TradeID <", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLessThanOrEqualTo(String value) {
            addCriterion("TradeID <=", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidLike(String value) {
            addCriterion("TradeID like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotLike(String value) {
            addCriterion("TradeID not like", value, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidIn(List<String> values) {
            addCriterion("TradeID in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotIn(List<String> values) {
            addCriterion("TradeID not in", values, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidBetween(String value1, String value2) {
            addCriterion("TradeID between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andTradeidNotBetween(String value1, String value2) {
            addCriterion("TradeID not between", value1, value2, "tradeid");
            return (Criteria) this;
        }

        public Criteria andSubbookIsNull() {
            addCriterion("SubBook is null");
            return (Criteria) this;
        }

        public Criteria andSubbookIsNotNull() {
            addCriterion("SubBook is not null");
            return (Criteria) this;
        }

        public Criteria andSubbookEqualTo(String value) {
            addCriterion("SubBook =", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookNotEqualTo(String value) {
            addCriterion("SubBook <>", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookGreaterThan(String value) {
            addCriterion("SubBook >", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookGreaterThanOrEqualTo(String value) {
            addCriterion("SubBook >=", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookLessThan(String value) {
            addCriterion("SubBook <", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookLessThanOrEqualTo(String value) {
            addCriterion("SubBook <=", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookLike(String value) {
            addCriterion("SubBook like", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookNotLike(String value) {
            addCriterion("SubBook not like", value, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookIn(List<String> values) {
            addCriterion("SubBook in", values, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookNotIn(List<String> values) {
            addCriterion("SubBook not in", values, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookBetween(String value1, String value2) {
            addCriterion("SubBook between", value1, value2, "subbook");
            return (Criteria) this;
        }

        public Criteria andSubbookNotBetween(String value1, String value2) {
            addCriterion("SubBook not between", value1, value2, "subbook");
            return (Criteria) this;
        }

        public Criteria andStrategyIsNull() {
            addCriterion("Strategy is null");
            return (Criteria) this;
        }

        public Criteria andStrategyIsNotNull() {
            addCriterion("Strategy is not null");
            return (Criteria) this;
        }

        public Criteria andStrategyEqualTo(String value) {
            addCriterion("Strategy =", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyNotEqualTo(String value) {
            addCriterion("Strategy <>", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyGreaterThan(String value) {
            addCriterion("Strategy >", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyGreaterThanOrEqualTo(String value) {
            addCriterion("Strategy >=", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyLessThan(String value) {
            addCriterion("Strategy <", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyLessThanOrEqualTo(String value) {
            addCriterion("Strategy <=", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyLike(String value) {
            addCriterion("Strategy like", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyNotLike(String value) {
            addCriterion("Strategy not like", value, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyIn(List<String> values) {
            addCriterion("Strategy in", values, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyNotIn(List<String> values) {
            addCriterion("Strategy not in", values, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyBetween(String value1, String value2) {
            addCriterion("Strategy between", value1, value2, "strategy");
            return (Criteria) this;
        }

        public Criteria andStrategyNotBetween(String value1, String value2) {
            addCriterion("Strategy not between", value1, value2, "strategy");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeIsNull() {
            addCriterion("TemplateType is null");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeIsNotNull() {
            addCriterion("TemplateType is not null");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeEqualTo(String value) {
            addCriterion("TemplateType =", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeNotEqualTo(String value) {
            addCriterion("TemplateType <>", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeGreaterThan(String value) {
            addCriterion("TemplateType >", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeGreaterThanOrEqualTo(String value) {
            addCriterion("TemplateType >=", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeLessThan(String value) {
            addCriterion("TemplateType <", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeLessThanOrEqualTo(String value) {
            addCriterion("TemplateType <=", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeLike(String value) {
            addCriterion("TemplateType like", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeNotLike(String value) {
            addCriterion("TemplateType not like", value, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeIn(List<String> values) {
            addCriterion("TemplateType in", values, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeNotIn(List<String> values) {
            addCriterion("TemplateType not in", values, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeBetween(String value1, String value2) {
            addCriterion("TemplateType between", value1, value2, "templatetype");
            return (Criteria) this;
        }

        public Criteria andTemplatetypeNotBetween(String value1, String value2) {
            addCriterion("TemplateType not between", value1, value2, "templatetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeIsNull() {
            addCriterion("PerformanceType is null");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeIsNotNull() {
            addCriterion("PerformanceType is not null");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeEqualTo(Integer value) {
            addCriterion("PerformanceType =", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeNotEqualTo(Integer value) {
            addCriterion("PerformanceType <>", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeGreaterThan(Integer value) {
            addCriterion("PerformanceType >", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("PerformanceType >=", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeLessThan(Integer value) {
            addCriterion("PerformanceType <", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeLessThanOrEqualTo(Integer value) {
            addCriterion("PerformanceType <=", value, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeIn(List<Integer> values) {
            addCriterion("PerformanceType in", values, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeNotIn(List<Integer> values) {
            addCriterion("PerformanceType not in", values, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeBetween(Integer value1, Integer value2) {
            addCriterion("PerformanceType between", value1, value2, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPerformancetypeNotBetween(Integer value1, Integer value2) {
            addCriterion("PerformanceType not between", value1, value2, "performancetype");
            return (Criteria) this;
        }

        public Criteria andPositionIsNull() {
            addCriterion("Position is null");
            return (Criteria) this;
        }

        public Criteria andPositionIsNotNull() {
            addCriterion("Position is not null");
            return (Criteria) this;
        }

        public Criteria andPositionEqualTo(BigDecimal value) {
            addCriterion("Position =", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotEqualTo(BigDecimal value) {
            addCriterion("Position <>", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionGreaterThan(BigDecimal value) {
            addCriterion("Position >", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Position >=", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionLessThan(BigDecimal value) {
            addCriterion("Position <", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Position <=", value, "position");
            return (Criteria) this;
        }

        public Criteria andPositionIn(List<BigDecimal> values) {
            addCriterion("Position in", values, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotIn(List<BigDecimal> values) {
            addCriterion("Position not in", values, "position");
            return (Criteria) this;
        }

        public Criteria andPositionBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Position between", value1, value2, "position");
            return (Criteria) this;
        }

        public Criteria andPositionNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Position not between", value1, value2, "position");
            return (Criteria) this;
        }

        public Criteria andTradepriceIsNull() {
            addCriterion("TradePrice is null");
            return (Criteria) this;
        }

        public Criteria andTradepriceIsNotNull() {
            addCriterion("TradePrice is not null");
            return (Criteria) this;
        }

        public Criteria andTradepriceEqualTo(BigDecimal value) {
            addCriterion("TradePrice =", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotEqualTo(BigDecimal value) {
            addCriterion("TradePrice <>", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceGreaterThan(BigDecimal value) {
            addCriterion("TradePrice >", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TradePrice >=", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceLessThan(BigDecimal value) {
            addCriterion("TradePrice <", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TradePrice <=", value, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceIn(List<BigDecimal> values) {
            addCriterion("TradePrice in", values, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotIn(List<BigDecimal> values) {
            addCriterion("TradePrice not in", values, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TradePrice between", value1, value2, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradepriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TradePrice not between", value1, value2, "tradeprice");
            return (Criteria) this;
        }

        public Criteria andTradeccyIsNull() {
            addCriterion("TradeCcy is null");
            return (Criteria) this;
        }

        public Criteria andTradeccyIsNotNull() {
            addCriterion("TradeCcy is not null");
            return (Criteria) this;
        }

        public Criteria andTradeccyEqualTo(String value) {
            addCriterion("TradeCcy =", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyNotEqualTo(String value) {
            addCriterion("TradeCcy <>", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyGreaterThan(String value) {
            addCriterion("TradeCcy >", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyGreaterThanOrEqualTo(String value) {
            addCriterion("TradeCcy >=", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyLessThan(String value) {
            addCriterion("TradeCcy <", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyLessThanOrEqualTo(String value) {
            addCriterion("TradeCcy <=", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyLike(String value) {
            addCriterion("TradeCcy like", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyNotLike(String value) {
            addCriterion("TradeCcy not like", value, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyIn(List<String> values) {
            addCriterion("TradeCcy in", values, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyNotIn(List<String> values) {
            addCriterion("TradeCcy not in", values, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyBetween(String value1, String value2) {
            addCriterion("TradeCcy between", value1, value2, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andTradeccyNotBetween(String value1, String value2) {
            addCriterion("TradeCcy not between", value1, value2, "tradeccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyIsNull() {
            addCriterion("SettleCcy is null");
            return (Criteria) this;
        }

        public Criteria andSettleccyIsNotNull() {
            addCriterion("SettleCcy is not null");
            return (Criteria) this;
        }

        public Criteria andSettleccyEqualTo(String value) {
            addCriterion("SettleCcy =", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyNotEqualTo(String value) {
            addCriterion("SettleCcy <>", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyGreaterThan(String value) {
            addCriterion("SettleCcy >", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyGreaterThanOrEqualTo(String value) {
            addCriterion("SettleCcy >=", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyLessThan(String value) {
            addCriterion("SettleCcy <", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyLessThanOrEqualTo(String value) {
            addCriterion("SettleCcy <=", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyLike(String value) {
            addCriterion("SettleCcy like", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyNotLike(String value) {
            addCriterion("SettleCcy not like", value, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyIn(List<String> values) {
            addCriterion("SettleCcy in", values, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyNotIn(List<String> values) {
            addCriterion("SettleCcy not in", values, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyBetween(String value1, String value2) {
            addCriterion("SettleCcy between", value1, value2, "settleccy");
            return (Criteria) this;
        }

        public Criteria andSettleccyNotBetween(String value1, String value2) {
            addCriterion("SettleCcy not between", value1, value2, "settleccy");
            return (Criteria) this;
        }

        public Criteria andTradedateIsNull() {
            addCriterion("TradeDate is null");
            return (Criteria) this;
        }

        public Criteria andTradedateIsNotNull() {
            addCriterion("TradeDate is not null");
            return (Criteria) this;
        }

        public Criteria andTradedateEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate =", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate <>", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateGreaterThan(Date value) {
            addCriterionForJDBCDate("TradeDate >", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate >=", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateLessThan(Date value) {
            addCriterionForJDBCDate("TradeDate <", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("TradeDate <=", value, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateIn(List<Date> values) {
            addCriterionForJDBCDate("TradeDate in", values, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("TradeDate not in", values, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("TradeDate between", value1, value2, "tradedate");
            return (Criteria) this;
        }

        public Criteria andTradedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("TradeDate not between", value1, value2, "tradedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateIsNull() {
            addCriterion("StrikeDate is null");
            return (Criteria) this;
        }

        public Criteria andStrikedateIsNotNull() {
            addCriterion("StrikeDate is not null");
            return (Criteria) this;
        }

        public Criteria andStrikedateEqualTo(Date value) {
            addCriterion("StrikeDate =", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateNotEqualTo(Date value) {
            addCriterion("StrikeDate <>", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateGreaterThan(Date value) {
            addCriterion("StrikeDate >", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateGreaterThanOrEqualTo(Date value) {
            addCriterion("StrikeDate >=", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateLessThan(Date value) {
            addCriterion("StrikeDate <", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateLessThanOrEqualTo(Date value) {
            addCriterion("StrikeDate <=", value, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateIn(List<Date> values) {
            addCriterion("StrikeDate in", values, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateNotIn(List<Date> values) {
            addCriterion("StrikeDate not in", values, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateBetween(Date value1, Date value2) {
            addCriterion("StrikeDate between", value1, value2, "strikedate");
            return (Criteria) this;
        }

        public Criteria andStrikedateNotBetween(Date value1, Date value2) {
            addCriterion("StrikeDate not between", value1, value2, "strikedate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIsNull() {
            addCriterion("SettlementDate is null");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIsNotNull() {
            addCriterion("SettlementDate is not null");
            return (Criteria) this;
        }

        public Criteria andSettlementdateEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate =", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate <>", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateGreaterThan(Date value) {
            addCriterionForJDBCDate("SettlementDate >", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate >=", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateLessThan(Date value) {
            addCriterionForJDBCDate("SettlementDate <", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("SettlementDate <=", value, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateIn(List<Date> values) {
            addCriterionForJDBCDate("SettlementDate in", values, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("SettlementDate not in", values, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("SettlementDate between", value1, value2, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andSettlementdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("SettlementDate not between", value1, value2, "settlementdate");
            return (Criteria) this;
        }

        public Criteria andExpirydateIsNull() {
            addCriterion("ExpiryDate is null");
            return (Criteria) this;
        }

        public Criteria andExpirydateIsNotNull() {
            addCriterion("ExpiryDate is not null");
            return (Criteria) this;
        }

        public Criteria andExpirydateEqualTo(Date value) {
            addCriterionForJDBCDate("ExpiryDate =", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateNotEqualTo(Date value) {
            addCriterionForJDBCDate("ExpiryDate <>", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateGreaterThan(Date value) {
            addCriterionForJDBCDate("ExpiryDate >", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ExpiryDate >=", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateLessThan(Date value) {
            addCriterionForJDBCDate("ExpiryDate <", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ExpiryDate <=", value, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateIn(List<Date> values) {
            addCriterionForJDBCDate("ExpiryDate in", values, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateNotIn(List<Date> values) {
            addCriterionForJDBCDate("ExpiryDate not in", values, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ExpiryDate between", value1, value2, "expirydate");
            return (Criteria) this;
        }

        public Criteria andExpirydateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ExpiryDate not between", value1, value2, "expirydate");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeIsNull() {
            addCriterion("SettlementType is null");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeIsNotNull() {
            addCriterion("SettlementType is not null");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeEqualTo(String value) {
            addCriterion("SettlementType =", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeNotEqualTo(String value) {
            addCriterion("SettlementType <>", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeGreaterThan(String value) {
            addCriterion("SettlementType >", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeGreaterThanOrEqualTo(String value) {
            addCriterion("SettlementType >=", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeLessThan(String value) {
            addCriterion("SettlementType <", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeLessThanOrEqualTo(String value) {
            addCriterion("SettlementType <=", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeLike(String value) {
            addCriterion("SettlementType like", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeNotLike(String value) {
            addCriterion("SettlementType not like", value, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeIn(List<String> values) {
            addCriterion("SettlementType in", values, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeNotIn(List<String> values) {
            addCriterion("SettlementType not in", values, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeBetween(String value1, String value2) {
            addCriterion("SettlementType between", value1, value2, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andSettlementtypeNotBetween(String value1, String value2) {
            addCriterion("SettlementType not between", value1, value2, "settlementtype");
            return (Criteria) this;
        }

        public Criteria andBizconvIsNull() {
            addCriterion("BizConv is null");
            return (Criteria) this;
        }

        public Criteria andBizconvIsNotNull() {
            addCriterion("BizConv is not null");
            return (Criteria) this;
        }

        public Criteria andBizconvEqualTo(Integer value) {
            addCriterion("BizConv =", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvNotEqualTo(Integer value) {
            addCriterion("BizConv <>", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvGreaterThan(Integer value) {
            addCriterion("BizConv >", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvGreaterThanOrEqualTo(Integer value) {
            addCriterion("BizConv >=", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvLessThan(Integer value) {
            addCriterion("BizConv <", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvLessThanOrEqualTo(Integer value) {
            addCriterion("BizConv <=", value, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvIn(List<Integer> values) {
            addCriterion("BizConv in", values, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvNotIn(List<Integer> values) {
            addCriterion("BizConv not in", values, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvBetween(Integer value1, Integer value2) {
            addCriterion("BizConv between", value1, value2, "bizconv");
            return (Criteria) this;
        }

        public Criteria andBizconvNotBetween(Integer value1, Integer value2) {
            addCriterion("BizConv not between", value1, value2, "bizconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvIsNull() {
            addCriterion("DaycountConv is null");
            return (Criteria) this;
        }

        public Criteria andDaycountconvIsNotNull() {
            addCriterion("DaycountConv is not null");
            return (Criteria) this;
        }

        public Criteria andDaycountconvEqualTo(String value) {
            addCriterion("DaycountConv =", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvNotEqualTo(String value) {
            addCriterion("DaycountConv <>", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvGreaterThan(String value) {
            addCriterion("DaycountConv >", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvGreaterThanOrEqualTo(String value) {
            addCriterion("DaycountConv >=", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvLessThan(String value) {
            addCriterion("DaycountConv <", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvLessThanOrEqualTo(String value) {
            addCriterion("DaycountConv <=", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvLike(String value) {
            addCriterion("DaycountConv like", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvNotLike(String value) {
            addCriterion("DaycountConv not like", value, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvIn(List<String> values) {
            addCriterion("DaycountConv in", values, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvNotIn(List<String> values) {
            addCriterion("DaycountConv not in", values, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvBetween(String value1, String value2) {
            addCriterion("DaycountConv between", value1, value2, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andDaycountconvNotBetween(String value1, String value2) {
            addCriterion("DaycountConv not between", value1, value2, "daycountconv");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidIsNull() {
            addCriterion("CounterpartyID is null");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidIsNotNull() {
            addCriterion("CounterpartyID is not null");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidEqualTo(String value) {
            addCriterion("CounterpartyID =", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidNotEqualTo(String value) {
            addCriterion("CounterpartyID <>", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidGreaterThan(String value) {
            addCriterion("CounterpartyID >", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidGreaterThanOrEqualTo(String value) {
            addCriterion("CounterpartyID >=", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidLessThan(String value) {
            addCriterion("CounterpartyID <", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidLessThanOrEqualTo(String value) {
            addCriterion("CounterpartyID <=", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidLike(String value) {
            addCriterion("CounterpartyID like", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidNotLike(String value) {
            addCriterion("CounterpartyID not like", value, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidIn(List<String> values) {
            addCriterion("CounterpartyID in", values, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidNotIn(List<String> values) {
            addCriterion("CounterpartyID not in", values, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidBetween(String value1, String value2) {
            addCriterion("CounterpartyID between", value1, value2, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andCounterpartyidNotBetween(String value1, String value2) {
            addCriterion("CounterpartyID not between", value1, value2, "counterpartyid");
            return (Criteria) this;
        }

        public Criteria andSalesidIsNull() {
            addCriterion("SalesID is null");
            return (Criteria) this;
        }

        public Criteria andSalesidIsNotNull() {
            addCriterion("SalesID is not null");
            return (Criteria) this;
        }

        public Criteria andSalesidEqualTo(String value) {
            addCriterion("SalesID =", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidNotEqualTo(String value) {
            addCriterion("SalesID <>", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidGreaterThan(String value) {
            addCriterion("SalesID >", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidGreaterThanOrEqualTo(String value) {
            addCriterion("SalesID >=", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidLessThan(String value) {
            addCriterion("SalesID <", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidLessThanOrEqualTo(String value) {
            addCriterion("SalesID <=", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidLike(String value) {
            addCriterion("SalesID like", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidNotLike(String value) {
            addCriterion("SalesID not like", value, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidIn(List<String> values) {
            addCriterion("SalesID in", values, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidNotIn(List<String> values) {
            addCriterion("SalesID not in", values, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidBetween(String value1, String value2) {
            addCriterion("SalesID between", value1, value2, "salesid");
            return (Criteria) this;
        }

        public Criteria andSalesidNotBetween(String value1, String value2) {
            addCriterion("SalesID not between", value1, value2, "salesid");
            return (Criteria) this;
        }

        public Criteria andEdgeIsNull() {
            addCriterion("Edge is null");
            return (Criteria) this;
        }

        public Criteria andEdgeIsNotNull() {
            addCriterion("Edge is not null");
            return (Criteria) this;
        }

        public Criteria andEdgeEqualTo(BigDecimal value) {
            addCriterion("Edge =", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeNotEqualTo(BigDecimal value) {
            addCriterion("Edge <>", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeGreaterThan(BigDecimal value) {
            addCriterion("Edge >", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Edge >=", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeLessThan(BigDecimal value) {
            addCriterion("Edge <", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Edge <=", value, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeIn(List<BigDecimal> values) {
            addCriterion("Edge in", values, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeNotIn(List<BigDecimal> values) {
            addCriterion("Edge not in", values, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Edge between", value1, value2, "edge");
            return (Criteria) this;
        }

        public Criteria andEdgeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Edge not between", value1, value2, "edge");
            return (Criteria) this;
        }

        public Criteria andFixingrecordIsNull() {
            addCriterion("FixingRecord is null");
            return (Criteria) this;
        }

        public Criteria andFixingrecordIsNotNull() {
            addCriterion("FixingRecord is not null");
            return (Criteria) this;
        }

        public Criteria andFixingrecordEqualTo(Boolean value) {
            addCriterion("FixingRecord =", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordNotEqualTo(Boolean value) {
            addCriterion("FixingRecord <>", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordGreaterThan(Boolean value) {
            addCriterion("FixingRecord >", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordGreaterThanOrEqualTo(Boolean value) {
            addCriterion("FixingRecord >=", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordLessThan(Boolean value) {
            addCriterion("FixingRecord <", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordLessThanOrEqualTo(Boolean value) {
            addCriterion("FixingRecord <=", value, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordIn(List<Boolean> values) {
            addCriterion("FixingRecord in", values, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordNotIn(List<Boolean> values) {
            addCriterion("FixingRecord not in", values, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordBetween(Boolean value1, Boolean value2) {
            addCriterion("FixingRecord between", value1, value2, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andFixingrecordNotBetween(Boolean value1, Boolean value2) {
            addCriterion("FixingRecord not between", value1, value2, "fixingrecord");
            return (Criteria) this;
        }

        public Criteria andQuantoflagIsNull() {
            addCriterion("QuantoFlag is null");
            return (Criteria) this;
        }

        public Criteria andQuantoflagIsNotNull() {
            addCriterion("QuantoFlag is not null");
            return (Criteria) this;
        }

        public Criteria andQuantoflagEqualTo(Integer value) {
            addCriterion("QuantoFlag =", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagNotEqualTo(Integer value) {
            addCriterion("QuantoFlag <>", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagGreaterThan(Integer value) {
            addCriterion("QuantoFlag >", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("QuantoFlag >=", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagLessThan(Integer value) {
            addCriterion("QuantoFlag <", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagLessThanOrEqualTo(Integer value) {
            addCriterion("QuantoFlag <=", value, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagIn(List<Integer> values) {
            addCriterion("QuantoFlag in", values, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagNotIn(List<Integer> values) {
            addCriterion("QuantoFlag not in", values, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagBetween(Integer value1, Integer value2) {
            addCriterion("QuantoFlag between", value1, value2, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andQuantoflagNotBetween(Integer value1, Integer value2) {
            addCriterion("QuantoFlag not between", value1, value2, "quantoflag");
            return (Criteria) this;
        }

        public Criteria andInitialmarginIsNull() {
            addCriterion("InitialMargin is null");
            return (Criteria) this;
        }

        public Criteria andInitialmarginIsNotNull() {
            addCriterion("InitialMargin is not null");
            return (Criteria) this;
        }

        public Criteria andInitialmarginEqualTo(BigDecimal value) {
            addCriterion("InitialMargin =", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginNotEqualTo(BigDecimal value) {
            addCriterion("InitialMargin <>", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginGreaterThan(BigDecimal value) {
            addCriterion("InitialMargin >", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("InitialMargin >=", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginLessThan(BigDecimal value) {
            addCriterion("InitialMargin <", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginLessThanOrEqualTo(BigDecimal value) {
            addCriterion("InitialMargin <=", value, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginIn(List<BigDecimal> values) {
            addCriterion("InitialMargin in", values, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginNotIn(List<BigDecimal> values) {
            addCriterion("InitialMargin not in", values, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("InitialMargin between", value1, value2, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andInitialmarginNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("InitialMargin not between", value1, value2, "initialmargin");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelIsNull() {
            addCriterion("MarginWarningLevel is null");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelIsNotNull() {
            addCriterion("MarginWarningLevel is not null");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelEqualTo(BigDecimal value) {
            addCriterion("MarginWarningLevel =", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelNotEqualTo(BigDecimal value) {
            addCriterion("MarginWarningLevel <>", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelGreaterThan(BigDecimal value) {
            addCriterion("MarginWarningLevel >", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginWarningLevel >=", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelLessThan(BigDecimal value) {
            addCriterion("MarginWarningLevel <", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginWarningLevel <=", value, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelIn(List<BigDecimal> values) {
            addCriterion("MarginWarningLevel in", values, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelNotIn(List<BigDecimal> values) {
            addCriterion("MarginWarningLevel not in", values, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginWarningLevel between", value1, value2, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMarginwarninglevelNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginWarningLevel not between", value1, value2, "marginwarninglevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelIsNull() {
            addCriterion("MarginCallLevel is null");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelIsNotNull() {
            addCriterion("MarginCallLevel is not null");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelEqualTo(BigDecimal value) {
            addCriterion("MarginCallLevel =", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelNotEqualTo(BigDecimal value) {
            addCriterion("MarginCallLevel <>", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelGreaterThan(BigDecimal value) {
            addCriterion("MarginCallLevel >", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginCallLevel >=", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelLessThan(BigDecimal value) {
            addCriterion("MarginCallLevel <", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginCallLevel <=", value, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelIn(List<BigDecimal> values) {
            addCriterion("MarginCallLevel in", values, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelNotIn(List<BigDecimal> values) {
            addCriterion("MarginCallLevel not in", values, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginCallLevel between", value1, value2, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andMargincalllevelNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginCallLevel not between", value1, value2, "margincalllevel");
            return (Criteria) this;
        }

        public Criteria andDivadjustIsNull() {
            addCriterion("DivAdjust is null");
            return (Criteria) this;
        }

        public Criteria andDivadjustIsNotNull() {
            addCriterion("DivAdjust is not null");
            return (Criteria) this;
        }

        public Criteria andDivadjustEqualTo(Boolean value) {
            addCriterion("DivAdjust =", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustNotEqualTo(Boolean value) {
            addCriterion("DivAdjust <>", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustGreaterThan(Boolean value) {
            addCriterion("DivAdjust >", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustGreaterThanOrEqualTo(Boolean value) {
            addCriterion("DivAdjust >=", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustLessThan(Boolean value) {
            addCriterion("DivAdjust <", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustLessThanOrEqualTo(Boolean value) {
            addCriterion("DivAdjust <=", value, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustIn(List<Boolean> values) {
            addCriterion("DivAdjust in", values, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustNotIn(List<Boolean> values) {
            addCriterion("DivAdjust not in", values, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustBetween(Boolean value1, Boolean value2) {
            addCriterion("DivAdjust between", value1, value2, "divadjust");
            return (Criteria) this;
        }

        public Criteria andDivadjustNotBetween(Boolean value1, Boolean value2) {
            addCriterion("DivAdjust not between", value1, value2, "divadjust");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelIsNull() {
            addCriterion("LiquidationLevel is null");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelIsNotNull() {
            addCriterion("LiquidationLevel is not null");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelEqualTo(BigDecimal value) {
            addCriterion("LiquidationLevel =", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelNotEqualTo(BigDecimal value) {
            addCriterion("LiquidationLevel <>", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelGreaterThan(BigDecimal value) {
            addCriterion("LiquidationLevel >", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("LiquidationLevel >=", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelLessThan(BigDecimal value) {
            addCriterion("LiquidationLevel <", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelLessThanOrEqualTo(BigDecimal value) {
            addCriterion("LiquidationLevel <=", value, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelIn(List<BigDecimal> values) {
            addCriterion("LiquidationLevel in", values, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelNotIn(List<BigDecimal> values) {
            addCriterion("LiquidationLevel not in", values, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("LiquidationLevel between", value1, value2, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andLiquidationlevelNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("LiquidationLevel not between", value1, value2, "liquidationlevel");
            return (Criteria) this;
        }

        public Criteria andMarginnetIsNull() {
            addCriterion("MarginNet is null");
            return (Criteria) this;
        }

        public Criteria andMarginnetIsNotNull() {
            addCriterion("MarginNet is not null");
            return (Criteria) this;
        }

        public Criteria andMarginnetEqualTo(Boolean value) {
            addCriterion("MarginNet =", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetNotEqualTo(Boolean value) {
            addCriterion("MarginNet <>", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetGreaterThan(Boolean value) {
            addCriterion("MarginNet >", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetGreaterThanOrEqualTo(Boolean value) {
            addCriterion("MarginNet >=", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetLessThan(Boolean value) {
            addCriterion("MarginNet <", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetLessThanOrEqualTo(Boolean value) {
            addCriterion("MarginNet <=", value, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetIn(List<Boolean> values) {
            addCriterion("MarginNet in", values, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetNotIn(List<Boolean> values) {
            addCriterion("MarginNet not in", values, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetBetween(Boolean value1, Boolean value2) {
            addCriterion("MarginNet between", value1, value2, "marginnet");
            return (Criteria) this;
        }

        public Criteria andMarginnetNotBetween(Boolean value1, Boolean value2) {
            addCriterion("MarginNet not between", value1, value2, "marginnet");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathIsNull() {
            addCriterion("JsonFilePath is null");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathIsNotNull() {
            addCriterion("JsonFilePath is not null");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathEqualTo(String value) {
            addCriterion("JsonFilePath =", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathNotEqualTo(String value) {
            addCriterion("JsonFilePath <>", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathGreaterThan(String value) {
            addCriterion("JsonFilePath >", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathGreaterThanOrEqualTo(String value) {
            addCriterion("JsonFilePath >=", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathLessThan(String value) {
            addCriterion("JsonFilePath <", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathLessThanOrEqualTo(String value) {
            addCriterion("JsonFilePath <=", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathLike(String value) {
            addCriterion("JsonFilePath like", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathNotLike(String value) {
            addCriterion("JsonFilePath not like", value, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathIn(List<String> values) {
            addCriterion("JsonFilePath in", values, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathNotIn(List<String> values) {
            addCriterion("JsonFilePath not in", values, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathBetween(String value1, String value2) {
            addCriterion("JsonFilePath between", value1, value2, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andJsonfilepathNotBetween(String value1, String value2) {
            addCriterion("JsonFilePath not between", value1, value2, "jsonfilepath");
            return (Criteria) this;
        }

        public Criteria andFxfixingIsNull() {
            addCriterion("FXFixing is null");
            return (Criteria) this;
        }

        public Criteria andFxfixingIsNotNull() {
            addCriterion("FXFixing is not null");
            return (Criteria) this;
        }

        public Criteria andFxfixingEqualTo(String value) {
            addCriterion("FXFixing =", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingNotEqualTo(String value) {
            addCriterion("FXFixing <>", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingGreaterThan(String value) {
            addCriterion("FXFixing >", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingGreaterThanOrEqualTo(String value) {
            addCriterion("FXFixing >=", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingLessThan(String value) {
            addCriterion("FXFixing <", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingLessThanOrEqualTo(String value) {
            addCriterion("FXFixing <=", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingLike(String value) {
            addCriterion("FXFixing like", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingNotLike(String value) {
            addCriterion("FXFixing not like", value, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingIn(List<String> values) {
            addCriterion("FXFixing in", values, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingNotIn(List<String> values) {
            addCriterion("FXFixing not in", values, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingBetween(String value1, String value2) {
            addCriterion("FXFixing between", value1, value2, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andFxfixingNotBetween(String value1, String value2) {
            addCriterion("FXFixing not between", value1, value2, "fxfixing");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNull() {
            addCriterion("LastUpdateUser is null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIsNotNull() {
            addCriterion("LastUpdateUser is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserEqualTo(String value) {
            addCriterion("LastUpdateUser =", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotEqualTo(String value) {
            addCriterion("LastUpdateUser <>", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThan(String value) {
            addCriterion("LastUpdateUser >", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser >=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThan(String value) {
            addCriterion("LastUpdateUser <", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLessThanOrEqualTo(String value) {
            addCriterion("LastUpdateUser <=", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserLike(String value) {
            addCriterion("LastUpdateUser like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotLike(String value) {
            addCriterion("LastUpdateUser not like", value, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserIn(List<String> values) {
            addCriterion("LastUpdateUser in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotIn(List<String> values) {
            addCriterion("LastUpdateUser not in", values, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserBetween(String value1, String value2) {
            addCriterion("LastUpdateUser between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdateuserNotBetween(String value1, String value2) {
            addCriterion("LastUpdateUser not between", value1, value2, "lastupdateuser");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNull() {
            addCriterion("LastUpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIsNotNull() {
            addCriterion("LastUpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeEqualTo(Date value) {
            addCriterion("LastUpdateTime =", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotEqualTo(Date value) {
            addCriterion("LastUpdateTime <>", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThan(Date value) {
            addCriterion("LastUpdateTime >", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime >=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThan(Date value) {
            addCriterion("LastUpdateTime <", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("LastUpdateTime <=", value, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeIn(List<Date> values) {
            addCriterion("LastUpdateTime in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotIn(List<Date> values) {
            addCriterion("LastUpdateTime not in", values, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andLastupdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("LastUpdateTime not between", value1, value2, "lastupdatetime");
            return (Criteria) this;
        }

        public Criteria andUndlroundingIsNull() {
            addCriterion("UndlRounding is null");
            return (Criteria) this;
        }

        public Criteria andUndlroundingIsNotNull() {
            addCriterion("UndlRounding is not null");
            return (Criteria) this;
        }

        public Criteria andUndlroundingEqualTo(Integer value) {
            addCriterion("UndlRounding =", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingNotEqualTo(Integer value) {
            addCriterion("UndlRounding <>", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingGreaterThan(Integer value) {
            addCriterion("UndlRounding >", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingGreaterThanOrEqualTo(Integer value) {
            addCriterion("UndlRounding >=", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingLessThan(Integer value) {
            addCriterion("UndlRounding <", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingLessThanOrEqualTo(Integer value) {
            addCriterion("UndlRounding <=", value, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingIn(List<Integer> values) {
            addCriterion("UndlRounding in", values, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingNotIn(List<Integer> values) {
            addCriterion("UndlRounding not in", values, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingBetween(Integer value1, Integer value2) {
            addCriterion("UndlRounding between", value1, value2, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andUndlroundingNotBetween(Integer value1, Integer value2) {
            addCriterion("UndlRounding not between", value1, value2, "undlrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingIsNull() {
            addCriterion("PayoffRounding is null");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingIsNotNull() {
            addCriterion("PayoffRounding is not null");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingEqualTo(Integer value) {
            addCriterion("PayoffRounding =", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingNotEqualTo(Integer value) {
            addCriterion("PayoffRounding <>", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingGreaterThan(Integer value) {
            addCriterion("PayoffRounding >", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingGreaterThanOrEqualTo(Integer value) {
            addCriterion("PayoffRounding >=", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingLessThan(Integer value) {
            addCriterion("PayoffRounding <", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingLessThanOrEqualTo(Integer value) {
            addCriterion("PayoffRounding <=", value, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingIn(List<Integer> values) {
            addCriterion("PayoffRounding in", values, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingNotIn(List<Integer> values) {
            addCriterion("PayoffRounding not in", values, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingBetween(Integer value1, Integer value2) {
            addCriterion("PayoffRounding between", value1, value2, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andPayoffroundingNotBetween(Integer value1, Integer value2) {
            addCriterion("PayoffRounding not between", value1, value2, "payoffrounding");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalIsNull() {
            addCriterion("ReportingNotional is null");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalIsNotNull() {
            addCriterion("ReportingNotional is not null");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalEqualTo(BigDecimal value) {
            addCriterion("ReportingNotional =", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalNotEqualTo(BigDecimal value) {
            addCriterion("ReportingNotional <>", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalGreaterThan(BigDecimal value) {
            addCriterion("ReportingNotional >", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ReportingNotional >=", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalLessThan(BigDecimal value) {
            addCriterion("ReportingNotional <", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ReportingNotional <=", value, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalIn(List<BigDecimal> values) {
            addCriterion("ReportingNotional in", values, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalNotIn(List<BigDecimal> values) {
            addCriterion("ReportingNotional not in", values, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ReportingNotional between", value1, value2, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andReportingnotionalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ReportingNotional not between", value1, value2, "reportingnotional");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNull() {
            addCriterion("CheckStatus is null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNotNull() {
            addCriterion("CheckStatus is not null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusEqualTo(Integer value) {
            addCriterion("CheckStatus =", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotEqualTo(Integer value) {
            addCriterion("CheckStatus <>", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThan(Integer value) {
            addCriterion("CheckStatus >", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("CheckStatus >=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThan(Integer value) {
            addCriterion("CheckStatus <", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThanOrEqualTo(Integer value) {
            addCriterion("CheckStatus <=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIn(List<Integer> values) {
            addCriterion("CheckStatus in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotIn(List<Integer> values) {
            addCriterion("CheckStatus not in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusBetween(Integer value1, Integer value2) {
            addCriterion("CheckStatus between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("CheckStatus not between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("Comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("Comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(String value) {
            addCriterion("Comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(String value) {
            addCriterion("Comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(String value) {
            addCriterion("Comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(String value) {
            addCriterion("Comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(String value) {
            addCriterion("Comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(String value) {
            addCriterion("Comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLike(String value) {
            addCriterion("Comment like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotLike(String value) {
            addCriterion("Comment not like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<String> values) {
            addCriterion("Comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<String> values) {
            addCriterion("Comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(String value1, String value2) {
            addCriterion("Comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(String value1, String value2) {
            addCriterion("Comment not between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCheckeridIsNull() {
            addCriterion("CheckerId is null");
            return (Criteria) this;
        }

        public Criteria andCheckeridIsNotNull() {
            addCriterion("CheckerId is not null");
            return (Criteria) this;
        }

        public Criteria andCheckeridEqualTo(String value) {
            addCriterion("CheckerId =", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotEqualTo(String value) {
            addCriterion("CheckerId <>", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridGreaterThan(String value) {
            addCriterion("CheckerId >", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridGreaterThanOrEqualTo(String value) {
            addCriterion("CheckerId >=", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLessThan(String value) {
            addCriterion("CheckerId <", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLessThanOrEqualTo(String value) {
            addCriterion("CheckerId <=", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridLike(String value) {
            addCriterion("CheckerId like", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotLike(String value) {
            addCriterion("CheckerId not like", value, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridIn(List<String> values) {
            addCriterion("CheckerId in", values, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotIn(List<String> values) {
            addCriterion("CheckerId not in", values, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridBetween(String value1, String value2) {
            addCriterion("CheckerId between", value1, value2, "checkerid");
            return (Criteria) this;
        }

        public Criteria andCheckeridNotBetween(String value1, String value2) {
            addCriterion("CheckerId not between", value1, value2, "checkerid");
            return (Criteria) this;
        }

        public Criteria andChecktimeIsNull() {
            addCriterion("CheckTime is null");
            return (Criteria) this;
        }

        public Criteria andChecktimeIsNotNull() {
            addCriterion("CheckTime is not null");
            return (Criteria) this;
        }

        public Criteria andChecktimeEqualTo(Date value) {
            addCriterion("CheckTime =", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotEqualTo(Date value) {
            addCriterion("CheckTime <>", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeGreaterThan(Date value) {
            addCriterion("CheckTime >", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CheckTime >=", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeLessThan(Date value) {
            addCriterion("CheckTime <", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeLessThanOrEqualTo(Date value) {
            addCriterion("CheckTime <=", value, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeIn(List<Date> values) {
            addCriterion("CheckTime in", values, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotIn(List<Date> values) {
            addCriterion("CheckTime not in", values, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeBetween(Date value1, Date value2) {
            addCriterion("CheckTime between", value1, value2, "checktime");
            return (Criteria) this;
        }

        public Criteria andChecktimeNotBetween(Date value1, Date value2) {
            addCriterion("CheckTime not between", value1, value2, "checktime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}