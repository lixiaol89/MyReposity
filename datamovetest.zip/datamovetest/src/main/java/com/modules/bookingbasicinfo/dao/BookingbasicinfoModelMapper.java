package com.modules.bookingbasicinfo.dao;

import com.modules.bookingbasicinfo.model.BookingbasicinfoModel;
import com.modules.bookingbasicinfo.model.BookingbasicinfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BookingbasicinfoModelMapper {
    int countByExample(BookingbasicinfoModelExample example);

    int deleteByExample(BookingbasicinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BookingbasicinfoModel record);

    int insertSelective(BookingbasicinfoModel record);

    List<BookingbasicinfoModel> selectByExampleWithBLOBs(BookingbasicinfoModelExample example);

    List<BookingbasicinfoModel> selectByExample(BookingbasicinfoModelExample example);

    BookingbasicinfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BookingbasicinfoModel record, @Param("example") BookingbasicinfoModelExample example);

    int updateByExampleWithBLOBs(@Param("record") BookingbasicinfoModel record, @Param("example") BookingbasicinfoModelExample example);

    int updateByExample(@Param("record") BookingbasicinfoModel record, @Param("example") BookingbasicinfoModelExample example);

    int updateByPrimaryKeySelective(BookingbasicinfoModel record);

    int updateByPrimaryKeyWithBLOBs(BookingbasicinfoModel record);

    int updateByPrimaryKey(BookingbasicinfoModel record);
}