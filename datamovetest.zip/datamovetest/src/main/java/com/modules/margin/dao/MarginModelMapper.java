package com.modules.margin.dao;

import com.modules.margin.model.MarginModel;
import com.modules.margin.model.MarginModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MarginModelMapper {
    int countByExample(MarginModelExample example);

    int deleteByExample(MarginModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(MarginModel record);

    int insertSelective(MarginModel record);

    List<MarginModel> selectByExample(MarginModelExample example);

    MarginModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") MarginModel record, @Param("example") MarginModelExample example);

    int updateByExample(@Param("record") MarginModel record, @Param("example") MarginModelExample example);

    int updateByPrimaryKeySelective(MarginModel record);

    int updateByPrimaryKey(MarginModel record);
}