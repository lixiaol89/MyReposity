package com.modules.margin.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class MarginModelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public MarginModelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andClientidIsNull() {
            addCriterion("ClientID is null");
            return (Criteria) this;
        }

        public Criteria andClientidIsNotNull() {
            addCriterion("ClientID is not null");
            return (Criteria) this;
        }

        public Criteria andClientidEqualTo(String value) {
            addCriterion("ClientID =", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotEqualTo(String value) {
            addCriterion("ClientID <>", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidGreaterThan(String value) {
            addCriterion("ClientID >", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidGreaterThanOrEqualTo(String value) {
            addCriterion("ClientID >=", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLessThan(String value) {
            addCriterion("ClientID <", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLessThanOrEqualTo(String value) {
            addCriterion("ClientID <=", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidLike(String value) {
            addCriterion("ClientID like", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotLike(String value) {
            addCriterion("ClientID not like", value, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidIn(List<String> values) {
            addCriterion("ClientID in", values, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotIn(List<String> values) {
            addCriterion("ClientID not in", values, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidBetween(String value1, String value2) {
            addCriterion("ClientID between", value1, value2, "clientid");
            return (Criteria) this;
        }

        public Criteria andClientidNotBetween(String value1, String value2) {
            addCriterion("ClientID not between", value1, value2, "clientid");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceIsNull() {
            addCriterion("MarginBalance is null");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceIsNotNull() {
            addCriterion("MarginBalance is not null");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceEqualTo(BigDecimal value) {
            addCriterion("MarginBalance =", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceNotEqualTo(BigDecimal value) {
            addCriterion("MarginBalance <>", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceGreaterThan(BigDecimal value) {
            addCriterion("MarginBalance >", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginBalance >=", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceLessThan(BigDecimal value) {
            addCriterion("MarginBalance <", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MarginBalance <=", value, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceIn(List<BigDecimal> values) {
            addCriterion("MarginBalance in", values, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceNotIn(List<BigDecimal> values) {
            addCriterion("MarginBalance not in", values, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginBalance between", value1, value2, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMarginbalanceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MarginBalance not between", value1, value2, "marginbalance");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginIsNull() {
            addCriterion("MaintenanceMargin is null");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginIsNotNull() {
            addCriterion("MaintenanceMargin is not null");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginEqualTo(BigDecimal value) {
            addCriterion("MaintenanceMargin =", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginNotEqualTo(BigDecimal value) {
            addCriterion("MaintenanceMargin <>", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginGreaterThan(BigDecimal value) {
            addCriterion("MaintenanceMargin >", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MaintenanceMargin >=", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginLessThan(BigDecimal value) {
            addCriterion("MaintenanceMargin <", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MaintenanceMargin <=", value, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginIn(List<BigDecimal> values) {
            addCriterion("MaintenanceMargin in", values, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginNotIn(List<BigDecimal> values) {
            addCriterion("MaintenanceMargin not in", values, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MaintenanceMargin between", value1, value2, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andMaintenancemarginNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MaintenanceMargin not between", value1, value2, "maintenancemargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginIsNull() {
            addCriterion("FreezedMargin is null");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginIsNotNull() {
            addCriterion("FreezedMargin is not null");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginEqualTo(BigDecimal value) {
            addCriterion("FreezedMargin =", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginNotEqualTo(BigDecimal value) {
            addCriterion("FreezedMargin <>", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginGreaterThan(BigDecimal value) {
            addCriterion("FreezedMargin >", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FreezedMargin >=", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginLessThan(BigDecimal value) {
            addCriterion("FreezedMargin <", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FreezedMargin <=", value, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginIn(List<BigDecimal> values) {
            addCriterion("FreezedMargin in", values, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginNotIn(List<BigDecimal> values) {
            addCriterion("FreezedMargin not in", values, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FreezedMargin between", value1, value2, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andFreezedmarginNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FreezedMargin not between", value1, value2, "freezedmargin");
            return (Criteria) this;
        }

        public Criteria andOtherassetIsNull() {
            addCriterion("OtherAsset is null");
            return (Criteria) this;
        }

        public Criteria andOtherassetIsNotNull() {
            addCriterion("OtherAsset is not null");
            return (Criteria) this;
        }

        public Criteria andOtherassetEqualTo(BigDecimal value) {
            addCriterion("OtherAsset =", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetNotEqualTo(BigDecimal value) {
            addCriterion("OtherAsset <>", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetGreaterThan(BigDecimal value) {
            addCriterion("OtherAsset >", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("OtherAsset >=", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetLessThan(BigDecimal value) {
            addCriterion("OtherAsset <", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetLessThanOrEqualTo(BigDecimal value) {
            addCriterion("OtherAsset <=", value, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetIn(List<BigDecimal> values) {
            addCriterion("OtherAsset in", values, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetNotIn(List<BigDecimal> values) {
            addCriterion("OtherAsset not in", values, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OtherAsset between", value1, value2, "otherasset");
            return (Criteria) this;
        }

        public Criteria andOtherassetNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OtherAsset not between", value1, value2, "otherasset");
            return (Criteria) this;
        }

        public Criteria andCurrencyIsNull() {
            addCriterion("Currency is null");
            return (Criteria) this;
        }

        public Criteria andCurrencyIsNotNull() {
            addCriterion("Currency is not null");
            return (Criteria) this;
        }

        public Criteria andCurrencyEqualTo(String value) {
            addCriterion("Currency =", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotEqualTo(String value) {
            addCriterion("Currency <>", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyGreaterThan(String value) {
            addCriterion("Currency >", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyGreaterThanOrEqualTo(String value) {
            addCriterion("Currency >=", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLessThan(String value) {
            addCriterion("Currency <", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLessThanOrEqualTo(String value) {
            addCriterion("Currency <=", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyLike(String value) {
            addCriterion("Currency like", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotLike(String value) {
            addCriterion("Currency not like", value, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyIn(List<String> values) {
            addCriterion("Currency in", values, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotIn(List<String> values) {
            addCriterion("Currency not in", values, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyBetween(String value1, String value2) {
            addCriterion("Currency between", value1, value2, "currency");
            return (Criteria) this;
        }

        public Criteria andCurrencyNotBetween(String value1, String value2) {
            addCriterion("Currency not between", value1, value2, "currency");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("Comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("Comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(String value) {
            addCriterion("Comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(String value) {
            addCriterion("Comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(String value) {
            addCriterion("Comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(String value) {
            addCriterion("Comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(String value) {
            addCriterion("Comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(String value) {
            addCriterion("Comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLike(String value) {
            addCriterion("Comment like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotLike(String value) {
            addCriterion("Comment not like", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<String> values) {
            addCriterion("Comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<String> values) {
            addCriterion("Comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(String value1, String value2) {
            addCriterion("Comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(String value1, String value2) {
            addCriterion("Comment not between", value1, value2, "comment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}