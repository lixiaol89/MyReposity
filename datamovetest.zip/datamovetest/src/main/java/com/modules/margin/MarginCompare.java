package com.modules.margin;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.margin.dao.MarginModelMapper;
import com.modules.margin.model.MarginModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class MarginCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		MarginModelMapper sourcemapper = GetDataSource.getMapper(MarginModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		MarginModelMapper targetmapper = GetDataSource.getMapper(MarginModelMapper.class, sessionqa);
		
		
		List<MarginModel> source = sourcemapper.selectByExample(null);
		List<MarginModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<MarginModel> same = new ArrayList<MarginModel>();
		for(MarginModel targetmodel : target){
			for(MarginModel sourcemodel : source){
				if(targetmodel.getClientid().equals(sourcemodel.getClientid())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(MarginModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(MarginModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new MarginCompare().compare();
	}


}
