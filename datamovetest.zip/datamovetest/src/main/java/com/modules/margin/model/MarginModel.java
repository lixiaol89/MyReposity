package com.modules.margin.model;

import java.math.BigDecimal;

public class MarginModel {
    private Integer id;

    private String clientid;

    private BigDecimal marginbalance;

    private BigDecimal maintenancemargin;

    private BigDecimal freezedmargin;

    private BigDecimal otherasset;

    private String currency;

    private String comment;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClientid() {
        return clientid;
    }

    public void setClientid(String clientid) {
        this.clientid = clientid == null ? null : clientid.trim();
    }

    public BigDecimal getMarginbalance() {
        return marginbalance;
    }

    public void setMarginbalance(BigDecimal marginbalance) {
        this.marginbalance = marginbalance;
    }

    public BigDecimal getMaintenancemargin() {
        return maintenancemargin;
    }

    public void setMaintenancemargin(BigDecimal maintenancemargin) {
        this.maintenancemargin = maintenancemargin;
    }

    public BigDecimal getFreezedmargin() {
        return freezedmargin;
    }

    public void setFreezedmargin(BigDecimal freezedmargin) {
        this.freezedmargin = freezedmargin;
    }

    public BigDecimal getOtherasset() {
        return otherasset;
    }

    public void setOtherasset(BigDecimal otherasset) {
        this.otherasset = otherasset;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment == null ? null : comment.trim();
    }
}