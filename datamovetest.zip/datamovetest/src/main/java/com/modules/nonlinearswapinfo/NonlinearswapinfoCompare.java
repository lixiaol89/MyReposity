package com.modules.nonlinearswapinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.nonlinearswapinfo.dao.NonlinearswapinfoModelMapper;
import com.modules.nonlinearswapinfo.model.NonlinearswapinfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class NonlinearswapinfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		NonlinearswapinfoModelMapper sourcemapper = GetDataSource.getMapper(NonlinearswapinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		NonlinearswapinfoModelMapper targetmapper = GetDataSource.getMapper(NonlinearswapinfoModelMapper.class, sessionqa);
		
		
		List<NonlinearswapinfoModel> source = sourcemapper.selectByExample(null);
		List<NonlinearswapinfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<NonlinearswapinfoModel> same = new ArrayList<NonlinearswapinfoModel>();
		for(NonlinearswapinfoModel targetmodel : target){
			for(NonlinearswapinfoModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(NonlinearswapinfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(NonlinearswapinfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new NonlinearswapinfoCompare().compare();
	}


}
