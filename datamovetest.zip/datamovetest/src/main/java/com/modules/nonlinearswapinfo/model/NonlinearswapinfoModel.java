package com.modules.nonlinearswapinfo.model;

import java.math.BigDecimal;
import java.util.Date;

public class NonlinearswapinfoModel {
    private Integer id;

    private String tradeid;

    private BigDecimal strike;

    private BigDecimal fixedrate;

    private BigDecimal yearfrac;

    private BigDecimal floatingrateshift;

    private BigDecimal pr;

    private BigDecimal commissionrate;

    private String fundingccy;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public BigDecimal getStrike() {
        return strike;
    }

    public void setStrike(BigDecimal strike) {
        this.strike = strike;
    }

    public BigDecimal getFixedrate() {
        return fixedrate;
    }

    public void setFixedrate(BigDecimal fixedrate) {
        this.fixedrate = fixedrate;
    }

    public BigDecimal getYearfrac() {
        return yearfrac;
    }

    public void setYearfrac(BigDecimal yearfrac) {
        this.yearfrac = yearfrac;
    }

    public BigDecimal getFloatingrateshift() {
        return floatingrateshift;
    }

    public void setFloatingrateshift(BigDecimal floatingrateshift) {
        this.floatingrateshift = floatingrateshift;
    }

    public BigDecimal getPr() {
        return pr;
    }

    public void setPr(BigDecimal pr) {
        this.pr = pr;
    }

    public BigDecimal getCommissionrate() {
        return commissionrate;
    }

    public void setCommissionrate(BigDecimal commissionrate) {
        this.commissionrate = commissionrate;
    }

    public String getFundingccy() {
        return fundingccy;
    }

    public void setFundingccy(String fundingccy) {
        this.fundingccy = fundingccy == null ? null : fundingccy.trim();
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}