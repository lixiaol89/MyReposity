package com.modules.nonlinearswapinfo.dao;

import com.modules.nonlinearswapinfo.model.NonlinearswapinfoModel;
import com.modules.nonlinearswapinfo.model.NonlinearswapinfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NonlinearswapinfoModelMapper {
    int countByExample(NonlinearswapinfoModelExample example);

    int deleteByExample(NonlinearswapinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NonlinearswapinfoModel record);

    int insertSelective(NonlinearswapinfoModel record);

    List<NonlinearswapinfoModel> selectByExample(NonlinearswapinfoModelExample example);

    NonlinearswapinfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") NonlinearswapinfoModel record, @Param("example") NonlinearswapinfoModelExample example);

    int updateByExample(@Param("record") NonlinearswapinfoModel record, @Param("example") NonlinearswapinfoModelExample example);

    int updateByPrimaryKeySelective(NonlinearswapinfoModel record);

    int updateByPrimaryKey(NonlinearswapinfoModel record);
}