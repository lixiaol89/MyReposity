package com.modules.repo.dao;

import com.modules.repo.model.RepoModel;
import com.modules.repo.model.RepoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RepoModelMapper {
    int countByExample(RepoModelExample example);

    int deleteByExample(RepoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(RepoModel record);

    int insertSelective(RepoModel record);

    List<RepoModel> selectByExample(RepoModelExample example);

    RepoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") RepoModel record, @Param("example") RepoModelExample example);

    int updateByExample(@Param("record") RepoModel record, @Param("example") RepoModelExample example);

    int updateByPrimaryKeySelective(RepoModel record);

    int updateByPrimaryKey(RepoModel record);
}