package com.modules.repo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.repo.dao.RepoModelMapper;
import com.modules.repo.model.RepoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class RepoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		RepoModelMapper sourcemapper = GetDataSource.getMapper(RepoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		RepoModelMapper targetmapper = GetDataSource.getMapper(RepoModelMapper.class, sessionqa);
		
		
		List<RepoModel> source = sourcemapper.selectByExample(null);
		List<RepoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<RepoModel> same = new ArrayList<RepoModel>();
		for(RepoModel targetmodel : target){
			for(RepoModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getParameter()==sourcemodel.getParameter()&&
						targetmodel.getFamily()==sourcemodel.getFamily()&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())&&
						targetmodel.getRepodate().equals(sourcemodel.getRepodate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(RepoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(RepoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new RepoCompare().compare();
	}


}
