package com.modules.repo.model;

import java.math.BigDecimal;
import java.util.Date;

public class RepoModel {
    private Integer id;

    private String underlying;

    private Integer parameter;

    private Integer family;

    private String currency;

    private Date repodate;

    private BigDecimal repoyield;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public Integer getParameter() {
        return parameter;
    }

    public void setParameter(Integer parameter) {
        this.parameter = parameter;
    }

    public Integer getFamily() {
        return family;
    }

    public void setFamily(Integer family) {
        this.family = family;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Date getRepodate() {
        return repodate;
    }

    public void setRepodate(Date repodate) {
        this.repodate = repodate;
    }

    public BigDecimal getRepoyield() {
        return repoyield;
    }

    public void setRepoyield(BigDecimal repoyield) {
        this.repoyield = repoyield;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}