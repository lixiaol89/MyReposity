package com.modules.correlation.model;

import java.math.BigDecimal;
import java.util.Date;

public class CorrelationModel {
    private Integer id;

    private String asset1;

    private String asset2;

    private BigDecimal correlation;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAsset1() {
        return asset1;
    }

    public void setAsset1(String asset1) {
        this.asset1 = asset1 == null ? null : asset1.trim();
    }

    public String getAsset2() {
        return asset2;
    }

    public void setAsset2(String asset2) {
        this.asset2 = asset2 == null ? null : asset2.trim();
    }

    public BigDecimal getCorrelation() {
        return correlation;
    }

    public void setCorrelation(BigDecimal correlation) {
        this.correlation = correlation;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
    
    @Override
    public String toString() {
    	System.out.println(this.asset1 + "," +this.asset2 + "," + this.correlation );
    	return super.toString();
    }
}