package com.modules.correlation.dao;

import com.modules.correlation.model.CorrelationModel;
import com.modules.correlation.model.CorrelationModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CorrelationModelMapper {
    int countByExample(CorrelationModelExample example);

    int deleteByExample(CorrelationModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CorrelationModel record);

    int insertSelective(CorrelationModel record);

    List<CorrelationModel> selectByExample(CorrelationModelExample example);

    CorrelationModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CorrelationModel record, @Param("example") CorrelationModelExample example);

    int updateByExample(@Param("record") CorrelationModel record, @Param("example") CorrelationModelExample example);

    int updateByPrimaryKeySelective(CorrelationModel record);

    int updateByPrimaryKey(CorrelationModel record);
}