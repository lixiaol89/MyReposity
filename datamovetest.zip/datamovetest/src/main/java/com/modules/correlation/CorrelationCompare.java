package com.modules.correlation;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.bkunderlyinginfo.BkunderlyinginfoCompare;
import com.modules.correlation.dao.CorrelationModelMapper;
import com.modules.correlation.model.CorrelationModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CorrelationCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CorrelationModelMapper sourcemapper = GetDataSource.getMapper(CorrelationModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CorrelationModelMapper targetmapper = GetDataSource.getMapper(CorrelationModelMapper.class, sessionqa);
		
		
		List<CorrelationModel> source = sourcemapper.selectByExample(null);
		List<CorrelationModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CorrelationModel> same = new ArrayList<CorrelationModel>();
		for(CorrelationModel targetmodel : target){
			for(CorrelationModel sourcemodel : source){
				if(targetmodel.getAsset1().equals(sourcemodel.getAsset1()) && targetmodel.getAsset2().equals(sourcemodel.getAsset2())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(CorrelationModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CorrelationModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CorrelationCompare().compare();
	}


}
