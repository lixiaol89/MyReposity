package com.modules.codecatalog.dao;

import com.modules.codecatalog.model.CodecatalogModel;
import com.modules.codecatalog.model.CodecatalogModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CodecatalogModelMapper {
    int countByExample(CodecatalogModelExample example);

    int deleteByExample(CodecatalogModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CodecatalogModel record);

    int insertSelective(CodecatalogModel record);

    List<CodecatalogModel> selectByExample(CodecatalogModelExample example);

    CodecatalogModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CodecatalogModel record, @Param("example") CodecatalogModelExample example);

    int updateByExample(@Param("record") CodecatalogModel record, @Param("example") CodecatalogModelExample example);

    int updateByPrimaryKeySelective(CodecatalogModel record);

    int updateByPrimaryKey(CodecatalogModel record);
}