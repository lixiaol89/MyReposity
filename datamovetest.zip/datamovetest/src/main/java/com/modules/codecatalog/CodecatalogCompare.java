package com.modules.codecatalog;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.codecatalog.dao.CodecatalogModelMapper;
import com.modules.codecatalog.model.CodecatalogModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CodecatalogCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CodecatalogModelMapper sourcemapper = GetDataSource.getMapper(CodecatalogModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CodecatalogModelMapper targetmapper = GetDataSource.getMapper(CodecatalogModelMapper.class, sessionqa);
		
		
		List<CodecatalogModel> source = sourcemapper.selectByExample(null);
		List<CodecatalogModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CodecatalogModel> same = new ArrayList<CodecatalogModel>();
		for(CodecatalogModel targetmodel : target){
			for(CodecatalogModel sourcemodel : source){
				if(targetmodel.getItemno()==sourcemodel.getItemno()){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(CodecatalogModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CodecatalogModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CodecatalogCompare().compare();
	}


}
