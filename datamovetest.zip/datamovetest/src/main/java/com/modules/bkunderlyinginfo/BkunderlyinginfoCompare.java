package com.modules.bkunderlyinginfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.bkunderlyinginfo.dao.BkunderlyinginfoModelMapper;
import com.modules.bkunderlyinginfo.model.BkunderlyinginfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class BkunderlyinginfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		BkunderlyinginfoModelMapper sourcemapper = GetDataSource.getMapper(BkunderlyinginfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		BkunderlyinginfoModelMapper targetmapper = GetDataSource.getMapper(BkunderlyinginfoModelMapper.class, sessionqa);
		
		
		List<BkunderlyinginfoModel> source = sourcemapper.selectByExample(null);
		List<BkunderlyinginfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<BkunderlyinginfoModel> same = new ArrayList<BkunderlyinginfoModel>();
		for(BkunderlyinginfoModel targetmodel : target){
			for(BkunderlyinginfoModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())&&targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(BkunderlyinginfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(BkunderlyinginfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new BkunderlyinginfoCompare().compare();
	}


}
