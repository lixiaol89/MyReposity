package com.modules.bkunderlyinginfo.dao;

import com.modules.bkunderlyinginfo.model.BkunderlyinginfoModel;
import com.modules.bkunderlyinginfo.model.BkunderlyinginfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BkunderlyinginfoModelMapper {
    int countByExample(BkunderlyinginfoModelExample example);

    int deleteByExample(BkunderlyinginfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BkunderlyinginfoModel record);

    int insertSelective(BkunderlyinginfoModel record);

    List<BkunderlyinginfoModel> selectByExample(BkunderlyinginfoModelExample example);

    BkunderlyinginfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BkunderlyinginfoModel record, @Param("example") BkunderlyinginfoModelExample example);

    int updateByExample(@Param("record") BkunderlyinginfoModel record, @Param("example") BkunderlyinginfoModelExample example);

    int updateByPrimaryKeySelective(BkunderlyinginfoModel record);

    int updateByPrimaryKey(BkunderlyinginfoModel record);
}