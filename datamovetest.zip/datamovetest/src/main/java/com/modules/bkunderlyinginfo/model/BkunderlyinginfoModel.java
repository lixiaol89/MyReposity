package com.modules.bkunderlyinginfo.model;

import java.math.BigDecimal;
import java.util.Date;

public class BkunderlyinginfoModel {
    private Integer id;

    private String tradeid;

    private String underlying;

    private BigDecimal weight;

    private String underlyingccy;

    private String exchangecode;

    private BigDecimal initialfixing;

    private BigDecimal overridefixing;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public String getUnderlyingccy() {
        return underlyingccy;
    }

    public void setUnderlyingccy(String underlyingccy) {
        this.underlyingccy = underlyingccy == null ? null : underlyingccy.trim();
    }

    public String getExchangecode() {
        return exchangecode;
    }

    public void setExchangecode(String exchangecode) {
        this.exchangecode = exchangecode == null ? null : exchangecode.trim();
    }

    public BigDecimal getInitialfixing() {
        return initialfixing;
    }

    public void setInitialfixing(BigDecimal initialfixing) {
        this.initialfixing = initialfixing;
    }

    public BigDecimal getOverridefixing() {
        return overridefixing;
    }

    public void setOverridefixing(BigDecimal overridefixing) {
        this.overridefixing = overridefixing;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}