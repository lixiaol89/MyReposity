package com.modules.marktomkt.dao;

import com.modules.marktomkt.model.MarktomktModel;
import com.modules.marktomkt.model.MarktomktModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MarktomktModelMapper {
    int countByExample(MarktomktModelExample example);

    int deleteByExample(MarktomktModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(MarktomktModel record);

    int insertSelective(MarktomktModel record);

    List<MarktomktModel> selectByExample(MarktomktModelExample example);

    MarktomktModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") MarktomktModel record, @Param("example") MarktomktModelExample example);

    int updateByExample(@Param("record") MarktomktModel record, @Param("example") MarktomktModelExample example);

    int updateByPrimaryKeySelective(MarktomktModel record);

    int updateByPrimaryKey(MarktomktModel record);
}