package com.modules.marktomkt;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.marktomkt.dao.MarktomktModelMapper;
import com.modules.marktomkt.model.MarktomktModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class MarktomktCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		MarktomktModelMapper sourcemapper = GetDataSource.getMapper(MarktomktModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		MarktomktModelMapper targetmapper = GetDataSource.getMapper(MarktomktModelMapper.class, sessionqa);
		
		
		List<MarktomktModel> source = sourcemapper.selectByExample(null);
		List<MarktomktModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<MarktomktModel> same = new ArrayList<MarktomktModel>();
		for(MarktomktModel targetmodel : target){
			for(MarktomktModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())&&
						targetmodel.getDate().equals(sourcemodel.getDate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(MarktomktModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(MarktomktModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new MarktomktCompare().compare();
	}


}
