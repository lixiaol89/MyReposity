package com.modules.marktomkt.model;

import java.math.BigDecimal;
import java.util.Date;

public class MarktomktModel {
    private Integer id;

    private String tradeid;

    private Date date;

    private String clientid;

    private String settleccy;

    private BigDecimal position;

    private BigDecimal pvn;

    private BigDecimal deltan;

    private BigDecimal marginn;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid == null ? null : tradeid.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getClientid() {
        return clientid;
    }

    public void setClientid(String clientid) {
        this.clientid = clientid == null ? null : clientid.trim();
    }

    public String getSettleccy() {
        return settleccy;
    }

    public void setSettleccy(String settleccy) {
        this.settleccy = settleccy == null ? null : settleccy.trim();
    }

    public BigDecimal getPosition() {
        return position;
    }

    public void setPosition(BigDecimal position) {
        this.position = position;
    }

    public BigDecimal getPvn() {
        return pvn;
    }

    public void setPvn(BigDecimal pvn) {
        this.pvn = pvn;
    }

    public BigDecimal getDeltan() {
        return deltan;
    }

    public void setDeltan(BigDecimal deltan) {
        this.deltan = deltan;
    }

    public BigDecimal getMarginn() {
        return marginn;
    }

    public void setMarginn(BigDecimal marginn) {
        this.marginn = marginn;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}