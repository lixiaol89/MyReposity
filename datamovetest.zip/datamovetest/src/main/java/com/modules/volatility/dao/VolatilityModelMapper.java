package com.modules.volatility.dao;

import com.modules.volatility.model.VolatilityModel;
import com.modules.volatility.model.VolatilityModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface VolatilityModelMapper {
    int countByExample(VolatilityModelExample example);

    int deleteByExample(VolatilityModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(VolatilityModel record);

    int insertSelective(VolatilityModel record);

    List<VolatilityModel> selectByExample(VolatilityModelExample example);

    VolatilityModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") VolatilityModel record, @Param("example") VolatilityModelExample example);

    int updateByExample(@Param("record") VolatilityModel record, @Param("example") VolatilityModelExample example);

    int updateByPrimaryKeySelective(VolatilityModel record);

    int updateByPrimaryKey(VolatilityModel record);
}