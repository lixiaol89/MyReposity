package com.modules.volatility;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.Comparemethod;
import com.modules.volatility.dao.VolatilityModelMapper;
import com.modules.volatility.model.VolatilityModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class VolatilityCompare  implements Comparemethod{
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		VolatilityModelMapper sourcemapper = GetDataSource.getMapper(VolatilityModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		VolatilityModelMapper targetmapper = GetDataSource.getMapper(VolatilityModelMapper.class, sessionqa);
		
		
		List<VolatilityModel> source = sourcemapper.selectByExample(null);
		List<VolatilityModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<VolatilityModel> same = new ArrayList<VolatilityModel>();
		for(VolatilityModel targetmodel : target){
			for(VolatilityModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getParameter()==sourcemodel.getParameter()&&
						targetmodel.getFamily()==sourcemodel.getFamily()&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())&&
						targetmodel.getVoldate().equals(sourcemodel.getVoldate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(VolatilityModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(VolatilityModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new VolatilityCompare().compare();
	}


}
