package com.modules.volatility.model;

import java.math.BigDecimal;
import java.util.Date;

public class VolatilityModel {
    private Integer id;

    private String underlying;

    private Integer parameter;

    private Integer family;

    private String currency;

    private Date voldate;

    private BigDecimal atmvol;

    private BigDecimal skew;

    private BigDecimal kurt;

    private BigDecimal callwing;

    private BigDecimal putwing;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public Integer getParameter() {
        return parameter;
    }

    public void setParameter(Integer parameter) {
        this.parameter = parameter;
    }

    public Integer getFamily() {
        return family;
    }

    public void setFamily(Integer family) {
        this.family = family;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Date getVoldate() {
        return voldate;
    }

    public void setVoldate(Date voldate) {
        this.voldate = voldate;
    }

    public BigDecimal getAtmvol() {
        return atmvol;
    }

    public void setAtmvol(BigDecimal atmvol) {
        this.atmvol = atmvol;
    }

    public BigDecimal getSkew() {
        return skew;
    }

    public void setSkew(BigDecimal skew) {
        this.skew = skew;
    }

    public BigDecimal getKurt() {
        return kurt;
    }

    public void setKurt(BigDecimal kurt) {
        this.kurt = kurt;
    }

    public BigDecimal getCallwing() {
        return callwing;
    }

    public void setCallwing(BigDecimal callwing) {
        this.callwing = callwing;
    }

    public BigDecimal getPutwing() {
        return putwing;
    }

    public void setPutwing(BigDecimal putwing) {
        this.putwing = putwing;
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}