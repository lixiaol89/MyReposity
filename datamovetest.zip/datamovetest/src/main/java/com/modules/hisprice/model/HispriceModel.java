package com.modules.hisprice.model;

import java.math.BigDecimal;
import java.util.Date;

public class HispriceModel {
    private Integer id;

    private Date hisdate;

    private String underlying;

    private String currency;

    private String exchangecode;

    private Boolean stopflag;

    private BigDecimal last;

    private BigDecimal close;

    private BigDecimal open;

    private BigDecimal high;

    private BigDecimal low;

    private BigDecimal settleprice;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getHisdate() {
        return hisdate;
    }

    public void setHisdate(Date hisdate) {
        this.hisdate = hisdate;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public String getExchangecode() {
        return exchangecode;
    }

    public void setExchangecode(String exchangecode) {
        this.exchangecode = exchangecode == null ? null : exchangecode.trim();
    }

    public Boolean getStopflag() {
        return stopflag;
    }

    public void setStopflag(Boolean stopflag) {
        this.stopflag = stopflag;
    }

    public BigDecimal getLast() {
        return last;
    }

    public void setLast(BigDecimal last) {
        this.last = last;
    }

    public BigDecimal getClose() {
        return close;
    }

    public void setClose(BigDecimal close) {
        this.close = close;
    }

    public BigDecimal getOpen() {
        return open;
    }

    public void setOpen(BigDecimal open) {
        this.open = open;
    }

    public BigDecimal getHigh() {
        return high;
    }

    public void setHigh(BigDecimal high) {
        this.high = high;
    }

    public BigDecimal getLow() {
        return low;
    }

    public void setLow(BigDecimal low) {
        this.low = low;
    }

    public BigDecimal getSettleprice() {
        return settleprice;
    }

    public void setSettleprice(BigDecimal settleprice) {
        this.settleprice = settleprice;
    }
}