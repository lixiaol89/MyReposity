package com.modules.hisprice.dao;

import com.modules.hisprice.model.HispriceModel;
import com.modules.hisprice.model.HispriceModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HispriceModelMapper {
    int countByExample(HispriceModelExample example);

    int deleteByExample(HispriceModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(HispriceModel record);

    int insertSelective(HispriceModel record);

    List<HispriceModel> selectByExample(HispriceModelExample example);

    HispriceModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") HispriceModel record, @Param("example") HispriceModelExample example);

    int updateByExample(@Param("record") HispriceModel record, @Param("example") HispriceModelExample example);

    int updateByPrimaryKeySelective(HispriceModel record);

    int updateByPrimaryKey(HispriceModel record);
}