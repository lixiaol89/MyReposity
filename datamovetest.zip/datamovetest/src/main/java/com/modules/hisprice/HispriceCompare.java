package com.modules.hisprice;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.hisprice.dao.HispriceModelMapper;
import com.modules.hisprice.model.HispriceModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class HispriceCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		HispriceModelMapper sourcemapper = GetDataSource.getMapper(HispriceModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		HispriceModelMapper targetmapper = GetDataSource.getMapper(HispriceModelMapper.class, sessionqa);
		
		
		List<HispriceModel> source = sourcemapper.selectByExample(null);
		List<HispriceModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<HispriceModel> same = new ArrayList<HispriceModel>();
		for(HispriceModel targetmodel : target){
			for(HispriceModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())&&
						targetmodel.getHigh().equals(sourcemodel.getHisdate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(HispriceModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(HispriceModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new HispriceCompare().compare();
	}


}
