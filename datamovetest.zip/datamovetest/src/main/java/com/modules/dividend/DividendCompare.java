package com.modules.dividend;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.dividend.dao.DividendModelMapper;
import com.modules.dividend.model.DividendModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class DividendCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		DividendModelMapper sourcemapper = GetDataSource.getMapper(DividendModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		DividendModelMapper targetmapper = GetDataSource.getMapper(DividendModelMapper.class, sessionqa);
		
		
		List<DividendModel> source = sourcemapper.selectByExample(null);
		List<DividendModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<DividendModel> same = new ArrayList<DividendModel>();
		for(DividendModel targetmodel : target){
			for(DividendModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getParameter()==sourcemodel.getParameter()&&
						targetmodel.getFamily()==sourcemodel.getFamily()&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())&&
						targetmodel.getDivexdate().equals(sourcemodel.getDivexdate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(DividendModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(DividendModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new DividendCompare().compare();
	}


}
