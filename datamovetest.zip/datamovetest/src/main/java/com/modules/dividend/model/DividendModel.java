package com.modules.dividend.model;

import java.math.BigDecimal;
import java.util.Date;

public class DividendModel {
    private Integer id;

    private String underlying;

    private Integer parameter;

    private Integer family;

    private String currency;

    private Date divexdate;

    private Date divpaymentdate;

    private BigDecimal divamount;

    private BigDecimal divyield;

    private String divccy;

    private String lastupdateuser;

    private Date lastupdatetime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnderlying() {
        return underlying;
    }

    public void setUnderlying(String underlying) {
        this.underlying = underlying == null ? null : underlying.trim();
    }

    public Integer getParameter() {
        return parameter;
    }

    public void setParameter(Integer parameter) {
        this.parameter = parameter;
    }

    public Integer getFamily() {
        return family;
    }

    public void setFamily(Integer family) {
        this.family = family;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Date getDivexdate() {
        return divexdate;
    }

    public void setDivexdate(Date divexdate) {
        this.divexdate = divexdate;
    }

    public Date getDivpaymentdate() {
        return divpaymentdate;
    }

    public void setDivpaymentdate(Date divpaymentdate) {
        this.divpaymentdate = divpaymentdate;
    }

    public BigDecimal getDivamount() {
        return divamount;
    }

    public void setDivamount(BigDecimal divamount) {
        this.divamount = divamount;
    }

    public BigDecimal getDivyield() {
        return divyield;
    }

    public void setDivyield(BigDecimal divyield) {
        this.divyield = divyield;
    }

    public String getDivccy() {
        return divccy;
    }

    public void setDivccy(String divccy) {
        this.divccy = divccy == null ? null : divccy.trim();
    }

    public String getLastupdateuser() {
        return lastupdateuser;
    }

    public void setLastupdateuser(String lastupdateuser) {
        this.lastupdateuser = lastupdateuser == null ? null : lastupdateuser.trim();
    }

    public Date getLastupdatetime() {
        return lastupdatetime;
    }

    public void setLastupdatetime(Date lastupdatetime) {
        this.lastupdatetime = lastupdatetime;
    }
}