package com.modules.dividend.dao;

import com.modules.dividend.model.DividendModel;
import com.modules.dividend.model.DividendModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DividendModelMapper {
    int countByExample(DividendModelExample example);

    int deleteByExample(DividendModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DividendModel record);

    int insertSelective(DividendModel record);

    List<DividendModel> selectByExample(DividendModelExample example);

    DividendModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DividendModel record, @Param("example") DividendModelExample example);

    int updateByExample(@Param("record") DividendModel record, @Param("example") DividendModelExample example);

    int updateByPrimaryKeySelective(DividendModel record);

    int updateByPrimaryKey(DividendModel record);
}