package com.modules.liveprice.dao;

import com.modules.liveprice.model.LivepriceModel;
import com.modules.liveprice.model.LivepriceModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LivepriceModelMapper {
    int countByExample(LivepriceModelExample example);

    int deleteByExample(LivepriceModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(LivepriceModel record);

    int insertSelective(LivepriceModel record);

    List<LivepriceModel> selectByExample(LivepriceModelExample example);

    LivepriceModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") LivepriceModel record, @Param("example") LivepriceModelExample example);

    int updateByExample(@Param("record") LivepriceModel record, @Param("example") LivepriceModelExample example);

    int updateByPrimaryKeySelective(LivepriceModel record);

    int updateByPrimaryKey(LivepriceModel record);
}