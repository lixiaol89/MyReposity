package com.modules.liveprice;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.liveprice.dao.LivepriceModelMapper;
import com.modules.liveprice.model.LivepriceModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class LivepriceCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		LivepriceModelMapper sourcemapper = GetDataSource.getMapper(LivepriceModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		LivepriceModelMapper targetmapper = GetDataSource.getMapper(LivepriceModelMapper.class, sessionqa);
		
		
		List<LivepriceModel> source = sourcemapper.selectByExample(null);
		List<LivepriceModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<LivepriceModel> same = new ArrayList<LivepriceModel>();
		for(LivepriceModel targetmodel : target){
			for(LivepriceModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getExchangecode().equals(sourcemodel.getExchangecode())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(LivepriceModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(LivepriceModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new LivepriceCompare().compare();
	}


}
