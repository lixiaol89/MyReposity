package com.modules.codelibrary;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.codelibrary.dao.CodelibraryModelMapper;
import com.modules.codelibrary.model.CodelibraryModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class CodelibraryCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		CodelibraryModelMapper sourcemapper = GetDataSource.getMapper(CodelibraryModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		CodelibraryModelMapper targetmapper = GetDataSource.getMapper(CodelibraryModelMapper.class, sessionqa);
		
		
		List<CodelibraryModel> source = sourcemapper.selectByExample(null);
		List<CodelibraryModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<CodelibraryModel> same = new ArrayList<CodelibraryModel>();
		for(CodelibraryModel targetmodel : target){
			for(CodelibraryModel sourcemodel : source){
				if(targetmodel.getItemno()==sourcemodel.getItemno()&&targetmodel.getCodeno()==sourcemodel.getCodeno()){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(CodelibraryModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(CodelibraryModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new CodelibraryCompare().compare();
	}


}
