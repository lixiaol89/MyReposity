package com.modules.codelibrary.dao;

import com.modules.codelibrary.model.CodelibraryModel;
import com.modules.codelibrary.model.CodelibraryModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CodelibraryModelMapper {
    int countByExample(CodelibraryModelExample example);

    int deleteByExample(CodelibraryModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CodelibraryModel record);

    int insertSelective(CodelibraryModel record);

    List<CodelibraryModel> selectByExample(CodelibraryModelExample example);

    CodelibraryModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CodelibraryModel record, @Param("example") CodelibraryModelExample example);

    int updateByExample(@Param("record") CodelibraryModel record, @Param("example") CodelibraryModelExample example);

    int updateByPrimaryKeySelective(CodelibraryModel record);

    int updateByPrimaryKey(CodelibraryModel record);
}