package com.modules.bondbkinfo;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.bondbkinfo.dao.BondbkinfoModelMapper;
import com.modules.bondbkinfo.model.BondbkinfoModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class BondbkinfoCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		BondbkinfoModelMapper sourcemapper = GetDataSource.getMapper(BondbkinfoModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		BondbkinfoModelMapper targetmapper = GetDataSource.getMapper(BondbkinfoModelMapper.class, sessionqa);
		
		
		List<BondbkinfoModel> source = sourcemapper.selectByExample(null);
		List<BondbkinfoModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<BondbkinfoModel> same = new ArrayList<BondbkinfoModel>();
		for(BondbkinfoModel targetmodel : target){
			for(BondbkinfoModel sourcemodel : source){
				if(targetmodel.getTradeid().equals(sourcemodel.getTradeid())){
					same.add(targetmodel);
				}
			}
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			
			for(BondbkinfoModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(BondbkinfoModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new BondbkinfoCompare().compare();
	}


}
