package com.modules.bondbkinfo.dao;

import com.modules.bondbkinfo.model.BondbkinfoModel;
import com.modules.bondbkinfo.model.BondbkinfoModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BondbkinfoModelMapper {
    int countByExample(BondbkinfoModelExample example);

    int deleteByExample(BondbkinfoModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BondbkinfoModel record);

    int insertSelective(BondbkinfoModel record);

    List<BondbkinfoModel> selectByExample(BondbkinfoModelExample example);

    BondbkinfoModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BondbkinfoModel record, @Param("example") BondbkinfoModelExample example);

    int updateByExample(@Param("record") BondbkinfoModel record, @Param("example") BondbkinfoModelExample example);

    int updateByPrimaryKeySelective(BondbkinfoModel record);

    int updateByPrimaryKey(BondbkinfoModel record);
}