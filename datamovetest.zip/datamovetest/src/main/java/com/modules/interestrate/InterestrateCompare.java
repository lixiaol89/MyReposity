package com.modules.interestrate;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.modules.interestrate.dao.InterestrateModelMapper;
import com.modules.interestrate.model.InterestrateModel;

import datasource.GetDataSource;
import datasource.GetDataSource.DataSourceEnvironment;

public class InterestrateCompare {
	

	
	public void compare(){
		SqlSession sessiondevelopment = GetDataSource.getSqlSession(DataSourceEnvironment.development);
		InterestrateModelMapper sourcemapper = GetDataSource.getMapper(InterestrateModelMapper.class, sessiondevelopment);
		
		
		SqlSession sessionqa = GetDataSource.getSqlSession(DataSourceEnvironment.qa);
		InterestrateModelMapper targetmapper = GetDataSource.getMapper(InterestrateModelMapper.class, sessionqa);
		
		
		List<InterestrateModel> source = sourcemapper.selectByExample(null);
		List<InterestrateModel> target = targetmapper.selectByExample(null);
		System.out.println("sourcesize=======================" + source.size());
		System.out.println("targetsize=======================" + target.size());
		
		List<InterestrateModel> same = new ArrayList<InterestrateModel>();
		for(InterestrateModel targetmodel : target){
			for(InterestrateModel sourcemodel : source){
				if(targetmodel.getUnderlying().equals(sourcemodel.getUnderlying())&&
						targetmodel.getParameter()==sourcemodel.getParameter()&&
						targetmodel.getFamily()==sourcemodel.getFamily()&&
						targetmodel.getCurrency().equals(sourcemodel.getCurrency())&&
						targetmodel.getIntdate().equals(sourcemodel.getIntdate())){
					same.add(targetmodel);
				}
			}
			
		}
		System.out.println("samesize=========================" + same.size());
		
		try {
			target.removeAll(same);
			
			targetmapper.deleteByExample(null);
			
			for(InterestrateModel smodel : source){
				targetmapper.insert(smodel);
			}
			
			for(InterestrateModel samemodel : target){
				samemodel.setId(null);
				targetmapper.insertSelective(samemodel);
			}
			
			sessionqa.commit();
		} catch (Exception e) {
			e.printStackTrace();
			sessionqa.rollback();
		}finally{
			sessionqa.close();
		}
		
		
	}
	
	public static void main(String[] args) {
		new InterestrateCompare().compare();
	}


}
