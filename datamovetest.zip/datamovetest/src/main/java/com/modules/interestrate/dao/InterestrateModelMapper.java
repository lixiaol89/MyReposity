package com.modules.interestrate.dao;

import com.modules.interestrate.model.InterestrateModel;
import com.modules.interestrate.model.InterestrateModelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InterestrateModelMapper {
    int countByExample(InterestrateModelExample example);

    int deleteByExample(InterestrateModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InterestrateModel record);

    int insertSelective(InterestrateModel record);

    List<InterestrateModel> selectByExample(InterestrateModelExample example);

    InterestrateModel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InterestrateModel record, @Param("example") InterestrateModelExample example);

    int updateByExample(@Param("record") InterestrateModel record, @Param("example") InterestrateModelExample example);

    int updateByPrimaryKeySelective(InterestrateModel record);

    int updateByPrimaryKey(InterestrateModel record);
}